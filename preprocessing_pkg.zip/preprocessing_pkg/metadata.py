"""Subject-inventory scaffold for however many datasets are enabled."""

from __future__ import annotations
import pandas as pd
from .config import DatasetRegistry, GlobalConfig
from .channels import standardize_channel_name


def build_subject_metadata_scaffold(registry: DatasetRegistry,
                                     glob: GlobalConfig | None = None) -> pd.DataFrame:
    """One row per (dataset, subject) for every ENABLED dataset.

    Now reports the channel count under the CONFIGURED harmonization mode (the
    old version always reported the intersection count regardless of what the
    pipeline was using), flags config-excluded subjects instead of listing them
    as if they were usable, and carries the cue offset so the timing bookkeeping
    is visible per row.
    """
    mode = glob.HARMONIZATION_MODE if glob else "intersection"
    anchors = list(glob.ANCHOR_DATASETS) if glob else None
    common_channels, _ = registry.compute_channels(
        standardize_channel_name, mode=mode, anchor_datasets=anchors)

    rows = []
    for cfg in registry.enabled():
        excluded = cfg.excluded_subjects or {}
        for sid in range(1, cfg.n_subjects + 1):
            rows.append({
                "dataset": cfg.name,
                "subject_id": sid,
                "native_sfreq": cfg.native_sfreq,
                "n_sessions": cfg.n_sessions,
                "cue_offset_sec": cfg.cue_offset_sec,
                "trial_length_sec": cfg.trial_length_sec,
                "excluded": sid in excluded,
                "exclusion_reason": excluded.get(sid, ""),
            })
    df = pd.DataFrame(rows)
    df["harmonization_mode"] = mode
    df["n_target_channels"] = len(common_channels)
    return df
