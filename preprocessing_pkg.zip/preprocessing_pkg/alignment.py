"""Euclidean Alignment (He & Wu 2020, IEEE TBME 67(2):399-410,
"Transfer Learning for Brain-Computer Interfaces: A Euclidean Space Data
Alignment Approach").

WHAT THE LEAKAGE AUDIT FOUND
----------------------------
The previous implementation computed each subject's reference covariance from
ALL of that subject's trials and applied it before cross-validation. Under
subject-grouped CV a held-out subject is entirely in the test fold, so its
reference matrix was estimated from test data.

That is not automatically wrong -- EA is deliberately *transductive*: it is
label-free, and in the original formulation the target subject's unlabelled
trials are exactly what you are allowed to use. But it was never declared, and
an undeclared transductive step in a table next to inductive rows is not a fair
comparison. So both scopes are implemented and named:

  scope='subject'     reference from each subject's own trials (transductive,
                      the standard formulation). Honest, but the row must be
                      labelled as such.
  scope='train_only'  reference estimated from training-fold subjects only and
                      applied to everyone (strictly inductive). Weaker, but
                      directly comparable to the EA-off row.

Two further corrections:
  * trace normalisation is applied to the REFERENCE, not to each trial before
    averaging. Normalising every trial first throws away the relative
    amplitude information that the reference is supposed to summarise.
  * the inverse square root is taken through a symmetric eigendecomposition
    with eigenvalue flooring, instead of ``scipy.linalg.fractional_matrix_power``.
    That routine goes through a Schur decomposition and returns a complex array
    whose real part was silently taken -- for a rank-deficient covariance
    (which post-CAR and post-masking data always is) it can return garbage
    rather than a usable whitener.
"""

from __future__ import annotations
import numpy as np
import mne


def _spatial_covariances(data: np.ndarray) -> np.ndarray:
    """(n_trials, n_channels, n_times) -> (n_trials, n_channels, n_channels)."""
    n_times = data.shape[-1]
    return np.einsum("nct,ndt->ncd", data, data) / n_times


def _inv_sqrt_psd(mat: np.ndarray, rcond: float = 1e-10) -> np.ndarray:
    """Symmetric inverse square root with eigenvalue flooring.

    Post-CAR data is rank-deficient by construction and masked channels make it
    more so, so the reference covariance has near-zero eigenvalues. Flooring
    them at `rcond * max_eigenvalue` keeps the whitener finite instead of
    amplifying a numerical null space by 1e8.
    """
    mat = (mat + mat.T) / 2.0
    evals, evecs = np.linalg.eigh(mat)
    floor = rcond * max(evals.max(), 1e-30)
    evals = np.clip(evals, floor, None)
    return evecs @ np.diag(evals ** -0.5) @ evecs.T


def compute_ea_reference(data: np.ndarray) -> np.ndarray:
    """Reference covariance R_bar: the arithmetic mean of per-trial spatial
    covariances, trace-normalised once at the end."""
    covs = _spatial_covariances(np.asarray(data, dtype=float))
    r_bar = covs.mean(axis=0)
    tr = np.trace(r_bar)
    if tr > 0:
        r_bar = r_bar / tr * r_bar.shape[0]
    return r_bar


def whiten_with_reference(data: np.ndarray, r_bar: np.ndarray) -> np.ndarray:
    """Apply R_bar^(-1/2) to every trial."""
    return np.einsum("cd,ndt->nct", _inv_sqrt_psd(r_bar), np.asarray(data, dtype=float))


def apply_euclidean_alignment(epochs, r_bar: np.ndarray | None = None) -> np.ndarray:
    """Per-subject EA. With `r_bar=None` the reference is computed from this
    Epochs object (transductive, scope='subject'); pass a reference fitted
    elsewhere for scope='train_only'.

    Returns a plain ndarray (n_trials, n_channels, n_times).
    """
    data = epochs.get_data() if isinstance(epochs, mne.BaseEpochs) else np.asarray(epochs)
    if r_bar is None:
        r_bar = compute_ea_reference(data)
    return whiten_with_reference(data, r_bar)


def align_cohort(epochs_by_key: dict, scope: str = "subject",
                  train_keys=None) -> dict:
    """Align a whole cohort. Returns {key: aligned ndarray}.

    scope='subject'    one reference per subject, from that subject's trials.
    scope='train_only' one reference pooled over `train_keys` only, applied to
                       every subject including held-out ones.
    """
    if scope == "subject":
        return {k: apply_euclidean_alignment(ep) for k, ep in epochs_by_key.items()}
    if scope == "train_only":
        if not train_keys:
            raise ValueError("scope='train_only' needs train_keys.")
        pooled = np.concatenate([epochs_by_key[k].get_data() for k in train_keys], axis=0)
        r_bar = compute_ea_reference(pooled)
        return {k: apply_euclidean_alignment(ep, r_bar=r_bar)
                for k, ep in epochs_by_key.items()}
    raise ValueError(f"scope must be 'subject' or 'train_only', got {scope!r}")
