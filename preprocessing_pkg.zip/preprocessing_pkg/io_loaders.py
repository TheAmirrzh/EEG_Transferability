"""Raw-data loaders, unified to one interface:

    loader_fn(subject: int) -> list[mne.io.Raw]

Each returned list is already restricted to the dataset's valid
runs/sessions/phases. ``run_primary_pipeline`` concatenates whatever list it is
handed, so every dataset plugs into the same downstream call.

TWO THINGS LAND HERE IN THIS REVISION
-------------------------------------
1. ``resolve_cue_offset`` -- the single most consequential fix in this pass.
   MOABB describes each dataset's usable task window with an ``interval``
   attribute, e.g. ``BNCI2014_001.interval == [2, 6]`` because the trial opens
   with a 2 s fixation cross and the arrow cue only appears at t = 2 s.
   In MOABB 1.0.0, ``SetRawAnnotations`` wrote annotations at the *trial*
   onset rather than at ``onset + interval[0]``; MOABB PR #607 (released in
   1.1) changed that. MOABB's own paradigms were unaffected because they add
   ``interval[0]`` themselves -- but any code that loads the raws and epochs
   externally from ``raw.annotations``, which is exactly what this pipeline
   does, is affected. Getting it wrong on BNCI2014_001 means epoching the
   fixation cross; on Weibo2014 (interval [3, 7]) it is 3 s off.

   This function reads the installed MOABB version and the dataset's declared
   interval, and returns the offset that has to be added to a cue-relative
   window. It prints what it decided, and it can be overridden by hand.

2. The robust Lee2019 loader (trigger extraction from ``STI 014``) that used
   to be a notebook monkey-patch.
"""

from __future__ import annotations
from pathlib import Path
import mne
import numpy as np

from .config import (
    PHYSIONET_ROOT, PHYSIONET_UNILATERAL_IMAGERY_RUNS,
    PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS,
)


# --------------------------------------------------------------------------
# MOABB annotation-offset resolution
# --------------------------------------------------------------------------

def _moabb_version() -> tuple:
    try:
        import moabb
        v = getattr(moabb, "__version__", "0")
    except Exception:
        return (0,)
    parts = []
    for p in str(v).split("."):
        num = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(num) if num else 0)
    return tuple(parts) if parts else (0,)


#: MOABB version at which annotations started including ``interval[0]``.
MOABB_ANNOTATION_FIX_VERSION = (1, 1, 0)


def moabb_annotations_include_interval_offset() -> bool:
    """True when the installed MOABB writes annotations at
    ``trial_onset + interval[0]`` (i.e. at the task/cue onset)."""
    return _moabb_version() >= MOABB_ANNOTATION_FIX_VERSION


def resolve_cue_offset(dataset_name: str, moabb_interval, source: str = "moabb",
                        override: float | None = None, verbose: bool = True) -> float:
    """Seconds to add to a CUE-relative epoch window to land on the annotation.

    source='moabb'  -> apply the version rule described in the module docstring.
    source='direct' -> the loader builds its own annotations from the raw
                       trigger channel or EDF+ markers, which sit at the cue,
                       so the offset is 0 regardless of MOABB.
    override        -> force a value (use when you have verified the alignment
                       empirically and want to pin it).
    """
    if override is not None:
        if verbose:
            print(f"[cue offset] {dataset_name}: {override:+.2f}s (manual override)")
        return float(override)

    if source == "direct" or not moabb_interval:
        if verbose:
            print(f"[cue offset] {dataset_name}: +0.00s "
                  f"(annotations built directly at cue onset)")
        return 0.0

    interval_start = float(moabb_interval[0])
    if interval_start == 0.0:
        if verbose:
            print(f"[cue offset] {dataset_name}: +0.00s (MOABB interval starts at 0)")
        return 0.0

    if moabb_annotations_include_interval_offset():
        if verbose:
            print(f"[cue offset] {dataset_name}: +0.00s -- MOABB "
                  f"{'.'.join(map(str, _moabb_version()))} >= 1.1 already places "
                  f"annotations at onset+interval[0] ({interval_start}s).")
        return 0.0

    if verbose:
        print(f"[cue offset] {dataset_name}: {interval_start:+.2f}s -- MOABB "
              f"{'.'.join(map(str, _moabb_version()))} < 1.1 writes annotations at the "
              f"TRIAL onset, and this dataset's task window starts {interval_start}s "
              "later (MOABB PR #607). Without this shift the 'imagery' epoch would "
              "be the fixation/cue period.")
    return interval_start


def apply_cue_offsets(registry, overrides: dict | None = None, verbose: bool = True) -> dict:
    """Resolve and write ``cue_offset_sec`` onto every enabled DatasetConfig.
    Call once, right after building the registry, before anything epochs."""
    overrides = overrides or {}
    direct = {"physionet", "lee2019"}   # loaders that build their own annotations
    out = {}
    for cfg in registry.enabled():
        cfg.cue_offset_sec = resolve_cue_offset(
            cfg.name, cfg.moabb_interval,
            source="direct" if cfg.name in direct else "moabb",
            override=overrides.get(cfg.name), verbose=verbose)
        out[cfg.name] = cfg.cue_offset_sec
    return out


def describe_annotation_timing(raw: mne.io.BaseRaw, event_id: dict, label: str = "") -> dict:
    """Empirical cross-check on the resolved offset.

    MOABB sets the annotation DURATION to ``interval[1] - interval[0]``
    regardless of version, so a duration that matches the declared post-cue
    trial length is consistent with the annotation marking the task window;
    the median inter-onset interval tells you the true trial period. Neither
    proves the onset placement on its own, which is why the version rule is
    the primary mechanism -- but a mismatch here means something is wrong.
    """
    ann = raw.annotations
    keep = [i for i, d in enumerate(ann.description) if d in event_id]
    onsets = np.asarray(ann.onset)[keep]
    durations = np.asarray(ann.duration)[keep]
    info = {
        "dataset": label,
        "n_matching_annotations": len(keep),
        "median_duration_sec": float(np.median(durations)) if len(durations) else float("nan"),
        "median_inter_onset_sec": float(np.median(np.diff(onsets))) if len(onsets) > 1 else float("nan"),
        "first_onset_sec": float(onsets[0]) if len(onsets) else float("nan"),
        "descriptions_present": sorted(set(ann.description)),
    }
    return info


# --------------------------------------------------------------------------
# PhysioNet EEGMMIDB (local EDF+)
# --------------------------------------------------------------------------

def resolve_physionet_edf_path(subject: int, run: int, root: Path = PHYSIONET_ROOT) -> Path:
    fname = f"S{subject:03d}R{run:02d}.edf"
    root = Path(root)
    for path in (root / f"S{subject:03d}" / fname, root / fname):
        if path.exists():
            return path
    raise FileNotFoundError(
        f"Could not find {fname} under {root}. Check PHYSIONET_ROOT and folder structure.")


def load_physionet_raw(subject: int, run: int, root: Path = PHYSIONET_ROOT, preload: bool = True):
    import os
    root = Path(os.environ.get("PHYSIONET_ROOT", root))
    return mne.io.read_raw_edf(resolve_physionet_edf_path(subject, run, root),
                               preload=preload, verbose=False)


def get_physionet_channel_info(subject: int = 1, run: int = 1, root: Path = PHYSIONET_ROOT):
    raw = load_physionet_raw(subject, run, root=root, preload=False)
    return list(raw.info["ch_names"]), list(raw.get_channel_types()), float(raw.info["sfreq"])


def load_physionet_subject_runs(subject: int, root: Path = PHYSIONET_ROOT,
                                 allow_anomalous: bool = False) -> list:
    """The 3 unilateral-imagery runs (4, 8, 12) as separate un-concatenated Raws.

    Raises on subjects 88/89/92/100 by default: 88/92/100 were recorded at
    128 Hz with shifted 5.125 s/1.375 s task/rest timing, and 89 has reported
    annotation errors."""
    if subject in PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS and not allow_anomalous:
        raise ValueError(
            f"Subject {subject} has a documented data-quality anomaly: "
            f"{PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS[subject]}. Skip it, or pass "
            "allow_anomalous=True to opt in deliberately.")
    return [load_physionet_raw(subject, run, root=root)
            for run in PHYSIONET_UNILATERAL_IMAGERY_RUNS]


# --------------------------------------------------------------------------
# Cho2017
# --------------------------------------------------------------------------

def get_cho2017_channel_info(subject: int = 1):
    from moabb.datasets import Cho2017
    data = Cho2017().get_data(subjects=[subject])[subject]
    session_key = next(iter(data))
    raw = data[session_key][next(iter(data[session_key]))]
    return list(raw.info["ch_names"]), list(raw.get_channel_types()), float(raw.info["sfreq"])


def load_cho2017_subject_runs(subject: int) -> list:
    from moabb.datasets import Cho2017
    data = Cho2017().get_data(subjects=[subject])[subject]
    return [data[s][r].copy().pick(picks="eeg") for s in data for r in data[s]]


# --------------------------------------------------------------------------
# Lee2019 / OpenBMI
# --------------------------------------------------------------------------

LEE2019_STIM_EVENT_DESC = {1: "left_hand", 2: "right_hand"}


def _lee2019_attach_annotations(raw: mne.io.BaseRaw) -> mne.io.BaseRaw:
    """OpenBMI recordings carry their trial markers on an ``STI 014`` stim
    channel rather than as Annotations. Convert them, then drop the auxiliary
    EMG/stim channels. Folded in from the notebook's runtime patch."""
    raw = raw.copy()
    if "STI 014" in raw.ch_names:
        events = mne.find_events(raw, stim_channel="STI 014", shortest_event=1, verbose=False)
        if len(events):
            raw.set_annotations(mne.annotations_from_events(
                events=events, sfreq=raw.info["sfreq"],
                event_desc=LEE2019_STIM_EVENT_DESC))
    drop = [ch for ch in ("EMG1", "EMG2", "EMG3", "EMG4", "STI 014", "Stim")
            if ch in raw.ch_names]
    if drop:
        raw.drop_channels(drop)
    return raw


def load_lee2019_subject_runs(subject: int, path: str | None = None,
                               sessions=(1, 2)) -> list:
    """train_run (offline phase) recordings for this subject, one Raw per
    session, un-concatenated.

    The online/test_run phase is excluded by config: it carries continuous
    visual feedback inside the trial, so post-cue activity there is partly a
    response to the feedback cross.

    NOTE on sessions: this MOABB version's BIDS refactor writes sessions
    0-indexed ('ses-0'), so ``sessions=[0, 1]``. The older ``sessions=[1]``
    silently filtered out the only session that was written.
    """
    from moabb.datasets import Lee2019_MI
    dataset = Lee2019_MI(train_run=True, test_run=False, sessions=list(sessions))
    data = dataset.get_data(subjects=[subject],
                            cache_config=dict(path=path, save_raw=True))[subject]
    if not data:
        raise RuntimeError(
            f"Lee2019 subject {subject}: get_data() returned no sessions/runs. "
            "Check the session folder names under your cache ('ses-0' vs 'ses-1').")
    raws = []
    for s in data:
        for r in data[s]:
            raws.append(_lee2019_attach_annotations(data[s][r]).pick(picks="eeg"))
    return raws


def get_lee2019_channel_info(subject: int = 1, path: str | None = None):
    raws = load_lee2019_subject_runs(subject, path=path, sessions=(1,))
    raw = raws[0]
    return list(raw.info["ch_names"]), list(raw.get_channel_types()), float(raw.info["sfreq"])


def make_lee2019_loader(path: str):
    def _loader(subject: int) -> list:
        return load_lee2019_subject_runs(subject, path=path)
    return _loader


def make_lee2019_channel_info_fn(path: str, subject: int = 1):
    def _channel_info() -> list:
        return get_lee2019_channel_info(subject=subject, path=path)[0]
    return _channel_info


def discover_lee2019_local_subjects(root_path: str) -> dict:
    """Scan a local Lee2019/OpenBMI tree for whichever subject/session files
    exist. Returns {subject_id: sorted[session_ids]}."""
    import re
    pattern = re.compile(
        r"(?:subj|sub)-?0*(\d+).*?(?:sess|ses)-?0*(\d+)"
        r"|(?:sess|ses)-?0*(\d+).*?(?:subj|sub)-?0*(\d+)", re.IGNORECASE)
    found, root = {}, Path(root_path)
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        m = pattern.search(str(p.relative_to(root)))
        if not m:
            continue
        g = m.groups()
        subj, sess = (int(g[0]), int(g[1])) if g[0] is not None else (int(g[3]), int(g[2]))
        found.setdefault(subj, set()).add(sess)
    result = {s: sorted(sess) for s, sess in sorted(found.items())}
    print(f"Discovered {len(result)} subject(s) under {root_path}: {result}")
    return result


# --------------------------------------------------------------------------
# BNCI2014_001 / Weibo2014 / Dreyer2023
# --------------------------------------------------------------------------

def _moabb_channel_info(dataset, subject: int = 1):
    data = dataset.get_data(subjects=[subject])[subject]
    session_key = next(iter(data))
    raw = data[session_key][next(iter(data[session_key]))]
    return list(raw.info["ch_names"]), list(raw.get_channel_types()), float(raw.info["sfreq"])


def _moabb_all_runs(dataset, subject: int, run_filter=None) -> list:
    data = dataset.get_data(subjects=[subject])[subject]
    raws = []
    for s in data:
        for r in data[s]:
            if run_filter is not None and not run_filter(str(r)):
                continue
            raws.append(data[s][r].copy().pick(picks="eeg"))
    if not raws:
        raise RuntimeError(f"No runs survived the run filter for subject {subject}.")
    return raws


def get_bnci2014001_channel_info(subject: int = 1):
    from moabb.datasets import BNCI2014_001
    return _moabb_channel_info(BNCI2014_001(), subject)


def load_bnci2014001_subject_runs(subject: int) -> list:
    """All runs from both sessions (2 x 6), EEG only, un-concatenated."""
    from moabb.datasets import BNCI2014_001
    return _moabb_all_runs(BNCI2014_001(), subject)


def get_weibo2014_channel_info(subject: int = 1):
    from moabb.datasets import Weibo2014
    return _moabb_channel_info(Weibo2014(), subject)


def load_weibo2014_subject_runs(subject: int) -> list:
    """All runs of the single session, EEG only. The other five classes
    (hands, feet, the two compound conditions, rest) stay in the annotations
    but are never selected, because the config's event_id names only
    left_hand/right_hand."""
    from moabb.datasets import Weibo2014
    return _moabb_all_runs(Weibo2014(), subject)


def get_dreyer2023_channel_info(subject: int = 1):
    from moabb.datasets import Dreyer2023
    return _moabb_channel_info(Dreyer2023(), subject)


def load_dreyer2023_subject_runs(subject: int, acquisition_only: bool = False) -> list:
    """All 6 runs of the single session, EEG only.

    ``acquisition_only=True`` keeps only the first two runs. Those are the
    *calibration* runs, in which the feedback bar is sham -- it is not driven
    by the online classifier. In the four training runs the bar IS driven by
    the online LDA from t = cue+1.25 s, so its visually evoked response is
    correlated with the trial label and any epoch extending past +1.25 s is
    partly decoding the feedback rather than the imagery. Use this flag if
    your epoch window reaches beyond +1.25 s.
    """
    from moabb.datasets import Dreyer2023
    run_filter = None
    if acquisition_only:
        def run_filter(name: str) -> bool:
            return ("R1" in name) or ("R2" in name)
    return _moabb_all_runs(Dreyer2023(), subject, run_filter=run_filter)


def make_dreyer2023_loader(acquisition_only: bool = False):
    def _loader(subject: int) -> list:
        return load_dreyer2023_subject_runs(subject, acquisition_only=acquisition_only)
    return _loader
