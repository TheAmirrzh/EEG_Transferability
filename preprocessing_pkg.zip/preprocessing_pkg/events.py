"""Event extraction, generalized across datasets.

Every dataset's raw exposes its trial markers as mne Annotations (PhysioNet's
EDF+ markers, MOABB's SetRawAnnotations output, or -- for Lee2019 -- the
STI 014 triggers converted in io_loaders). One function covers all of them; the
only thing that varies is which event_id dict a given DatasetConfig declares.

`cue_offset_sec` is NOT applied here. It belongs to the epoching step
(signal_processing._epoch_concat), because it shifts the analysis window, not
the events themselves.
"""

from __future__ import annotations
import mne


def get_dataset_events(raw: mne.io.BaseRaw, event_id: dict):
    """Extract (events, event_id) for any dataset's raw, given that dataset's
    own event_id dict. The caller is responsible for having restricted `raw` to
    valid runs/phases (see io_loaders)."""
    events, resolved = mne.events_from_annotations(raw, event_id=event_id, verbose=False)
    if len(events) == 0:
        raise RuntimeError(
            f"No annotation matched event_id={event_id}. Descriptions present in this "
            f"recording: {sorted(set(raw.annotations.description))}")
    return events, resolved
