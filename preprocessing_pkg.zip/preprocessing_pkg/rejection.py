"""Trial-level (AutoReject) and channel-level rejection ablations.

Both fit entirely from one subject's own data, so both are leakage-safe by
construction, and both stay OUT of the primary pipeline by design.

Mask-awareness matters here more than anywhere else: a masked channel is
exactly zero, so a naive variance-based bad-channel detector flags every one of
them as "flat" and then interpolates them -- which silently converts
reference_masked mode back into union mode, undoing the entire point of
masking. The detector now only ever looks at, and only ever interpolates,
channels the mask marks as real.
"""

from __future__ import annotations
import numpy as np
import mne

from .signal_processing import (
    preprocess_raw, set_common_average_reference, make_epochs, _as_list,
    get_channel_mask, _concat_preserving_mask, _epoch_concat, _filter_resample_concat,
)


def apply_autoreject_trial_rejection(epochs: mne.Epochs, random_state: int = 42):
    """Robust, data-driven trial rejection -- SECONDARY ABLATION ONLY.

    Restricted to real channels: AutoReject estimates per-channel peak-to-peak
    thresholds by cross-validation, and a channel that is identically zero has
    a degenerate threshold distribution that can dominate the fit.
    """
    from autoreject import AutoReject
    mask = get_channel_mask(epochs)
    work = epochs
    if mask is not None and not mask.all():
        work = epochs.copy().pick([c for c, m in zip(epochs.ch_names, mask) if m])
    ar = AutoReject(n_interpolate=[1, 2, 4], random_state=random_state,
                    n_jobs=1, verbose=False)
    _, reject_log = ar.fit_transform(work, return_log=True)
    keep = ~reject_log.bad_epochs
    n_rejected = int(reject_log.bad_epochs.sum())
    print(f"[AutoReject ablation] Rejected {n_rejected}/{len(epochs)} trials "
          f"({100 * n_rejected / max(len(epochs), 1):.1f}%).")
    # Apply the trial-level decision to the FULL channel set, so the tensor
    # keeps its shared dimensionality and its mask.
    return epochs[keep], reject_log


def run_secondary_autoreject_pipeline(raws, channel_mapping_df, common_channels, montage,
                                       event_id, epoch_window, baseline=None,
                                       mode="reference_masked", car_scope_channels=None,
                                       cue_offset_sec=0.0, target_sfreq=128.0,
                                       bandpass=(8.0, 30.0), trans_bandwidth=2.0,
                                       cache_key: str | None = None):
    """Filter+resample per run (required), concatenate and CAR ONCE per
    subject. AutoReject itself was already fit once on the full concatenated
    Epochs object -- no change there -- this only removes the redundant
    per-run CAR calls that used to precede the concatenation.
    """
    raw_concat = _filter_resample_concat(raws, channel_mapping_df, common_channels, montage,
                                         bandpass, target_sfreq, mode, trans_bandwidth)
    raw_car = set_common_average_reference(raw_concat, car_scope_channels)
    epochs = _epoch_concat(raw_car, event_id, epoch_window, baseline, cue_offset_sec)
    return apply_autoreject_trial_rejection(epochs)


def detect_and_interpolate_bad_channels(raw: mne.io.BaseRaw, flat_thresh: float = 1e-13,
                                         noisy_z: float = 5.0) -> mne.io.BaseRaw:
    """Variance-based bad-channel detection + spherical-spline interpolation --
    SECONDARY ABLATION ONLY, fitted from this one subject's own recording.

    Only real channels are considered and only real channels are interpolated.
    Without that restriction every masked channel looks flat, gets flagged, and
    gets interpolated -- which quietly turns masking into interpolation.

    The threshold is a robust z on the variance (median/MAD), not a mean/std z,
    so one genuinely broken channel cannot inflate the scale enough to hide
    itself.
    """
    raw = raw.copy()
    mask = get_channel_mask(raw)
    names = list(raw.ch_names)
    real = [n for i, n in enumerate(names) if mask is None or mask[i]]
    if not real:
        return raw

    data = raw.copy().pick(real).get_data()
    var = data.var(axis=1)
    med = np.median(var)
    mad = np.median(np.abs(var - med)) + 1e-30
    flat = [real[i] for i, v in enumerate(var) if v < flat_thresh]
    noisy = [real[i] for i, v in enumerate(var) if abs(v - med) / mad > noisy_z]
    bads = sorted(set(flat) | set(noisy))

    if bads:
        if len(bads) > 0.3 * len(real):
            print(f"[Channel-rejection ablation] {len(bads)}/{len(real)} real channels "
                  "flagged -- that is too many to be bad electrodes; refusing to "
                  "interpolate a third of the montage. Leaving the recording untouched.")
            return raw
        raw.info["bads"] = bads
        print(f"[Channel-rejection ablation] Interpolating {len(bads)} bad channel(s): {bads}")
        raw.interpolate_bads(reset_bads=True, exclude=[n for n in names if n not in real],
                             verbose=False)
    else:
        print("[Channel-rejection ablation] No bad channels detected.")
    return raw


def run_secondary_channel_rejection_pipeline(raws, channel_mapping_df, common_channels,
                                              montage, event_id, epoch_window, baseline=None,
                                              mode="reference_masked", car_scope_channels=None,
                                              cue_offset_sec=0.0, target_sfreq=128.0,
                                              bandpass=(8.0, 30.0), trans_bandwidth=2.0,
                                              cache_key: str | None = None):
    """Bad-channel interpolation inserted after harmonization and BEFORE the
    reference: a bad channel left in would otherwise corrupt the average for
    every other channel.

    Detection now runs ONCE on the full concatenated recording rather than
    once per run: cheaper, and a variance-based flat/noisy detector is also
    more reliable with more data behind its median/MAD estimate than it is on
    one short run at a time.
    """
    raw_concat = _filter_resample_concat(raws, channel_mapping_df, common_channels, montage,
                                         bandpass, target_sfreq, mode, trans_bandwidth)
    raw_interp = detect_and_interpolate_bad_channels(raw_concat)
    raw_car = set_common_average_reference(raw_interp, car_scope_channels)
    return _epoch_concat(raw_car, event_id, epoch_window, baseline, cue_offset_sec)
