"""Global + per-dataset configuration.

Design goal unchanged: the shared channel set is never a hardcoded number, it
is always recomputed from whichever DatasetConfig objects are enabled right
now, under whichever HARMONIZATION_MODE is configured.

WHAT CHANGED IN THIS REVISION
-----------------------------
1. ``GlobalConfig.HARMONIZATION_MODE`` -- 'reference_masked' (new default),
   'union' (previous behaviour) or 'intersection'. See channels.py.
   ``ANCHOR_DATASETS`` names the datasets whose intersection defines the
   reference space in 'reference_masked' mode.

2. ``GlobalConfig.CAR_SCOPE`` -- which channels the common average reference
   is computed over. The average reference is an estimate of the potential at
   infinity, and that estimate depends on how the scalp is sampled (Ferree
   2006, Brain Topogr 19:43). Two datasets with different montages therefore
   get *different* reference operators, which is a silent cross-dataset
   confound. 'shared_support' restricts the average to channels every enabled
   dataset really recorded, making the operator identical everywhere.

3. ``DatasetConfig.cue_offset_sec`` -- seconds from the annotation onset to
   the actual start of the motor-imagery period. This is THE correctness fix
   in this revision: several MOABB datasets annotate the *trial* onset, not
   the cue, and MOABB itself carries the difference in its ``interval``
   attribute rather than in the annotations. See io_loaders.resolve_cue_offset.

4. ``DatasetConfig.pre_cue_clean_sec`` / ``feedback_onset_sec`` -- how much
   clean pre-cue signal exists for baselining, and when (if ever) online
   visual feedback starts contaminating the post-cue window.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional


# --------------------------------------------------------------------------
# 1. Global, dataset-agnostic configuration
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class GlobalConfig:
    TARGET_SFREQ: float = 128.0
    EXPECTED_TIME_SAMPLES: int = 256
    BANDPASS: tuple[float, float] = (8.0, 30.0)
    # Explicit transition bandwidths. MNE's 'auto' picks these from the data
    # and they silently determine the FIR filter length -- which is exactly
    # the quantity the temporal-leakage audit needs to reason about, so it is
    # pinned here rather than left implicit.
    FIR_TRANS_BANDWIDTH: float = 2.0
    MONTAGE_NAME: str = "standard_1005"
    RANDOM_STATE: int = 42

    # ---- channel harmonization -------------------------------------------
    # 'reference_masked' | 'union' | 'intersection'
    HARMONIZATION_MODE: str = "reference_masked"
    # Only used by 'reference_masked'. These are the well-covered, high-density
    # datasets whose shared electrodes define the target space (~62 channels).
    ANCHOR_DATASETS: tuple = ("physionet", "cho2017")
    # 'native'        -> CAR over whatever that dataset recorded (classic, but
    #                    a different operator per montage)
    # 'shared_support'-> CAR over channels present in EVERY enabled dataset
    #                    (identical operator everywhere; recommended when
    #                    pooling datasets)
    CAR_SCOPE: str = "shared_support"

    # ---- performance --------------------------------------------------
    # Worker count for build_cohort's per-(dataset, subject) joblib pool.
    # Kept modest by default to avoid oversubscribing Colab's cores once
    # each worker's own BLAS/MNE filtering threads are counted; raise it on
    # a machine with more cores, or pass build_cohort(..., n_jobs=...) to
    # override per call without touching this default.
    COHORT_N_JOBS: int = 4

    # ---- Hilbert / envelope ----------------------------------------------
    # Extra REAL signal epoched on either side of the display window, used as
    # margin for the analytic-signal transform and cropped away afterwards.
    # Synthetic (reflection) padding is deliberately NOT the mechanism: for
    # narrowband oscillations it is measurably worse than no padding at all,
    # because it turns a value discontinuity into a slope cusp. See
    # signal_processing.analytic_envelope for the numbers.
    ENVELOPE_MARGIN_SEC: float = 1.0

    # ---- epoch windows ----------------------------------------------------
    # Primary window: 1.0 s post-CUE -> exactly EXPECTED_TIME_SAMPLES samples
    # at TARGET_SFREQ. Recomputed, never hardcoded. NOTE: tmin/tmax here are
    # relative to the CUE, and the per-dataset cue_offset_sec is added at
    # epoching time -- they are not relative to the raw annotation.
    @property
    def PRIMARY_EPOCH_WINDOW(self) -> dict:
        tmin = 1.0
        tmax = tmin + (self.EXPECTED_TIME_SAMPLES - 1) / self.TARGET_SFREQ
        return dict(tmin=tmin, tmax=tmax)

    PRIMARY_BASELINE: Optional[tuple] = None

    # Display window for ERD/ERS work. tmax is 2.0 s rather than 3.0 s so that
    # a full ENVELOPE_MARGIN_SEC of real signal still fits inside Cho2017's
    # 3.0 s post-cue trial -- the binding constraint across the six datasets.
    BASELINE_ABLATION_EPOCH_WINDOW: dict = field(
        default_factory=lambda: dict(tmin=-0.5, tmax=2.0))
    BASELINE_ABLATION_BASELINE: tuple = (-0.5, -0.05)
    # ^ ends at -0.05 s, not 0.0: with a zero-phase FIR band-pass the cue-locked
    #   transient is symmetric about the cue, so the last samples before t=0
    #   already contain post-cue energy.

    EPOCH_WINDOW_ABLATION_GRID: list = field(default_factory=lambda: [
        dict(tmin=0.0, tmax=2.0, note="no post-cue exclusion (naive baseline)"),
        dict(tmin=0.5, tmax=2.5, note="exclude earliest visual-evoked transient"),
        dict(tmin=1.0, tmax=1.0 + 255 / 128.0, note="primary-pipeline default"),
        dict(tmin=0.5, tmax=0.5 + 255 / 128.0, note="early window, Dreyer-feedback-safe"),
    ])
    # ^ all four are now the SAME duration (2.0 s) except where noted, so the
    #   grid varies onset only. The previous grid mixed 3.0 s and 2.0 s windows,
    #   which confounds "later start" with "more data" -- a longer window gives
    #   CSP more samples per covariance estimate and wins for that reason alone.

    # ---- evaluation -------------------------------------------------------
    CV_FOLDS: int = 5
    # 'subject'    -> EA reference fitted on each subject's own trials,
    #                 including test-fold ones. This is the standard,
    #                 explicitly transductive formulation (He & Wu 2020) and
    #                 is label-free, but it does touch test data.
    # 'train_only' -> reference fitted on training-fold subjects only.
    EA_SCOPE: str = "subject"


# --------------------------------------------------------------------------
# 2. Per-dataset configuration
# --------------------------------------------------------------------------

@dataclass
class DatasetConfig:
    name: str
    enabled: bool
    n_subjects: int
    n_sessions: int
    native_sfreq: float
    event_id: dict
    label_map: dict
    loader_fn: Callable
    channel_info_fn: Callable
    valid_runs_or_phases: list
    trial_length_sec: float          # usable post-CUE signal per trial
    cue_offset_sec: float = 0.0      # annotation onset -> cue onset
    pre_cue_clean_sec: float = 0.0   # clean signal available before the cue
    feedback_onset_sec: float | None = None   # post-cue time at which online
                                               # visual feedback starts, if any
    moabb_interval: tuple | None = None        # the dataset's own MOABB
                                                # `interval`, for cue-offset
                                                # resolution and auditing
    excluded: dict = field(default_factory=dict)
    excluded_subjects: dict = field(default_factory=dict)
    notes: str = ""

    def get_channel_names(self) -> list[str]:
        return self.channel_info_fn()

    def shifted_window(self, window: dict) -> dict:
        """Translate a cue-relative window into an annotation-relative one."""
        return dict(tmin=window["tmin"] + self.cue_offset_sec,
                    tmax=window["tmax"] + self.cue_offset_sec)


# --------------------------------------------------------------------------
# 3. Registry
# --------------------------------------------------------------------------

class DatasetRegistry:
    """Holds every configured dataset; the shared channel set is always
    derived, live, from whichever ones are enabled right now."""

    def __init__(self, *configs: DatasetConfig):
        self._configs = {c.name: c for c in configs}

    def __getitem__(self, name: str) -> DatasetConfig:
        return self._configs[name]

    def enabled(self) -> list[DatasetConfig]:
        active = [c for c in self._configs.values() if c.enabled]
        if len(active) < 2:
            raise ValueError(
                "Need at least 2 enabled datasets to compute a shared channel "
                f"set; currently enabled: {[c.name for c in active]}")
        return active

    def enable_only(self, *names: str) -> None:
        for c in self._configs.values():
            c.enabled = c.name in names

    # -- the three strategies, all reachable through one method -------------

    def _name_sets(self, standardize_fn) -> dict:
        from .channels import is_scalp_eeg
        return {
            c.name: {standardize_fn(ch) for ch in c.get_channel_names()
                     if is_scalp_eeg(standardize_fn(ch))}
            for c in self.enabled()
        }

    def compute_channels(self, standardize_fn: Callable[[str], str],
                          mode: str = "reference_masked",
                          anchor_datasets=None) -> tuple[list, dict]:
        """Returns (target_channels_sorted, per_dataset_name_sets)."""
        per_dataset = self._name_sets(standardize_fn)
        if mode == "union":
            target = set.union(*per_dataset.values())
        elif mode == "intersection":
            target = set.intersection(*per_dataset.values())
        elif mode == "reference_masked":
            anchors = [a for a in (anchor_datasets or []) if a in per_dataset]
            if not anchors:
                raise ValueError(
                    f"No anchor dataset from {anchor_datasets} is enabled "
                    f"(enabled: {sorted(per_dataset)}).")
            target = set.intersection(*[per_dataset[a] for a in anchors])
        else:
            raise ValueError(f"Unknown harmonization mode {mode!r}")
        return sorted(target), per_dataset

    # Backwards-compatible thin wrappers --------------------------------
    def compute_common_channels(self, standardize_fn):
        return self.compute_channels(standardize_fn, mode="intersection")

    def compute_target_channels(self, standardize_fn):
        return self.compute_channels(standardize_fn, mode="union")

    def summary_table_rows(self, standardize_fn, mode: str = "reference_masked",
                            anchor_datasets=None) -> list[dict]:
        target, per_dataset = self.compute_channels(
            standardize_fn, mode=mode, anchor_datasets=anchor_datasets)
        target_set = set(target)
        rows = []
        for c in self.enabled():
            names = per_dataset[c.name]
            retained = names & target_set
            dropped = names - target_set      # real channels not in the target
            missing = target_set - names      # target channels not recorded
            rows.append(dict(
                dataset=c.name,
                native_sfreq=c.native_sfreq,
                native_ch_count=len(names),
                retained_ch_count=len(retained),
                dropped_count=len(dropped),
                dropped=sorted(dropped),
                missing_count=len(missing),
                missing=sorted(missing),
                # kept for older callers
                synthesized_count=len(missing) if mode == "union" else 0,
                drop_rate=(len(dropped) / len(names)) if names else 0.0,
            ))
        return rows

    # -- window validation --------------------------------------------------

    def validate_epoch_windows(self, glob: "GlobalConfig") -> bool:
        """Every declared window (primary, ablation grid, baseline-ablation)
        is checked PER DATASET against that dataset's own post-cue trial
        length and available pre-cue signal -- not against a single global
        minimum, and not against annotation-relative time.

        The old version compared cue-relative windows to the global minimum
        trial length only, which both over-rejected (a window fine for 5 of 6
        datasets failed because of the 6th) and under-checked (a negative tmin
        was never tested against the available pre-cue signal at all).
        """
        windows = {
            "PRIMARY_EPOCH_WINDOW": glob.PRIMARY_EPOCH_WINDOW,
            "BASELINE_ABLATION_EPOCH_WINDOW": glob.BASELINE_ABLATION_EPOCH_WINDOW,
            **{f"EPOCH_WINDOW_ABLATION_GRID[{i}]": w
               for i, w in enumerate(glob.EPOCH_WINDOW_ABLATION_GRID)},
        }
        problems, warnings_ = [], []
        for cfg in self.enabled():
            for label, w in windows.items():
                if w["tmax"] > cfg.trial_length_sec + 1e-9:
                    problems.append(
                        f"  {cfg.name}: {label} tmax={w['tmax']:.3f}s exceeds its "
                        f"{cfg.trial_length_sec}s post-cue trial length.")
                if w["tmin"] < -cfg.pre_cue_clean_sec - 1e-9:
                    problems.append(
                        f"  {cfg.name}: {label} tmin={w['tmin']:.3f}s reaches further "
                        f"back than its {cfg.pre_cue_clean_sec}s of clean pre-cue signal.")
                if (cfg.feedback_onset_sec is not None
                        and w["tmax"] > cfg.feedback_onset_sec + 1e-9):
                    warnings_.append(
                        f"  {cfg.name}: {label} extends to {w['tmax']:.3f}s, past the "
                        f"{cfg.feedback_onset_sec}s onset of online visual feedback. "
                        "Feedback is driven by the online classifier, so its visual "
                        "response is correlated with the label -- decoding from this "
                        "window partly decodes the feedback bar, not the imagery.")
        if problems:
            raise AssertionError(
                "Epoch-window validation failed:\n" + "\n".join(problems))
        for w in warnings_:
            print("WARNING (confound, not an error):\n" + w)
        print(f"All epoch windows validated per-dataset against each dataset's own "
              f"trial length and pre-cue budget ({[c.name for c in self.enabled()]}).")
        return True

    def cue_alignment_table(self):
        """Prints the cue-offset bookkeeping. Read this before trusting any
        cross-dataset comparison: an unnoticed offset means one dataset's
        'motor imagery window' is actually its fixation cross."""
        import pandas as pd
        rows = [{
            "dataset": c.name,
            "moabb_interval": str(c.moabb_interval),
            "cue_offset_sec": c.cue_offset_sec,
            "post-cue trial length (s)": c.trial_length_sec,
            "clean pre-cue (s)": c.pre_cue_clean_sec,
            "feedback onset (s post-cue)": c.feedback_onset_sec,
        } for c in self.enabled()]
        df = pd.DataFrame(rows)
        print("\n================= CUE-ONSET ALIGNMENT =================")
        print(df.to_string(index=False))
        print("cue_offset_sec is added to every cue-relative epoch window "
              "before slicing, so tmin=1.0 always means 1.0 s after the "
              "imagery cue for every dataset.")
        print("=" * 55 + "\n")
        return df


# --------------------------------------------------------------------------
# 4. PhysioNet EEGMMIDB
# --------------------------------------------------------------------------

PHYSIONET_ROOT = Path("eegmmidb")
PHYSIONET_UNILATERAL_IMAGERY_RUNS = [4, 8, 12]

PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS = {
    88: "recorded at 128 Hz (not 160 Hz) with shifted 5.125s/1.375s task/rest timing",
    89: "independently reported incorrect/mislabeled event annotations",
    92: "recorded at 128 Hz (not 160 Hz) with shifted 5.125s/1.375s task/rest timing",
    100: "recorded at 128 Hz (not 160 Hz) with shifted 5.125s/1.375s task/rest timing",
}
PHYSIONET_EXCLUDED_RUNS = {
    1: "baseline, eyes open", 2: "baseline, eyes closed",
    3: "executed movement (unilateral) - not imagery",
    5: "executed movement (bilateral fists/feet) - not imagery, not unilateral",
    6: "imagined movement (bilateral fists/feet) - not unilateral",
    7: "executed movement (unilateral) - not imagery",
    9: "executed movement (bilateral fists/feet) - not imagery, not unilateral",
    10: "imagined movement (bilateral fists/feet) - not unilateral",
    11: "executed movement (unilateral) - not imagery",
    13: "executed movement (bilateral fists/feet) - not imagery, not unilateral",
    14: "imagined movement (bilateral fists/feet) - not unilateral",
}


def make_physionet_config(loader_fn, channel_info_fn, enabled=True) -> DatasetConfig:
    return DatasetConfig(
        name="physionet",
        enabled=enabled,
        n_subjects=109,
        n_sessions=1,
        native_sfreq=160.0,
        event_id={"T1": 1, "T2": 2},   # runs 4/8/12: T1=left fist, T2=right fist
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=PHYSIONET_UNILATERAL_IMAGERY_RUNS,
        trial_length_sec=4.0,
        cue_offset_sec=0.0,      # EDF+ T1/T2 annotations mark the cue itself
        pre_cue_clean_sec=2.0,   # preceded by a T0 rest block (~4.2 s)
        feedback_onset_sec=None,
        moabb_interval=(0.0, 3.0),
        excluded=PHYSIONET_EXCLUDED_RUNS,
        excluded_subjects=PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS,
        notes="Read from local EDF+, not through MOABB, so annotations are the "
              "native T0/T1/T2 markers placed at cue onset (duration ~4.1 s). "
              "MOABB's own PhysionetMI uses the more conservative interval "
              "[0, 3]; 4.0 s here is the outer bound of the BCI2000 task period.",
    )


# --------------------------------------------------------------------------
# 5. Cho2017 (GigaDB)
# --------------------------------------------------------------------------

def make_cho2017_config(loader_fn, channel_info_fn, enabled=True) -> DatasetConfig:
    return DatasetConfig(
        name="cho2017",
        enabled=enabled,
        n_subjects=52,
        n_sessions=1,
        native_sfreq=512.0,
        event_id={"left_hand": 1, "right_hand": 2},
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=["all"],
        trial_length_sec=3.0,
        cue_offset_sec=0.0,      # MOABB interval [0, 3] -> annotation IS the cue
        pre_cue_clean_sec=2.0,   # 2 s fixation cross precedes every trial
        feedback_onset_sec=None, # feedback only between runs, never within a trial
        moabb_interval=(0.0, 3.0),
        excluded={},
        excluded_subjects={},
        notes="Trial: 2 s fixation, 3 s left/right-hand instruction, then a random "
              "4.1-4.8 s break (MOABB gigadb.py). 3.0 s is the binding post-cue "
              "constraint across all six datasets. Subjects s20/s33 are both-handed "
              "rather than right-handed -- not excluded, but worth knowing if they "
              "behave as outliers. Per-trial `bad_trial_indices` from the original "
              "authors' own QC are wired in via cho2017_qc.py.",
    )


# --------------------------------------------------------------------------
# 6. Lee2019 / OpenBMI
# --------------------------------------------------------------------------

def make_lee2019_config(loader_fn, channel_info_fn, enabled=True) -> DatasetConfig:
    return DatasetConfig(
        name="lee2019",
        enabled=enabled,
        n_subjects=54,
        n_sessions=2,
        native_sfreq=1000.0,
        event_id={"left_hand": 1, "right_hand": 2},
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=["train_run"],
        trial_length_sec=4.0,
        cue_offset_sec=0.0,      # MOABB interval [0, 4]; the STI 014 trigger
                                  # used by the direct loader is the cue itself
        pre_cue_clean_sec=3.0,   # 3 s fixation cross
        feedback_onset_sec=None, # offline (train_run) phase has no feedback
        moabb_interval=(0.0, 4.0),
        excluded={"test_run": "online/test phase carries continuous feedback, so "
                              "post-cue activity there is partly a response to the "
                              "feedback cross rather than to the imagery"},
        excluded_subjects={},
        notes="Trial: 3 s fixation, 4 s cued grasping imagery, 6 +/- 1.5 s blank rest.",
    )


# --------------------------------------------------------------------------
# 7. BNCI2014_001 (BCI Competition IV-2a) -- CC BY-ND 4.0
# --------------------------------------------------------------------------

def make_bnci2014001_config(loader_fn, channel_info_fn, enabled=True,
                             cue_offset_sec: float = 0.0) -> DatasetConfig:
    return DatasetConfig(
        name="bnci2014001",
        enabled=enabled,
        n_subjects=9,
        n_sessions=2,
        native_sfreq=250.0,
        event_id={"left_hand": 1, "right_hand": 2},   # natively 4-class; naming
                                                        # only these two means
                                                        # events_from_annotations
                                                        # never matches feet/tongue
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=["all"],
        trial_length_sec=4.0,     # cue t=2 s -> fixation cross vanishes t=6 s
        cue_offset_sec=cue_offset_sec,   # RESOLVED AT RUNTIME, see below
        pre_cue_clean_sec=2.0,    # fixation cross from t=0 to the t=2 s cue
        feedback_onset_sec=None,  # "No feedback was provided" (MOABB docs)
        moabb_interval=(2.0, 6.0),
        excluded={},
        excluded_subjects={},
        notes="CRITICAL: MOABB gives this dataset interval=[2, 6] because the trial "
              "begins with a 2 s fixation cross and the arrow cue only appears at "
              "t=2 s. In MOABB 1.0.0 the raw annotations were written at the TRIAL "
              "onset rather than at onset+interval[0] (fixed by MOABB PR #607, "
              "released in 1.1). Any code that epochs externally from the "
              "annotations -- like this pipeline -- therefore needs +2.0 s on "
              "MOABB 1.0.0 and +0.0 s from 1.1 onwards. "
              "io_loaders.resolve_cue_offset() decides this at runtime instead of "
              "hardcoding either answer. Get it wrong and the 'primary imagery "
              "window' is the fixation cross. License: CC BY-ND 4.0.",
    )


# --------------------------------------------------------------------------
# 8. Weibo2014
# --------------------------------------------------------------------------

def make_weibo2014_config(loader_fn, channel_info_fn, enabled=True,
                           cue_offset_sec: float = 0.0) -> DatasetConfig:
    return DatasetConfig(
        name="weibo2014",
        enabled=enabled,
        n_subjects=10,
        n_sessions=1,
        native_sfreq=200.0,
        event_id={"left_hand": 1, "right_hand": 2},   # natively 7-class
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=["all"],
        trial_length_sec=4.0,     # MOABB interval [3, 7]
        cue_offset_sec=cue_offset_sec,   # RESOLVED AT RUNTIME
        pre_cue_clean_sec=2.0,
        feedback_onset_sec=None,
        moabb_interval=(3.0, 7.0),
        excluded={},
        excluded_subjects={},
        notes="Same MOABB annotation-offset caveat as BNCI2014_001, with a LARGER "
              "offset: interval=[3, 7], so on MOABB 1.0.0 the annotation sits 3 s "
              "before the imagery period. 60 EEG channels; CB1/CB2 are inferior "
              "occipital sites with no 10-05 position and are excluded by "
              "channels.NON_SCALP_CHANNELS. License: no SPDX tag confirmed during "
              "review -- long-standing and freely downloadable through MOABB, but "
              "check the original PLoS ONE publication before non-research use.",
    )


# --------------------------------------------------------------------------
# 9. Dreyer2023 -- CC BY 4.0
# --------------------------------------------------------------------------

DREYER2023_ACQUISITION_RUNS = ("R1", "R2")   # sham feedback
DREYER2023_TRAINING_RUNS = ("R3", "R4", "R5", "R6")   # real online feedback


def make_dreyer2023_config(loader_fn, channel_info_fn, enabled=True) -> DatasetConfig:
    return DatasetConfig(
        name="dreyer2023",
        enabled=enabled,
        n_subjects=87,
        n_sessions=1,
        native_sfreq=512.0,
        event_id={"left_hand": 1, "right_hand": 2},
        label_map={1: "left_hand", 2: "right_hand"},
        loader_fn=loader_fn,
        channel_info_fn=channel_info_fn,
        valid_runs_or_phases=["all"],
        trial_length_sec=5.0,     # MOABB interval [0, 5]: cue t=3 s, cross off t=8 s
        cue_offset_sec=0.0,       # interval[0] == 0, so no offset in any MOABB version
        pre_cue_clean_sec=0.8,    # cross at t=0, but an ACOUSTIC cue fires at t=2 s,
                                   # i.e. 1 s before the visual cue -- the auditory
                                   # evoked response contaminates the last ~1 s of
                                   # nominal baseline, so only ~0.8 s is truly clean
        feedback_onset_sec=1.25,  # red arrow off at t=4.25 s == cue+1.25 s, and the
                                   # blue feedback bar starts at the same instant
        moabb_interval=(0.0, 5.0),
        excluded={},
        excluded_subjects={59: "only 4 of 6 runs present (MOABB skips its R5/R6 online runs)"},
        notes="Trial: cross t=0, acoustic signal t=2 s, red arrow cue t=3 s (1.25 s), "
              "continuous blue-bar feedback t=4.25-8 s, cross off t=8 s. "
              "TWO CONSEQUENCES. (1) The feedback bar is driven by the ONLINE LDA "
              "output, so its visually evoked response correlates with the label: "
              "any window past cue+1.25 s partly decodes the feedback, not the "
              "imagery. Prefer the acquisition runs (R1/R2, sham feedback) or a "
              "window ending by +1.25 s. (2) The t=2 s beep means a -0.5 s pre-cue "
              "baseline sits inside the auditory evoked response. "
              "27 EEG electrodes, all frontal-to-parietal (Fz..Pz, C1-C6, FC1-FC6, "
              "CP1-CP6, F3/F4, P3/P4): NO frontopolar, temporal or occipital "
              "coverage at all, which is why union-mode interpolation for this "
              "dataset is extrapolation over most of the scalp. License: CC BY 4.0.",
    )
