"""Config -> pipeline.

``DatasetConfig`` says where the raw data comes from and which runs/phases are
valid; ``DatasetPipeline`` wires that into the mechanism-unchanged
``run_primary_pipeline`` and its ablation siblings.

TWO REAL BUGS FIXED HERE
------------------------
1. ``build_cohort`` used to call ``registry.compute_common_channels(...)``
   internally and IGNORE the ``common_channels`` the rest of the notebook had
   built. So every cohort and every ablation table was silently computed on the
   strict intersection while the notebook believed it was working in its
   82-channel union space -- the numbers in the tables did not describe the
   pipeline the notebook had configured. The channel set is now passed in
   explicitly and never recomputed behind the caller's back.

2. ``_resolve_subject_ids`` returned ``range(1, N+1)`` including subjects the
   config explicitly excludes (PhysioNet 88/89/92/100, Dreyer 59). They then
   raised inside the per-subject try/except and were reported as generic
   "Skipping" lines, indistinguishable from real failures. Known exclusions are
   now filtered up front and reported separately.

PERFORMANCE: ``build_cohort`` now builds one subject's epochs per JOBLIB TASK
and runs the whole (dataset, subject) task list through ``joblib.Parallel``,
instead of one Python ``for`` loop. Every section that calls it -- spatial
reference, artifact handling, epoch window, baseline/normalization/EA,
channel-harmonization strategy, and the full cohort build -- is therefore
parallelized across subjects with this one change, with no change needed at
the call sites. Default worker count is ``GlobalConfig.COHORT_N_JOBS``;
override per call with ``build_cohort(..., n_jobs=...)``.

``DatasetPipeline.get_epochs`` also now passes a `cache_key` (dataset name +
subject id + variant) down to the pipeline functions in signal_processing.py,
which the ICA ablation uses to key its broadband-copy disk cache (see
``signal_processing.configure_cache``). Every other variant accepts and
ignores it.
"""

from __future__ import annotations
from dataclasses import dataclass, field
import mne

from .config import DatasetConfig, DatasetRegistry, GlobalConfig
from .channels import standardize_channel_name
from .signal_processing import (
    run_primary_pipeline, run_secondary_laplacian_pipeline, run_secondary_ica_pipeline,
    get_channel_mask, get_cache_memory,
)
from .rejection import run_secondary_autoreject_pipeline, run_secondary_channel_rejection_pipeline

_VARIANT_DISPATCH = {
    "primary": run_primary_pipeline,
    "laplacian": run_secondary_laplacian_pipeline,
    "ica": run_secondary_ica_pipeline,
    "autoreject": run_secondary_autoreject_pipeline,       # returns (epochs, reject_log)
    "channel_reject": run_secondary_channel_rejection_pipeline,
}


def _run_variant_uncached(loader_fn, subject, variant, channel_mapping_df, common_channels,
                           montage, event_id, epoch_window, baseline, mode, car_scope_channels,
                           cue_offset_sec, target_sfreq, bandpass, trans_bandwidth, cache_key):
    """The actual load-and-process step, called fresh on a cache miss (or
    always, if no cache is configured). `raws` is produced HERE, inside the
    cached call, rather than being passed in and ignored -- so a cache HIT
    skips loading the raw data entirely, not just the processing after it.

    `common_channels`/`car_scope_channels` are converted back from tuples to
    lists (the cached call site passes tuples so they hash) -- keeps every
    downstream function seeing exactly the type it always has."""
    raws = loader_fn(subject)
    common_channels = list(common_channels)
    car_scope_channels = list(car_scope_channels) if car_scope_channels is not None else None
    return _VARIANT_DISPATCH[variant](
        raws, channel_mapping_df, common_channels, montage, event_id, epoch_window, baseline,
        mode=mode, car_scope_channels=car_scope_channels, cue_offset_sec=cue_offset_sec,
        target_sfreq=target_sfreq, bandpass=bandpass, trans_bandwidth=trans_bandwidth,
        cache_key=cache_key,
    )


@dataclass
class DatasetPipeline:
    cfg: DatasetConfig
    channel_mapping_df: "pd.DataFrame"
    common_channels: list
    montage: object
    glob: GlobalConfig
    car_scope_channels: list | None = None

    def get_epochs(self, subject: int, variant: str = "primary",
                   epoch_window: dict | None = None, baseline=None) -> mne.Epochs:
        """Build epochs for one subject via the named variant.

        `epoch_window` is CUE-RELATIVE. The dataset's own ``cue_offset_sec`` is
        added inside the pipeline, so tmin=1.0 means 1.0 s after the imagery
        cue for every dataset regardless of where its annotations sit.

        CACHING (opt-in via ``signal_processing.configure_cache``): if a
        cache is configured, the ENTIRE load-and-process step for this
        (dataset, subject, variant, epoch_window, baseline, channel set,
        CAR scope, harmonization mode) combination is cached to disk -- not
        just the ICA broadband intermediate. This matters because every
        ablation block that includes a "primary"/"CAR"/"None" reference row
        (spatial reference, artifact handling, baseline correction,
        normalization, Euclidean Alignment) was independently rebuilding
        that identical cohort from scratch; a cache hit skips both the
        reload AND the reprocessing. Every value that changes the output
        is part of the cache key (see below) -- with no cache configured,
        behavior is byte-for-byte identical to before this was added.
        """
        if variant not in _VARIANT_DISPATCH:
            raise ValueError(f"Unknown pipeline variant '{variant}'. "
                             f"Known: {sorted(_VARIANT_DISPATCH)}")
        epoch_window = epoch_window or self.glob.PRIMARY_EPOCH_WINDOW
        baseline = self.glob.PRIMARY_BASELINE if baseline is None else baseline
        cache_key = f"{self.cfg.name}_S{subject:03d}_{variant}"

        common = get_cache_memory()
        if common is None:
            return _run_variant_uncached(
                self.cfg.loader_fn, subject, variant, self.channel_mapping_df,
                self.common_channels, self.montage, self.cfg.event_id, epoch_window, baseline,
                self.glob.HARMONIZATION_MODE, self.car_scope_channels, self.cfg.cue_offset_sec,
                self.glob.TARGET_SFREQ, self.glob.BANDPASS, self.glob.FIR_TRANS_BANDWIDTH, cache_key,
            )

        # `loader_fn`, `channel_mapping_df`, `montage` are excluded from the
        # hash (a closure and two objects that are either unhashable or
        # expensive to hash) -- every value that actually distinguishes one
        # result from another (dataset+subject via cache_key, variant, the
        # exact channel set, the exact epoch window/baseline, CAR scope,
        # harmonization mode, target sfreq/bandpass) IS a plain hashed
        # argument. Two different channel sets or two different epoch
        # windows for the "same" subject therefore correctly produce two
        # different cache entries, never a stale hit.
        cached_fn = common.cache(_run_variant_uncached,
                                  ignore=["loader_fn", "channel_mapping_df", "montage"])
        return cached_fn(
            self.cfg.loader_fn, subject, variant, self.channel_mapping_df,
            tuple(self.common_channels), self.montage, self.cfg.event_id, epoch_window, baseline,
            self.glob.HARMONIZATION_MODE,
            tuple(self.car_scope_channels) if self.car_scope_channels else None,
            self.cfg.cue_offset_sec, self.glob.TARGET_SFREQ, self.glob.BANDPASS,
            self.glob.FIR_TRANS_BANDWIDTH, cache_key,
        )


def build_pipeline_from_config(cfg: DatasetConfig, channel_mapping_df, common_channels,
                                montage, glob: GlobalConfig,
                                car_scope_channels=None) -> DatasetPipeline:
    return DatasetPipeline(cfg, channel_mapping_df, list(common_channels), montage,
                            glob, car_scope_channels)


def resolve_car_scope(registry: DatasetRegistry, common_channels: list,
                       glob: GlobalConfig) -> list | None:
    """Channels the common average reference is taken over.

    'shared_support' -> the target channels EVERY enabled dataset really
    recorded. This makes the reference operator identical across datasets,
    which matters because the average reference approximates the potential at
    infinity only up to how the scalp is sampled: a 22-electrode motor montage
    and a 64-electrode whole-head montage otherwise produce two different
    operators, and the difference contaminates every channel of every trial.
    """
    if glob.CAR_SCOPE == "native":
        return None
    if glob.CAR_SCOPE != "shared_support":
        raise ValueError(f"Unknown CAR_SCOPE {glob.CAR_SCOPE!r}")
    _, per_dataset = registry.compute_channels(
        standardize_channel_name, mode="intersection")
    shared = set.intersection(*per_dataset.values()) & set(common_channels)
    scope = sorted(shared)
    if not scope:
        raise ValueError(
            "CAR_SCOPE='shared_support' produced an empty scope: the enabled "
            "datasets share no target channel. Use CAR_SCOPE='native'.")
    print(f"[CAR scope] 'shared_support': averaging over the {len(scope)} channel(s) "
          f"every enabled dataset recorded (of {len(common_channels)} target channels).")
    return scope


def _resolve_subject_ids(spec, cfg: DatasetConfig) -> tuple[list, list]:
    """(usable_ids, skipped_known) -- known-bad subjects are filtered up front
    rather than failing inside the loop and looking like a data problem."""
    if spec is None:
        ids = list(range(1, cfg.n_subjects + 1))
    elif isinstance(spec, int):
        ids = list(range(1, spec + 1))
    else:
        ids = list(spec)
    excluded = set(cfg.excluded_subjects or {})
    usable = [i for i in ids if i not in excluded]
    skipped = [i for i in ids if i in excluded]
    return usable, skipped


def _tqdm_joblib(tqdm_object):
    """Standard recipe for a real tqdm progress bar over a joblib.Parallel
    call (joblib has no native tqdm support -- this patches its completion
    callback for the duration of the `with` block only, then restores it).
    Used so every ablation block's cohort-build shows genuine per-subject
    progress instead of joblib's own text-log lines."""
    import contextlib
    import joblib

    class _TqdmBatchCompletionCallback(joblib.parallel.BatchCompletionCallBack):
        def __call__(self, *args, **kwargs):
            tqdm_object.update(n=self.batch_size)
            return super().__call__(*args, **kwargs)

    old_callback = joblib.parallel.BatchCompletionCallBack
    joblib.parallel.BatchCompletionCallBack = _TqdmBatchCompletionCallback

    @contextlib.contextmanager
    def _ctx():
        try:
            yield tqdm_object
        finally:
            joblib.parallel.BatchCompletionCallBack = old_callback
            tqdm_object.close()
    return _ctx()


def _build_one_subject_epochs(cfg: DatasetConfig, channel_mapping_df, common_channels,
                               montage, glob: GlobalConfig, car_scope_channels, sid: int,
                               variant: str, epoch_window, baseline):
    """One (dataset, subject) unit of work for `build_cohort`'s parallel pool.

    Runs in a worker process (joblib 'loky' backend), so it must be a
    top-level, picklable function -- it rebuilds its own `DatasetPipeline`
    from the (picklable) `cfg`/`channel_mapping_df`/`montage`/`glob` rather
    than receiving one built in the driver process. Returns a plain tuple
    instead of raising, so one subject's failure never aborts the whole pool.

    THREAD CAP: without this, numpy/scipy/MNE's BLAS-backed linear algebra
    (filtering, resampling, and especially ICA/Picard's decomposition) tries
    to use every CPU core INSIDE each of the n_jobs worker processes
    independently -- n_jobs=4 on an 8-core machine can mean 4x8=32-way
    contention for 8 cores. That oversubscription is what actually crashes
    workers (TerminatedWorkerError / SIGKILL), not just slows them down.
    Capping each worker to 1 BLAS thread here makes the outer `n_jobs` the
    only parallelism in effect.

    Also silences warnings inside the worker (MNE/sklearn/numpy are noisy at
    this scale across many subjects) -- this only affects THIS worker
    process's warning filter, not the driver notebook's.
    """
    import warnings
    warnings.filterwarnings("ignore")
    key = f"{cfg.name}/S{sid:03d}"
    try:
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=1):
            pipe = build_pipeline_from_config(cfg, channel_mapping_df, common_channels,
                                              montage, glob, car_scope_channels)
            result = pipe.get_epochs(sid, variant=variant,
                                     epoch_window=epoch_window, baseline=baseline)
    except ImportError:
        # threadpoolctl ships with scikit-learn and is almost always already
        # installed; fall back to uncapped rather than hard-failing if not.
        pipe = build_pipeline_from_config(cfg, channel_mapping_df, common_channels,
                                          montage, glob, car_scope_channels)
        result = pipe.get_epochs(sid, variant=variant,
                                 epoch_window=epoch_window, baseline=baseline)
    except Exception as exc:
        return key, None, None, str(exc)

    ep = result[0] if isinstance(result, tuple) else result
    if len(ep) == 0:
        return key, None, None, "0 epochs survived."
    return key, ep, get_channel_mask(ep), None


def build_cohort(registry: DatasetRegistry, channel_mapping_df, montage, glob: GlobalConfig,
                  n_subjects_per_dataset: dict, common_channels: list,
                  variant: str = "primary", car_scope_channels=None,
                  epoch_window: dict | None = None, baseline=None,
                  return_masks: bool = False, n_jobs: int | None = None) -> dict:
    """Build epochs for the requested subjects of every ENABLED dataset.

    `common_channels` is now REQUIRED and is used verbatim -- it is not
    recomputed here. Returns {"<dataset>/S<NNN>": Epochs}, plus the per-dataset
    channel masks when `return_masks=True`.

    PARALLELIZED across every (dataset, subject) pair with `joblib.Parallel`
    (the 'loky' process backend, so CPU-bound filtering/ICA/AutoReject actually
    run concurrently rather than fighting the GIL). `n_jobs=None` (the default)
    uses `glob.COHORT_N_JOBS`; pass `n_jobs=1` to fall back to a plain
    sequential loop (joblib runs n_jobs=1 in-process, so this is also the way
    to get ordinary tracebacks while debugging one subject).

    Loading data for subjects that are not yet cached locally still hits the
    network from several processes at once; if a dataset has never been
    downloaded before, running it once for a single subject first (as Section
    6's demo does) avoids every worker racing to populate the same directory.
    """
    from joblib import Parallel, delayed

    n_jobs = glob.COHORT_N_JOBS if n_jobs is None else n_jobs
    tasks = []
    for cfg in registry.enabled():
        subject_ids, skipped = _resolve_subject_ids(n_subjects_per_dataset.get(cfg.name), cfg)
        for sid in skipped:
            print(f"[cohort build] {cfg.name}/S{sid:03d} excluded by config: "
                  f"{cfg.excluded_subjects[sid]}")
        tasks.extend((cfg, sid) for sid in subject_ids)

    print(f"[cohort build] Dispatching {len(tasks)} subject(s) across "
          f"{len({cfg.name for cfg, _ in tasks})} dataset(s) with n_jobs={n_jobs} "
          f"(variant='{variant}').")

    from tqdm.auto import tqdm
    with _tqdm_joblib(tqdm(total=len(tasks), desc=f"[{variant}] cohort", unit="subject")):
        results = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(_build_one_subject_epochs)(
                cfg, channel_mapping_df, common_channels, montage, glob,
                car_scope_channels, sid, variant, epoch_window, baseline)
            for cfg, sid in tasks
        )

    epochs_by_key, masks = {}, {}
    for key, ep, mask, err in results:
        if err is not None:
            print(f"[cohort build] Skipping {key} ({variant}): {err}")
            continue
        epochs_by_key[key] = ep
        if mask is not None:
            masks[key] = mask
    if return_masks:
        return epochs_by_key, masks
    return epochs_by_key
