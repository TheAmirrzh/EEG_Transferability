"""Six-dataset motor-imagery EEG preprocessing package
(PhysioNet + Cho2017 + Lee2019 + BNCI2014-001 + Weibo2014 + Dreyer2023).

See README.md for the module map and the full changelog for this revision.
"""

from .config import (
    GlobalConfig, DatasetConfig, DatasetRegistry,
    PHYSIONET_ROOT, PHYSIONET_UNILATERAL_IMAGERY_RUNS,
    PHYSIONET_KNOWN_ANOMALOUS_SUBJECTS, PHYSIONET_EXCLUDED_RUNS,
    DREYER2023_ACQUISITION_RUNS, DREYER2023_TRAINING_RUNS,
    make_physionet_config, make_cho2017_config, make_lee2019_config,
    make_bnci2014001_config, make_weibo2014_config, make_dreyer2023_config,
)
from .channels import (
    standardize_channel_name, is_scalp_eeg, scalp_eeg_names, NON_SCALP_CHANNELS,
    build_channel_table, filter_eeg_only,
    compute_common_channels, compute_target_channels, compute_reference_channels,
    resolve_target_channels, build_channel_masks, summarize_channel_synthesis,
    build_mapping_table, verify_common_channels_montage, analyze_dataset_harmonization,
)
from .io_loaders import (
    resolve_cue_offset, apply_cue_offsets, describe_annotation_timing,
    moabb_annotations_include_interval_offset,
    load_physionet_raw, get_physionet_channel_info, load_physionet_subject_runs,
    resolve_physionet_edf_path,
    get_cho2017_channel_info, load_cho2017_subject_runs,
    get_lee2019_channel_info, load_lee2019_subject_runs,
    make_lee2019_loader, make_lee2019_channel_info_fn, discover_lee2019_local_subjects,
    get_bnci2014001_channel_info, load_bnci2014001_subject_runs,
    get_weibo2014_channel_info, load_weibo2014_subject_runs,
    get_dreyer2023_channel_info, load_dreyer2023_subject_runs, make_dreyer2023_loader,
)
from .events import get_dataset_events
from .metadata import build_subject_metadata_scaffold
from .signal_processing import (
    preprocess_raw, set_common_average_reference, apply_laplacian_reference,
    make_epochs, run_primary_pipeline, run_secondary_laplacian_pipeline,
    apply_ica_cleaning, run_secondary_ica_pipeline,
    analytic_envelope, band_envelope, get_channel_mask, fir_half_length_sec,
    configure_cache, get_cache_memory, suppress_warnings,
    envelope_margin_samples, available_envelope_margin,
)
from .rejection import (
    apply_autoreject_trial_rejection, run_secondary_autoreject_pipeline,
    detect_and_interpolate_bad_channels, run_secondary_channel_rejection_pipeline,
)
from .normalization import (
    fit_channel_normalizer, apply_channel_normalizer, apply_per_trial_zscore_ablation,
)
from .alignment import (
    apply_euclidean_alignment, compute_ea_reference, whiten_with_reference, align_cohort,
)
from .pipeline_builder import (
    DatasetPipeline, build_pipeline_from_config, build_cohort, resolve_car_scope,
)
from .baselines import (
    build_classical_bci_baselines, build_all_baselines, FBCSP, SimpleFBCSP,
    default_filter_bank,
)
from .augmentation import EEGAugmentationTransform
from .cohort_analysis import (
    build_baseline_ablation_epochs, evaluate_raw_feature_separability, get_display_window,
    build_erd_cohort,
)
from .cho2017_qc import (
    locate_cho2017_mat_file, get_cho2017_bad_trial_indices, apply_cho2017_qc_rejection,
)
from .audits import (
    assert_channel_equivalence, audit_car_memoryless, audit_filter_leakage_bound,
    audit_epoch_isolation, audit_filter_resample_order, audit_epoch_boundary_containment,
    audit_subject_split_integrity, audit_channel_set_determinism, audit_duplicate_trials,
    audit_feature_leakage, audit_normalizer_multi_split, audit_cohort_tensor_consistency,
    audit_cohort_finite_values, audit_pipeline_determinism, audit_trial_count_bounds,
    audit_effective_rank, audit_augmentation_pipeline, run_full_pipeline_audit,
    continuous_filter_helper,
)
from . import visualization
from . import ablation_suite
from . import audits
from .ablation_suite import (
    ablation_channel_harmonization_strategy, audit_dataset_identity_shortcut,
    per_dataset_breakdown, flatten_epochs_dict, cv_accuracy,
)

__version__ = "2.1.0"
__all__ = [name for name in dir() if not name.startswith("_")]
