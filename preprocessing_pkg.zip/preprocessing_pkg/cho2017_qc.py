"""Cho2017's own per-subject quality control, read from the original GigaDB
.mat files. MOABB's Raw/annotations abstraction does not expose it, so this
reads the source file directly.

The notebook used to patch this module at runtime (two whole cells, one of
which rewrote this file on disk mid-session) because the shipped version
assumed the top-level keys were 'EEG_MI_train'/'EEG_MI_test', while the actual
GigaDB files wrap everything in a single 'eeg' struct. That patch is folded in
here, along with the scipy.io quirks it had to work around.
"""

from __future__ import annotations
from pathlib import Path
import numpy as np

_FIELD_GUESSES = ("bad_trial_indices", "bad_trial_idx", "bad_trials",
                  "badTrialIdx", "bad_trial")


def locate_cho2017_mat_file(subject: int, root_path: str,
                             pattern: str = "s{subject:02d}.mat") -> str:
    """Best-effort locator for a subject's raw .mat file under `root_path`."""
    candidate = Path(root_path) / pattern.format(subject=subject)
    if candidate.exists():
        return str(candidate)
    matches = sorted(Path(root_path).rglob(f"s{subject:02d}.mat"))
    if not matches:
        matches = sorted(Path(root_path).rglob(f"*{subject:02d}*.mat"))
    if matches:
        return str(matches[0])
    raise FileNotFoundError(
        f"No Cho2017 .mat file for subject {subject} under {root_path}. "
        "Pass the exact path directly to get_cho2017_bad_trial_indices instead.")


def _coerce_indices(found) -> np.ndarray:
    """scipy.io returns an empty struct, an empty array, a scalar or an array
    depending on what MATLAB stored. Normalise all four to an int array."""
    if found is None or type(found).__name__ == "mat_struct":
        return np.array([], dtype=int)
    arr = np.atleast_1d(found)
    if arr.size == 0 or arr.dtype == object:
        return np.array([], dtype=int)
    return arr.astype(int).ravel()


def _lookup(obj):
    for field in _FIELD_GUESSES:
        if isinstance(obj, dict) and field in obj:
            return obj[field]
        if hasattr(obj, field):
            return getattr(obj, field)
    return None


def get_cho2017_bad_trial_indices(subject: int, mat_path: str) -> dict:
    """Returns {"EEG_MI_train": array, "EEG_MI_test": array}.

    Handles both layouts seen in the wild:
      A. the GigaDB layout, a single top-level 'eeg' struct carrying
         `bad_trial_indices` (this is what the real downloads contain);
      B. top-level 'EEG_MI_train'/'EEG_MI_test' structs.
    Raises with the actual top-level keys if neither matches, rather than
    silently returning nothing.
    """
    import scipy.io as sio
    mat = sio.loadmat(mat_path, squeeze_me=True, struct_as_record=False)

    if "eeg" in mat:
        found = _lookup(mat["eeg"])
        return {"EEG_MI_train": _coerce_indices(found),
                "EEG_MI_test": np.array([], dtype=int)}

    result = {}
    for phase in ("EEG_MI_train", "EEG_MI_test"):
        if phase in mat:
            result[phase] = _coerce_indices(_lookup(mat[phase]))
    if not result:
        top = [k for k in mat if not k.startswith("__")]
        raise KeyError(
            f"No bad-trial annotations found in {mat_path}. Top-level keys: {top}. "
            f"Field names tried: {_FIELD_GUESSES}.")
    return result


def apply_cho2017_qc_rejection(epochs, bad_trial_indices: dict,
                                phase: str = "EEG_MI_train", one_indexed: bool = True):
    """Drop the original authors'-flagged bad trials.

    Assumes epoch order matches chronological annotation order == original
    trial order, which holds because mne.events_from_annotations always returns
    events sorted by time. MATLAB indices are 1-indexed by convention; set
    one_indexed=False if your copy is already 0-indexed.

    IMPORTANT CAVEAT: if the epochs object has already had trials dropped for
    any other reason (reject_by_annotation, AutoReject, a run that failed to
    load), the positional indices no longer line up and this will silently drop
    the wrong trials. Apply it to freshly-built primary epochs only -- the
    check below catches a gross length mismatch but not a partial one.
    """
    idx = np.asarray(bad_trial_indices[phase], dtype=int)
    if one_indexed:
        idx = idx - 1
    in_range = (idx >= 0) & (idx < len(epochs))
    if not np.all(in_range):
        print(f"[Cho2017 QC] {int((~in_range).sum())} flagged index/indices fall outside "
              f"0..{len(epochs)-1} -- likely a train/test phase or one_indexed mismatch. "
              "Dropping only the in-range ones.")
    idx = idx[in_range]

    keep = np.ones(len(epochs), dtype=bool)
    keep[idx] = False
    print(f"[Cho2017 QC] Dropping {int((~keep).sum())}/{len(epochs)} trial(s) flagged by "
          f"the original authors' quality control ({phase}).")
    return epochs[keep]
