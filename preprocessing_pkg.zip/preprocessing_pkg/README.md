# preprocessing_pkg 2.1.0

Six-dataset motor-imagery EEG preprocessing: PhysioNet EEGMMIDB, Cho2017,
Lee2019/OpenBMI, BNCI2014-001, Weibo2014, Dreyer2023.

## 2.1.0 — performance (no change in what is computed, only how often)

- **Fit once per subject, not once per run.** CAR, the Surface Laplacian
  spline solve, ICA, and variance-based bad-channel detection were each being
  fit separately on every run before concatenation. `_filter_resample_concat`
  now does the per-run harmonize+filter+resample (still required, to avoid
  smearing a filter transient across a run boundary) and concatenates once;
  every subsequent step is then fit exactly once on the concatenated
  recording. CAR is mathematically unaffected (it's a per-timepoint spatial
  average); ICA and bad-channel detection go from N fits per subject to 1 —
  12 fits collapse to 1 for a 12-run dataset like BNCI2014-001 — and are also
  statistically sounder fit on more data at once.
- **`build_cohort` is parallelized across every (dataset, subject) pair**
  with `joblib.Parallel` (`GlobalConfig.COHORT_N_JOBS`, default 4). Because
  every ablation block (Sections 10, 12, 13, 14, 15, 16) funnels through
  `build_cohort`, this parallelizes all of them with no change at their call
  sites. `cohort_analysis.build_erd_cohort` applies the same pattern to
  Section 18's per-subject ERD/ERS epoch construction.
- **The ICA ablation's broadband copy is cacheable to disk**
  (`signal_processing.configure_cache(cache_dir)`), keyed on a cheap
  `cache_key` string (dataset name + subject id) rather than on the Raw
  objects themselves. Point it at Drive-backed storage and a Colab
  disconnect mid-ablation no longer costs you the subjects already done.

## Module map

| module | role |
|---|---|
| `config.py` | `GlobalConfig` (hyperparameters) + one `DatasetConfig` per dataset + `DatasetRegistry` |
| `channels.py` | name canonicalization, scalp-EEG filtering, the three harmonization strategies, channel masks |
| `io_loaders.py` | `loader_fn(subject) -> list[Raw]` per dataset, **plus cue-offset resolution** |
| `signal_processing.py` | harmonize → filter → resample → reference → cue-aligned epoch; analytic envelope |
| `rejection.py` | AutoReject / bad-channel ablations (mask-aware) |
| `normalization.py` | per-channel train-only + per-trial z-score |
| `alignment.py` | Euclidean Alignment, transductive and inductive scopes |
| `baselines.py` | CSP+LDA, Riemannian TS+LR, FBCSP with MIBIF |
| `pipeline_builder.py` | config → `DatasetPipeline`; `build_cohort` |
| `ablation_suite.py` | every ablation under one CV protocol |
| `audits.py` | leakage / temporal-property / invariant checks |
| `visualization.py` | V1–V13 plots |
| `cohort_analysis.py` | ERD/ERS epochs, separability probe |
| `cho2017_qc.py` | the original authors' per-trial QC flags |

## Changelog — what changed in 2.0.0 and why

### 1. Cue-onset alignment (correctness, highest severity)

`DatasetConfig.cue_offset_sec` and `io_loaders.resolve_cue_offset()`.

MOABB stores each dataset's usable task window in an `interval` attribute:
`BNCI2014_001` is `[2, 6]` because the trial opens with a 2 s fixation cross
and the arrow cue appears at t = 2 s; `Weibo2014` is `[3, 7]`. In MOABB 1.0.0
`SetRawAnnotations` wrote annotations at the **trial** onset rather than at
`onset + interval[0]`; MOABB PR #607 (shipped in 1.1) changed that. MOABB's own
paradigms were unaffected because they add `interval[0]` themselves — but code
that loads the raws and epochs externally from `raw.annotations`, which is what
this package does, is affected.

The previous version assumed offset 0 for all six datasets. On MOABB 1.0.0 that
made the BNCI2014-001 "primary imagery window" the fixation cross, and put
Weibo2014 3 s early. The offset is now resolved at runtime from the installed
MOABB version and the dataset's declared interval, printed, and overridable.

Verified per dataset: physionet (direct EDF) 0 · cho2017 `[0,3]` 0 ·
lee2019 (STI 014) 0 · **bnci2014001 `[2,6]`** · **weibo2014 `[3,7]`** ·
dreyer2023 `[0,5]` 0.

### 2. Channel harmonization as a hyperparameter

`GlobalConfig.HARMONIZATION_MODE ∈ {"reference_masked", "union", "intersection"}`,
with `ANCHOR_DATASETS` defining the reference space.

`reference_masked` (new default) takes the intersection of the anchor datasets
(PhysioNet ∩ Cho2017, ~62 channels, computed live not hardcoded) and expresses
every other dataset in it: real channels kept, never-recorded channels
zero-filled and flagged in a boolean mask carried on `info['temp']`.

Motivation. Union mode asked spherical-spline interpolation to produce
Fp1/O1/T7 for Dreyer2023, whose 27 electrodes are all frontal-to-parietal with
no frontopolar, temporal or occipital coverage at all. Beyond accuracy,
interpolated rows are exact linear combinations of the recorded ones, so the
tensor's rank stays at the native channel count however many rows it gains, and
inter-channel correlation is inflated (Kang, Lano & Sponheim 2015,
*Neuropsychiatr Electrophysiol* 1:9). `audits.audit_effective_rank` reports
this directly.

### 3. Reference scope

`GlobalConfig.CAR_SCOPE ∈ {"shared_support", "native"}`.

Two bugs: under union mode the average was taken over interpolated channels, so
fabricated values fed back into every real channel; and under any mode the
average was over a different electrode set per dataset, so the reference
operator itself differed across datasets (the average reference approximates
the potential at infinity only up to how the scalp is sampled — Ferree 2006,
*Brain Topogr* 19:43). `shared_support` restricts the average to channels every
enabled dataset recorded.

### 4. Hilbert edge effects — and why the obvious fix is wrong

`signal_processing.analytic_envelope(..., margin_samples=...)`.

The bare `scipy.signal.hilbert` treats an epoch as one period of a periodic
signal, so the last-to-first-sample step injects a broadband transient ruining
roughly one cycle of the lowest analysed frequency at each end (~125 ms at
8 Hz, 12% of a 2 s epoch, exactly where ERD onset is read).

Reflection padding — the intuitive remedy — **measures worse than doing
nothing** on narrowband data, because it makes the signal continuous in value
but flips the sign of its slope, replacing a step with a cusp. Measured on
simulated 9–13 Hz oscillations with a known ERD-shaped envelope, mean absolute
envelope error in the outer 125 ms:

```
no padding                0.334
reflection padding        0.438   <-- worse than nothing
real-data margin +-1 s    0.003
```

So the fix is to epoch **wider than you display**, transform, and crop.
`build_baseline_ablation_epochs` requests `ENVELOPE_MARGIN_SEC` of extra real
signal on each side, capped per dataset by its clean pre-cue budget and post-cue
trial length, and records the display window. `BASELINE_ABLATION_EPOCH_WINDOW`
was shortened to (−0.5, 2.0) so a full 1 s margin still fits inside Cho2017's
3.0 s post-cue trial, which is the binding constraint.

### 5. Evaluation leakage and comparability

* `StratifiedGroupKFold` replaces `GroupKFold` — the latter balances group
  sizes, not class proportions, so pooling datasets with different balances
  moved accuracy for reasons unrelated to the ablation.
* Empirical majority-class rate replaces the hardcoded "50% chance".
* Balanced accuracy and ROC-AUC reported alongside accuracy.
* Per-dataset breakdown accompanies every pooled row, plus
  `audit_dataset_identity_shortcut`: if dataset identity is near-perfectly
  decodable (it is, whenever masks differ), a pooled score is an upper bound,
  not a generalisation estimate.
* **Euclidean Alignment was transductive without saying so** — the reference
  was estimated from each subject's own trials, including held-out ones. That
  is the standard He & Wu (2020) formulation and is label-free, but placed
  unlabelled next to inductive rows it is not a fair comparison. Now three
  rows: off / per-subject (transductive) / train-fold reference (inductive).
* EA's inverse square root went through `fractional_matrix_power`, which uses a
  Schur decomposition and returns a complex array whose real part was silently
  taken — unreliable on the rank-deficient covariances that post-CAR data always
  produces. Replaced with a symmetric eigendecomposition with eigenvalue
  flooring.
* Epoch-window ablation grid mixed 3.0 s and 2.0 s windows, confounding
  "later start" with "more data per covariance estimate". Duration is now held
  constant.

### 6. Channel-set inconsistency (silent, severe)

`build_cohort` and `ablation_suite._build_cohort` both called
`registry.compute_common_channels()` internally and **ignored** the
`common_channels` the caller had built. Every cohort and every ablation table
was therefore computed on the strict intersection while the notebook believed
it was working in its 82-channel union space. The channel set is now a required
argument and is never recomputed behind the caller's back.

### 7. "Causality" terminology

Neither audit was about causality, and the mislabelling hid a real problem.

* CAR is a **memoryless** spatial operator, not a causal one. Renamed
  `audit_car_memoryless`; it now calls the real
  `set_common_average_reference` instead of recomputing the average inline,
  which had made the test a tautology about its own arithmetic.
* The band-pass runs with `phase="zero"`, which is **non-causal by
  construction** — a symmetric impulse response means output at t depends on
  input both before and after t. The honest question is how far energy travels.
  `audit_filter_leakage_bound` computes the actual FIR half-support from
  `mne.filter.create_filter` (≈1.65 s at 160 Hz with a 2 Hz transition band)
  and checks the guard against it. The old test used a fixed 1.5 s guard —
  *inside* the filter's reach — so it was testing numerical luck.
* New `audit_epoch_isolation`: whether adjacent trials are far enough apart
  that the filter cannot carry one trial's energy into the next trial's epoch.

### 8. Other fixes

* `audit_feature_leakage` was **vacuous** — it perturbed a detached `.copy()`
  and then refit on the unchanged train list, so it would have passed even if
  the normalizer had been handed test data directly. Now perturbs in place.
* `audit_epoch_boundary_containment` indexed the raw array with `ev[0]` without
  subtracting `raw.first_samp`; every comparison was shifted for any recording
  with a non-zero first sample.
* `audit_channel_set_determinism` always tested the intersection regardless of
  configured mode, certifying a channel set the pipeline was not using.
* `assert_channel_equivalence` asserted every channel has std > 1e-10, which is
  guaranteed to fail under masking. Now mask-aware.
* **FBCSP was not FBCSP** — the defining MIBIF feature-selection stage
  (Ang et al. 2008) was missing entirely, so it was just a wider CSP; the CSP
  objects were built in `__init__` and mutated by `fit`, so a deepcopy-"clone"
  shared fitted spatial filters with its parent; it was not a scikit-learn
  estimator (hence four monkey-patched dunders in the notebook); and its
  28–32 Hz band sat outside the 8–30 Hz analysis passband. Rewritten with
  zero-phase Chebyshev II sub-bands, MIBIF including the paired-feature rule,
  and `BaseEstimator`/`ClassifierMixin`.
* `standardize_channel_name` now maps legacy 10-20 labels (T3/T4/T5/T6) onto
  10-10 equivalents, without which two datasets naming the same electrode
  differently were treated as different electrodes.
* Non-scalp channels (CB1/CB2, EMG/EOG, stim, mastoids) are excluded at source
  via `channels.NON_SCALP_CHANNELS`, replacing two notebook cells of post-hoc
  filtering.
* The robust Lee2019 `STI 014` loader and the Cho2017 `'eeg'`-struct QC reader
  are folded into the package; the notebook no longer monkey-patches either,
  and no longer rewrites a package file on disk mid-session.
* `_resolve_subject_ids` filtered no known-bad subjects, so PhysioNet 88/89/92/100
  and Dreyer 59 raised inside the loop and looked like data failures.
* ICA's `n_components=0.99` is capped at the data's actual rank (CAR removes
  one degree of freedom; masked channels remove more).
* Surface Laplacian now refuses to run on masked data rather than treating
  zero-filled rows as genuine 0 V measurements.
* Bad-channel detection only considers and only interpolates *real* channels —
  otherwise every masked channel looks flat, gets flagged, and gets
  interpolated, silently converting masking back into interpolation.
* `plot_erd_ers_tfr` uses `epochs.compute_tfr` (`tfr_morlet` was removed in
  MNE 1.8) and baselines over a window clear of both the epoch edge (cone of
  influence) and the cue.
* `plot_channel_correlation_heatmap` annotates the −1/(N−1) correlation floor
  CAR imposes by construction, and reports effective rank.
* Lateralisation index defaults to the baselined log-ratio; the previous raw
  `(P(C4) − P(C3)) × 1e12` is in arbitrary units and cannot be averaged across
  subjects.
* `compute_grand_average_topomap` averages only over channels real in every
  contributing recording — averaging a masked zero into a grand mean pulls that
  electrode's ERD toward 0 dB in proportion to how many datasets lack it.
* Augmentation: the `jitter_mode` Literal listed `"crop_resample"` while the
  implementation accepted only `"crop_and_resample"`; and `temporal_jitter`
  drew one shift for the whole batch rather than per trial.

## Dataset facts verified against documentation

| dataset | n_subj | ch | native sfreq | MOABB interval | post-cue trial | notes |
|---|---|---|---|---|---|---|
| physionet | 109 | 64 | 160 Hz | `[0,3]` | 4.0 s | runs 4/8/12; 88/89/92/100 excluded |
| cho2017 | 52 | 64 | 512 Hz | `[0,3]` | 3.0 s | 2 s fixation, binding constraint |
| lee2019 | 54 | 62 | 1000 Hz | `[0,4]` | 4.0 s | 3 s fixation; train_run only |
| bnci2014001 | 9 | 22 | 250 Hz | `[2,6]` | 4.0 s | cue at t=2 s, no feedback |
| weibo2014 | 10 | 60 | 200 Hz | `[3,7]` | 4.0 s | CB1/CB2 not in 10-05 |
| dreyer2023 | 87 | 27 | 512 Hz | `[0,5]` | 5.0 s | **feedback from cue+1.25 s** |

**Dreyer2023 confound.** Trial: cross t=0, acoustic warning t=2 s, red arrow
cue t=3 s (1.25 s), blue feedback bar t=4.25–8 s. The bar is driven by the
online LDA, so its visually evoked response correlates with the label: any
window past cue+1.25 s partly decodes the feedback, not the imagery. Use the
acquisition runs (`make_dreyer2023_loader(acquisition_only=True)`, sham
feedback) or a window ending by +1.25 s. The t=2 s beep also means a −0.5 s
pre-cue baseline sits inside an auditory evoked response, hence
`pre_cue_clean_sec=0.8`.

`registry.validate_epoch_windows()` raises on window/trial-length violations
and warns on the feedback overlap.

## References

- Perrin et al. (1989) *Electroenceph Clin Neurophysiol* 72:184 — spherical splines
- Kang, Lano & Sponheim (2015) *Neuropsychiatr Electrophysiol* 1:9 — interpolation inflates coherence
- Ferree (2006) *Brain Topogr* 19:43 — average reference depends on scalp sampling
- Ang et al. (2008) IJCNN — FBCSP + MIBIF
- He & Wu (2020) *IEEE TBME* 67:399 — Euclidean Alignment
- MOABB PR #607 — annotation interval offset
