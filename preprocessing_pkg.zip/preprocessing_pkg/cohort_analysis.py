"""Cohort-scale analysis.

Bug #1 fix retained: `build_baseline_ablation_epochs` is the ONE place that
builds pre-cue-inclusive epochs, and it always extracts events fresh from the
exact raw it just built -- there is no loop-scoped `events` variable for a
later cell to reuse from a different subject.

New here: the baseline-ablation epochs are cue-aligned like everything else,
and the separability probe reports what each of its two numbers can and cannot
support.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
import mne
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold, GroupKFold, StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .signal_processing import (
    preprocess_raw, set_common_average_reference, _concat_preserving_mask,
    _epoch_concat, get_channel_mask, available_envelope_margin, _filter_resample_concat,
)
from .pipeline_builder import DatasetPipeline, build_pipeline_from_config, _resolve_subject_ids


def build_baseline_ablation_epochs(pipe: DatasetPipeline, subject: int) -> mne.Epochs:
    """Pre-cue-inclusive epochs (BASELINE_ABLATION window) for exactly this
    (dataset, subject), with events extracted fresh from the exact concatenated
    raw this call produces.

    The window is cue-relative and shifted by the dataset's own
    `cue_offset_sec`, so t=0 is the imagery cue for every dataset -- which is
    what makes the ERD/ERS plots comparable across datasets at all.
    """
    glob = pipe.glob
    raws = pipe.cfg.loader_fn(subject)
    raw_filt_concat = _filter_resample_concat(
        raws, pipe.channel_mapping_df, pipe.common_channels, pipe.montage,
        glob.BANDPASS, glob.TARGET_SFREQ, glob.HARMONIZATION_MODE, glob.FIR_TRANS_BANDWIDTH)
    raw_concat = set_common_average_reference(raw_filt_concat, pipe.car_scope_channels)

    display = glob.BASELINE_ABLATION_EPOCH_WINDOW
    if -display["tmin"] > pipe.cfg.pre_cue_clean_sec + 1e-9:
        print(f"[{pipe.cfg.name}] WARNING: the baseline window reaches "
              f"{-display['tmin']:.2f}s before the cue but only "
              f"{pipe.cfg.pre_cue_clean_sec:.2f}s of clean pre-cue signal exists.")

    # Epoch WIDER than we intend to display, so the Hilbert envelope has real
    # signal to work with at both ends and the outer ~125 ms of the display
    # window is not an edge artefact. The margin is whatever this dataset can
    # actually spare -- Dreyer2023, whose auditory warning lands 1 s before the
    # cue, can spare much less than Cho2017.
    margin = available_envelope_margin(pipe.cfg, display,
                                       getattr(glob, "ENVELOPE_MARGIN_SEC", 1.0))
    if margin < getattr(glob, "ENVELOPE_MARGIN_SEC", 1.0) - 1e-9:
        print(f"[{pipe.cfg.name}] envelope margin reduced to {margin:.2f}s "
              f"(pre-cue budget {pipe.cfg.pre_cue_clean_sec:.2f}s, post-cue trial "
              f"{pipe.cfg.trial_length_sec:.2f}s). Edge handling is proportionally weaker.")
    window = dict(tmin=display["tmin"] - margin, tmax=display["tmax"] + margin)

    epochs = _epoch_concat(raw_concat, pipe.cfg.event_id, window, None,
                           pipe.cfg.cue_offset_sec)
    temp = dict(epochs.info["temp"]) if isinstance(epochs.info.get("temp"), dict) else {}
    temp["display_window"] = (display["tmin"], display["tmax"])
    temp["envelope_margin_sec"] = margin
    epochs.info["temp"] = temp
    return epochs


def get_display_window(epochs, default=(-0.5, 2.0)):
    """The window a margin-extended Epochs object was actually meant to show."""
    temp = epochs.info.get("temp")
    if isinstance(temp, dict) and "display_window" in temp:
        return tuple(temp["display_window"])
    return default


def _build_one_erd(cfg, channel_mapping_df, common_channels, montage, glob,
                    car_scope_channels, sid: int):
    """One (dataset, subject) unit of work for `build_erd_cohort`'s parallel
    pool -- the same pattern as pipeline_builder._build_one_subject_epochs,
    duplicated rather than imported to keep this module's worker function
    self-contained and independently picklable. Same thread-cap reasoning
    as that function: without it, n_jobs worker PROCESSES each try to use
    every CPU core for their own BLAS-backed linear algebra, and that
    oversubscription is what actually crashes workers under load."""
    import warnings
    warnings.filterwarnings("ignore")
    key = f"{cfg.name}/S{sid:03d}"
    try:
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=1):
            pipe = build_pipeline_from_config(cfg, channel_mapping_df, common_channels,
                                              montage, glob, car_scope_channels)
            epochs = build_baseline_ablation_epochs(pipe, sid)
    except ImportError:
        pipe = build_pipeline_from_config(cfg, channel_mapping_df, common_channels,
                                          montage, glob, car_scope_channels)
        epochs = build_baseline_ablation_epochs(pipe, sid)
    except Exception as exc:
        return key, None, str(exc)
    return key, epochs, None


def build_erd_cohort(registry, channel_mapping_df, common_channels, montage, glob,
                      n_subjects_per_dataset: dict, car_scope_channels=None,
                      max_subjects_per_dataset: int = 5, n_jobs: int | None = None) -> dict:
    """Parallel counterpart of Section 18's original per-subject Python loop:
    baseline-ablation (ERD/ERS) epochs for up to `max_subjects_per_dataset`
    subjects of every enabled dataset, one joblib task per (dataset, subject)
    pair -- same parallelization pattern as `pipeline_builder.build_cohort`.
    """
    from joblib import Parallel, delayed

    n_jobs = glob.COHORT_N_JOBS if n_jobs is None else n_jobs
    tasks = []
    for cfg in registry.enabled():
        spec = n_subjects_per_dataset.get(cfg.name, max_subjects_per_dataset)
        ids = (list(range(1, min(spec, max_subjects_per_dataset) + 1))
               if isinstance(spec, int) else list(spec)[:max_subjects_per_dataset])
        usable, _ = _resolve_subject_ids(ids, cfg)
        tasks.extend((cfg, sid) for sid in usable)

    print(f"[ERD cohort] Dispatching {len(tasks)} subject(s) with n_jobs={n_jobs}.")
    from tqdm.auto import tqdm
    from .pipeline_builder import _tqdm_joblib
    with _tqdm_joblib(tqdm(total=len(tasks), desc="[ERD] cohort", unit="subject")):
        results = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(_build_one_erd)(cfg, channel_mapping_df, common_channels, montage,
                                    glob, car_scope_channels, sid)
            for cfg, sid in tasks
        )
    erd_epochs_by_subject = {}
    for key, ep, err in results:
        if err is not None:
            print(f"Skipping {key}: {err}")
            continue
        erd_epochs_by_subject[key] = ep
    return erd_epochs_by_subject


def _shared_real_channels(epochs_by_subject: dict):
    common = None
    for ep in epochs_by_subject.values():
        m = get_channel_mask(ep)
        m = np.ones(len(ep.ch_names), dtype=bool) if m is None else m
        common = m.copy() if common is None else (common & m)
    return common


def evaluate_raw_feature_separability(epochs_by_subject: dict, band=(8, 30),
                                       cv_splits=5, random_state=42):
    """Task separability (Acc_T, subject-grouped) vs. subject separability
    (Acc_S, trial-level) on raw log band-power features.

    THREE THINGS TO READ CAREFULLY.

    1. Acc_T is the honest one: the scaler and classifier are fitted inside
       each fold (they live in a Pipeline passed to cross_val_score), and folds
       are grouped by recording so no subject spans train and test.

    2. Acc_S is DELIBERATELY not leakage-free. It splits at the trial level
       within subjects, so trials from the same recording appear on both sides.
       That is the point -- it measures how identifiable a subject is from
       their own trials, i.e. an upper bound on identity information present in
       the features. It must never be quoted as a generalisation result.

    3. Features are restricted to channels real in EVERY recording. Otherwise
       the masked zeros make dataset identity trivially decodable and Acc_S
       becomes a measurement of the mask pattern rather than of the EEG.
    """
    keep = _shared_real_channels(epochs_by_subject)
    feats, tasks, subjects = [], [], []
    for subj, epochs in epochs_by_subject.items():
        filt = epochs.copy().filter(band[0], band[1], verbose=False)
        data = filt.get_data()
        if keep is not None:
            data = data[:, keep, :]
        feats.append(np.log(np.mean(data ** 2, axis=2) + 1e-20))
        inv = {v: k for k, v in epochs.event_id.items()}
        tasks.extend([inv[c] for c in epochs.events[:, 2]])
        subjects.extend([subj] * len(epochs))

    X = np.concatenate(feats, axis=0)
    y_task, y_subj = np.array(tasks), np.array(subjects)
    groups = y_subj
    n_groups = len(np.unique(groups))
    k = int(max(2, min(cv_splits, n_groups)))

    def _pipe():
        return Pipeline([("scaler", StandardScaler()),
                         ("clf", LogisticRegression(max_iter=1000,
                                                     random_state=random_state, C=1.0))])
    try:
        cv_task = StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=random_state)
        scores_task = cross_val_score(_pipe(), X, y_task, cv=cv_task, groups=groups,
                                       scoring="accuracy")
    except Exception:
        scores_task = cross_val_score(_pipe(), X, y_task, cv=GroupKFold(n_splits=k),
                                       groups=groups, scoring="accuracy")
    acc_t, std_t = float(np.mean(scores_task)), float(np.std(scores_task))

    cv_subj = StratifiedKFold(n_splits=cv_splits, shuffle=True, random_state=random_state)
    scores_subj = cross_val_score(_pipe(), X, y_subj, cv=cv_subj, scoring="accuracy")
    acc_s, std_s = float(np.mean(scores_subj)), float(np.std(scores_subj))

    n_subj = len(np.unique(y_subj))
    chance_task = float(max(pd.Series(y_task).value_counts(normalize=True)))
    results_df = pd.DataFrame([
        {"Target": "Task", "CV Strategy": f"StratifiedGroupKFold (K={k}, grouped by recording)",
         "Accuracy": f"{acc_t:.2%}", "Std": f"\u00b1{std_t:.2%}",
         "Chance (majority)": f"{chance_task:.2%}",
         "Interpretable as generalisation?": "yes"},
        {"Target": f"Subject ({n_subj} recordings)",
         "CV Strategy": f"StratifiedKFold (K={cv_splits}, TRIAL-level, within-subject)",
         "Accuracy": f"{acc_s:.2%}", "Std": f"\u00b1{std_s:.2%}",
         "Chance (majority)": f"{1.0 / n_subj:.2%}",
         "Interpretable as generalisation?": "NO -- identity probe by design"},
    ])
    print("\n============ RAW FEATURE SEPARABILITY ============")
    print(results_df.to_string(index=False))
    print(f"Features: {X.shape[1]} channels real in every recording, "
          f"{band[0]}-{band[1]} Hz log band-power.")
    print(f"Disparity (Acc_S / Acc_T): {acc_s / max(acc_t, 1e-9):.2f}x -- large values mean "
          "subject identity dominates task information in these raw features, which is "
          "the motivation for alignment/normalization, not a defect.")
    print("=" * 50 + "\n")
    return results_df, (acc_t, acc_s)
