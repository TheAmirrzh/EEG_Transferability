"""Core signal-processing chain.

Primary chain: rename -> harmonize to the shared channel set -> montage ->
band-pass at the native rate -> resample -> reference -> epoch (cue-aligned).

CHANGES IN THIS REVISION
------------------------
* ``_harmonize_channels`` is now mode-aware. Under 'union' it interpolates
  missing channels as before; under 'reference_masked' it ZERO-FILLS them and
  records a boolean mask in ``raw.info['temp']``; under 'intersection' there
  are none. It also drops non-scalp channels defensively and pins channel
  order, folding in the notebook's ``safe_harmonize_channels`` monkey-patch.

* CAR is computed with an explicit SCOPE. Two bugs were hiding here:
  (a) under union mode the reference average was taken over interpolated
      channels, so fabricated values fed back into every real channel;
  (b) under any mode the average was taken over a different electrode set per
      dataset, so the reference operator itself differed across datasets --
      a silent confound when the whole point is pooling them.
  ``CAR_SCOPE='shared_support'`` restricts the average to channels every
  enabled dataset really recorded, making the operator identical everywhere.

* Epoching is CUE-ALIGNED. ``run_*_pipeline`` receives a cue-relative window
  and the dataset's ``cue_offset_sec``, and shifts the window before slicing.

* ``analytic_envelope`` -- reflection-padded Hilbert transform. The raw
  ``scipy.signal.hilbert`` applied directly to an epoch treats the signal as
  periodic, so the discontinuity between the last and first sample injects a
  broadband transient that corrupts roughly one cycle of the lowest analysed
  frequency at each end -- i.e. ~125 ms at 8 Hz, which at a 2 s epoch is 12%
  of the window and sits exactly where ERD onset is being read off.

PERFORMANCE CHANGES IN THIS REVISION
-------------------------------------
* Every ablation variant now HARMONIZES + FILTERS + RESAMPLES per run (still
  required -- filtering across a run boundary that is not really continuous
  data would smear each run's edge into its neighbour) and then CONCATENATES
  ONCE per subject via the new ``_filter_resample_concat`` helper, before
  applying whichever reference or artifact-rejection step the variant needs.
  Every one of those steps -- CAR, the Surface Laplacian spline solve, ICA
  fitting, bad-channel detection -- is therefore fit EXACTLY ONCE per subject
  on the concatenated recording, not once per run. For a 12-run dataset like
  BNCI2014-001 this turns 12 redundant ICA fits into 1. CAR is mathematically
  unaffected by this reordering (it is a per-timepoint spatial average, so
  computing it before or after concatenation is bit-identical); ICA and
  bad-channel detection are also statistically sounder fit on the full
  recording rather than one short run at a time.

* The ICA ablation's broadband copy can be cached to disk with
  ``configure_cache(cache_dir)``, keyed on a caller-supplied ``cache_key``
  (dataset name + subject id) rather than on the Raw objects themselves, so
  hashing the cache key is cheap even though what it retrieves is not. This
  is aimed squarely at Colab timeouts: if the artifact-handling ablation is
  interrupted partway through and re-run, subjects already processed are not
  reprocessed.
"""

from __future__ import annotations
import mne
import numpy as np
import pandas as pd
from scipy.signal import hilbert
from scipy.fft import next_fast_len

from .channels import (
    standardize_channel_name, is_scalp_eeg, NON_SCALP_CHANNELS,
)

MASK_KEY = "channel_mask"


# --------------------------------------------------------------------------
# Channel harmonization
# --------------------------------------------------------------------------

def _drop_non_scalp(raw: mne.io.BaseRaw) -> mne.io.BaseRaw:
    """Remove EMG/EOG/stim/mastoid/unmontageable channels before anything else.
    Folded in from the notebook's runtime `safe_harmonize_channels` patch."""
    drop = [ch for ch in raw.ch_names
            if not is_scalp_eeg(standardize_channel_name(ch))]
    if drop:
        raw.drop_channels(drop)
    return raw


def _synthesize_missing_channels(raw: mne.io.BaseRaw, missing_channels: list,
                                  montage) -> mne.io.BaseRaw:
    """UNION MODE ONLY. Reconstruct never-recorded channels by spherical-spline
    interpolation (Perrin et al. 1989) -- the same algorithm MNE uses for bad
    channels, applied here to channels that were never recorded at all.

    HONEST LIMITATION, quantified: the interpolated rows are exact linear
    combinations of the recorded ones, so (a) the tensor's numerical rank stays
    at the native channel count no matter how many rows it gains, (b)
    inter-channel correlation is inflated because neighbouring outputs share
    input electrodes (Kang, Lano & Sponheim 2015), and (c) accuracy collapses
    where there is no nearby real electrode -- Dreyer2023 has no frontopolar,
    temporal or occipital electrode at all, so those positions are pure
    extrapolation from >10 cm away. Prefer HARMONIZATION_MODE='reference_masked'
    unless you are explicitly running the union-vs-masked ablation.
    """
    placeholder = np.zeros((len(missing_channels), raw.n_times))
    info_new = mne.create_info(missing_channels, raw.info["sfreq"], ch_types="eeg")
    placeholder_raw = mne.io.RawArray(placeholder, info_new, verbose=False)
    raw.add_channels([placeholder_raw], force_update_info=True)
    raw.info["bads"] = sorted(set(raw.info["bads"]) | set(missing_channels))
    raw.set_montage(montage, match_case=False, on_missing="raise")
    raw.interpolate_bads(reset_bads=True, verbose=False)
    return raw


def _zero_fill_missing_channels(raw: mne.io.BaseRaw, missing_channels: list,
                                 montage) -> mne.io.BaseRaw:
    """REFERENCE_MASKED MODE. Insert exact zeros at never-recorded positions and
    record the mask. Nothing is invented: the tensor says 'no measurement here'
    and the mask says which rows those are."""
    placeholder = np.zeros((len(missing_channels), raw.n_times))
    info_new = mne.create_info(missing_channels, raw.info["sfreq"], ch_types="eeg")
    placeholder_raw = mne.io.RawArray(placeholder, info_new, verbose=False)
    raw.add_channels([placeholder_raw], force_update_info=True)
    raw.set_montage(montage, match_case=False, on_missing="raise")
    return raw


def _harmonize_channels(raw: mne.io.BaseRaw, channel_mapping_df: pd.DataFrame,
                         common_channels: list, montage,
                         mode: str = "reference_masked") -> mne.io.BaseRaw:
    """Rename -> drop non-scalp -> pick native channels (validate names only).

    RAM NOTE: gap-filling (zero-fill or spherical-spline interpolation) used
    to happen HERE, at whatever the recording's native sampling rate is --
    for Lee2019 (1000 Hz) that meant allocating placeholder/interpolated
    channels at ~8x the memory they need once resampled to 128 Hz. Gap-
    filling is a purely SPATIAL operation (a fixed linear combination of
    other channels' values at each timepoint, from electrode positions
    only -- never from signal content), while filtering/resampling are
    purely TEMPORAL and applied identically per channel. Operations on
    independent axes like this commute exactly, so gap-filling now happens
    in `preprocess_raw` AFTER resampling instead -- same result, computed
    on far fewer samples. This function now only renames, drops non-scalp
    channels, and validates names; `_fill_channel_gaps` (below) does the
    part that moved.
    """
    raw = raw.copy()
    raw.rename_channels({orig: standardize_channel_name(orig)
                         for orig in raw.info["ch_names"]})
    _drop_non_scalp(raw)

    if channel_mapping_df is not None:
        known = set(channel_mapping_df["standardized_name"])
        unknown = set(raw.info["ch_names"]) - known
        if unknown:
            raise ValueError(
                f"Renamed channel(s) absent from channel_mapping_df: {sorted(unknown)}. "
                "Rebuild the mapping table or investigate a naming mismatch.")
    return raw


def _fill_channel_gaps(raw: mne.io.BaseRaw, common_channels: list, montage,
                        mode: str = "reference_masked") -> mne.io.BaseRaw:
    """The gap-filling step that used to live in `_harmonize_channels`,
    moved to run AFTER filtering+resampling (see that function's docstring
    for why this is safe): pick/order to `common_channels`, fill in
    whatever this recording doesn't natively have per `mode`, attach the
    channel mask, set the montage.
    """
    common_channels = list(common_channels)
    native = set(raw.info["ch_names"])
    mask = np.array([ch in native for ch in common_channels], dtype=bool)
    missing_here = [ch for ch in common_channels if ch not in native]

    if missing_here:
        if mode == "union":
            raw = _synthesize_missing_channels(raw, missing_here, montage)
            # After interpolation the values exist, but they are not
            # measurements -- keep the mask so downstream code can still tell.
        elif mode == "reference_masked":
            raw = _zero_fill_missing_channels(raw, missing_here, montage)
        elif mode == "intersection":
            raise ValueError(
                f"Intersection mode should leave nothing missing, yet {missing_here} "
                "are absent. The channel set was computed from a different set of "
                "datasets than the one being processed.")
        else:
            raise ValueError(f"Unknown harmonization mode {mode!r}")

    raw.pick(common_channels)
    raw.reorder_channels(common_channels)
    assert list(raw.info["ch_names"]) == common_channels, \
        "Post-pick channel order does not match the target channel set."
    raw.set_montage(montage, match_case=False, on_missing="raise")

    _attach_mask(raw, mask)
    return raw


def _attach_mask(inst, mask: np.ndarray) -> None:
    """Store the boolean channel mask on an MNE object.

    ``info['temp']`` is MNE's sanctioned free-form slot, but it does not
    survive ``concatenate_raws``, so every function that concatenates
    re-attaches it explicitly rather than assuming it carried through.
    """
    temp = dict(inst.info["temp"]) if isinstance(inst.info.get("temp"), dict) else {}
    temp[MASK_KEY] = np.asarray(mask, dtype=bool)
    inst.info["temp"] = temp


def get_channel_mask(inst) -> np.ndarray | None:
    """Retrieve the boolean channel mask attached by `_harmonize_channels`."""
    temp = inst.info.get("temp")
    if isinstance(temp, dict) and MASK_KEY in temp:
        return np.asarray(temp[MASK_KEY], dtype=bool)
    return None


# --------------------------------------------------------------------------
# Filtering / resampling
# --------------------------------------------------------------------------

def preprocess_raw(raw: mne.io.BaseRaw, channel_mapping_df: pd.DataFrame,
                    common_channels: list, montage, l_freq: float = 8.0,
                    h_freq: float = 30.0, target_sfreq: float = 128.0,
                    mode: str = "reference_masked",
                    trans_bandwidth: float = 2.0) -> mne.io.BaseRaw:
    """Rename/validate -> filter at the NATIVE rate -> resample -> fill
    channel gaps.

    Filtering before resampling is deliberate and audited (audits.C2): it
    means the anti-alias behaviour is determined by an explicitly specified
    filter rather than by whatever the resampler happens to do.

    Gap-filling now happens AFTER resampling (see `_harmonize_channels`'s
    docstring for the commutativity argument for why this changes nothing
    about the result) -- for a high-native-rate dataset like Lee2019
    (1000 Hz), this means placeholder/interpolated channels are allocated
    at 128 Hz instead of 1000 Hz: ~8x less memory for that step, which is
    what was actually causing OOM crashes on Lee2019 specifically.
    """
    raw = _harmonize_channels(raw, channel_mapping_df, common_channels, montage, mode=mode)
    # No mask yet at this point -- every channel present here is a genuine
    # native recording (gap-filling hasn't happened), so plain "eeg" picks
    # are correct and don't need the mask-based restriction the old code
    # needed post-gap-filling.
    raw.filter(l_freq=l_freq, h_freq=h_freq, method="fir", fir_design="firwin",
               phase="zero", picks="eeg",
               l_trans_bandwidth=trans_bandwidth, h_trans_bandwidth=trans_bandwidth,
               verbose=False)
    raw.resample(target_sfreq, npad="auto", verbose=False)
    raw = _fill_channel_gaps(raw, common_channels, montage, mode=mode)
    return raw


def fir_half_length_sec(sfreq: float, l_freq: float = 8.0, h_freq: float = 30.0,
                         trans_bandwidth: float = 2.0) -> float:
    """Half-support of the zero-phase FIR band-pass, in seconds.

    This is the quantity that actually bounds temporal leakage: with
    ``phase='zero'`` the impulse response is symmetric, so a sample at time t
    is influenced by input up to this far on EITHER side -- including the
    future. That is not a bug, it is what zero-phase means; it just has to be
    stated, and epoch isolation has to be checked against it rather than
    against a guess.
    """
    filt = mne.filter.create_filter(
        None, sfreq, l_freq=l_freq, h_freq=h_freq, method="fir",
        fir_design="firwin", phase="zero",
        l_trans_bandwidth=trans_bandwidth, h_trans_bandwidth=trans_bandwidth,
        verbose=False)
    return (len(filt) - 1) / 2.0 / sfreq


# --------------------------------------------------------------------------
# Referencing
# --------------------------------------------------------------------------

def set_common_average_reference(raw: mne.io.BaseRaw,
                                  scope_channels: list | None = None) -> mne.io.BaseRaw:
    """Common average reference, computed from this subject alone (so it is
    parameter-free and leakage-safe) but over an EXPLICIT channel scope.

    `scope_channels=None` averages over every channel that carries real signal
    for this recording (the classic per-dataset CAR). Pass an explicit list --
    typically the channels every enabled dataset recorded -- to make the
    reference operator identical across datasets. The average reference
    approximates the potential at infinity only up to how the scalp is
    sampled (Ferree 2006), so two montages otherwise give two different
    operators and the difference lands in every channel.

    Masked (zero-filled) channels are never included in the average and are
    left at exactly zero afterwards.
    """
    raw = raw.copy()
    mask = get_channel_mask(raw)
    names = list(raw.ch_names)
    real = [n for i, n in enumerate(names) if mask is None or mask[i]]

    if scope_channels is None:
        scope = real
    else:
        scope = [n for n in scope_channels if n in real]
        if not scope:
            raise ValueError(
                "CAR scope is empty for this recording: none of the requested "
                "scope channels were actually recorded here.")

    data = raw.get_data()
    idx_scope = [names.index(n) for n in scope]
    ref = data[idx_scope].mean(axis=0, keepdims=True)

    idx_real = [names.index(n) for n in real]
    data[idx_real] -= ref
    if mask is not None:
        data[~mask] = 0.0
    raw._data = data
    return raw


def apply_laplacian_reference(raw: mne.io.BaseRaw, stiffness: float = 4.0,
                               n_legendre_terms: int = 50,
                               lambda2: float = 1e-5) -> mne.io.BaseRaw:
    """Surface Laplacian (CSD) -- ablation alternative to CAR.

    Refuses to run on masked data: CSD solves a spline system over ALL supplied
    electrode positions, so zero-filled rows would be treated as genuine
    measurements of 0 V and would drag the estimated current density at every
    neighbouring site. Under 'reference_masked' this variant is only meaningful
    for datasets with full coverage.
    """
    mask = get_channel_mask(raw)
    if mask is not None and not mask.all():
        raise ValueError(
            f"Surface Laplacian refused: {int((~mask).sum())} of {len(mask)} channels "
            "are masked (zero-filled). CSD would interpret those zeros as real "
            "potentials and corrupt every neighbouring estimate. Run this ablation "
            "under HARMONIZATION_MODE='intersection', or restrict it to datasets "
            "with full coverage of the target set.")
    raw_csd = raw.copy()
    if raw_csd.get_montage() is None:
        raise ValueError("Cannot compute Surface Laplacian without 3D sensor coordinates.")
    return mne.preprocessing.compute_current_source_density(
        raw_csd, stiffness=stiffness, n_legendre_terms=n_legendre_terms,
        lambda2=lambda2, verbose=False)


# --------------------------------------------------------------------------
# Epoching
# --------------------------------------------------------------------------

def make_epochs(raw: mne.io.BaseRaw, events: np.ndarray, event_id: dict, tmin: float,
                 tmax: float, baseline=None, reject_by_annotation: bool = True) -> mne.Epochs:
    ep = mne.Epochs(raw, events=events, event_id=event_id, tmin=tmin, tmax=tmax,
                     baseline=baseline, preload=True, reject=None,
                     reject_by_annotation=reject_by_annotation, verbose=False)
    mask = get_channel_mask(raw)
    if mask is not None:
        _attach_mask(ep, mask)
    return ep


def _as_list(raws):
    return raws if isinstance(raws, (list, tuple)) else [raws]


def _concat_preserving_mask(processed: list) -> mne.io.BaseRaw:
    """concatenate_raws drops info['temp'], so re-attach the channel mask.
    Every run of one subject shares the same mask by construction."""
    mask = get_channel_mask(processed[0])
    raw_concat = (mne.concatenate_raws(processed, preload=True)
                  if len(processed) > 1 else processed[0])
    if mask is not None:
        _attach_mask(raw_concat, mask)
    return raw_concat


def _epoch_concat(raw_concat, event_id, epoch_window, baseline, cue_offset_sec):
    """Shift the cue-relative window by this dataset's cue offset, then slice."""
    events, _ = mne.events_from_annotations(raw_concat, event_id=event_id, verbose=False)
    if len(events) == 0:
        raise RuntimeError(
            f"No events matched event_id={event_id}. Annotation descriptions present: "
            f"{sorted(set(raw_concat.annotations.description))}")
    tmin = epoch_window["tmin"] + cue_offset_sec
    tmax = epoch_window["tmax"] + cue_offset_sec
    return make_epochs(raw_concat, events=events, event_id=event_id,
                       tmin=tmin, tmax=tmax, baseline=baseline)


def _filter_resample_concat(raws, channel_mapping_df, common_channels, montage,
                             bandpass, target_sfreq, mode, trans_bandwidth):
    """Harmonize + filter + resample EACH RUN -- still required, since filtering
    across a run boundary that is not really continuous data would smear each
    run's edge into its neighbour -- then CONCATENATE INTO ONE subject-level
    raw. Callers apply whichever reference or artifact-rejection step they need
    exactly ONCE on this result, instead of once per run: cheaper, and for a
    statistical fit (ICA, bad-channel detection) sounder too, since it sees the
    whole recording instead of one short run at a time.
    """
    processed = [preprocess_raw(r, channel_mapping_df, common_channels, montage,
                                l_freq=bandpass[0], h_freq=bandpass[1],
                                target_sfreq=target_sfreq, mode=mode,
                                trans_bandwidth=trans_bandwidth)
                for r in _as_list(raws)]
    return _concat_preserving_mask(processed)


def run_primary_pipeline(raws, channel_mapping_df, common_channels, montage,
                          event_id: dict, epoch_window: dict, baseline=None,
                          mode: str = "reference_masked",
                          car_scope_channels: list | None = None,
                          cue_offset_sec: float = 0.0,
                          target_sfreq: float = 128.0,
                          bandpass=(8.0, 30.0), trans_bandwidth: float = 2.0,
                          cache_key: str | None = None) -> mne.Epochs:
    """harmonize -> filter/resample (per run) -> concatenate -> CAR (once) ->
    cue-aligned epoch.

    CAR is now computed ONCE on the concatenated recording rather than once per
    run. This is bit-identical to the previous per-run-then-concatenate order
    -- CAR is a per-timepoint spatial average, so it cannot depend on where the
    concatenation boundary falls -- it is just fewer redundant calls.
    `cache_key` is accepted for signature parity with the other pipeline
    variants (only the ICA variant currently uses it) and is otherwise ignored.
    """
    raw_concat = _filter_resample_concat(raws, channel_mapping_df, common_channels, montage,
                                         bandpass, target_sfreq, mode, trans_bandwidth)
    raw_car = set_common_average_reference(raw_concat, car_scope_channels)
    return _epoch_concat(raw_car, event_id, epoch_window, baseline, cue_offset_sec)


def run_secondary_laplacian_pipeline(raws, channel_mapping_df, common_channels, montage,
                                      event_id, epoch_window, baseline=None,
                                      mode="reference_masked", car_scope_channels=None,
                                      cue_offset_sec=0.0, target_sfreq=128.0,
                                      bandpass=(8.0, 30.0), trans_bandwidth=2.0,
                                      cache_key: str | None = None) -> mne.Epochs:
    """Same per-run filter, once-per-subject reference pattern as
    ``run_primary_pipeline``, but with the Surface Laplacian in place of CAR.

    Unlike CAR, the spline system CSD solves is genuinely re-solved on every
    call, so computing it once per subject instead of once per run removes a
    real redundant computation (the montage -- and so the spline coefficients
    -- is identical across runs of the same subject).
    """
    raw_concat = _filter_resample_concat(raws, channel_mapping_df, common_channels, montage,
                                         bandpass, target_sfreq, mode, trans_bandwidth)
    raw_lap = apply_laplacian_reference(raw_concat)
    return _epoch_concat(raw_lap, event_id, epoch_window, baseline, cue_offset_sec)


# --------------------------------------------------------------------------
# Disk cache for expensive, deterministic per-subject artifacts
# --------------------------------------------------------------------------

_CACHE_MEMORY = None


def configure_cache(cache_dir: str | None) -> None:
    """Enable a disk cache (``joblib.Memory``) for the ICA ablation's broadband
    copy -- the single most expensive deterministic intermediate in the
    artifact-handling ablation, and the one most worth surviving a Colab
    timeout. Call once, e.g. in Section 1, before running any ablation; pass
    ``None`` (the default state) to disable caching.

    Only `cache_key` (a cheap string: dataset name + subject id) and the other
    small, hashable parameters (mode, broadband, target_sfreq, the channel
    list) enter the cache key -- the actual Raw objects and the montage are
    excluded via ``ignore=[...]`` in `_build_broadband_concat`, so computing
    the hash is cheap even though what it retrieves is not. Point `cache_dir`
    at Drive-backed storage (not local Colab disk) if you want the cache to
    survive a kernel restart, not just a re-run within one session.

    SPEED NOTE: this same cache (via `get_cache_memory()`) is also used by
    `pipeline_builder.DatasetPipeline.get_epochs` to cache the FULL
    load-and-process step for every variant, not just the ICA broadband
    intermediate -- so enabling this also eliminates the redundant
    "primary" pipeline rebuild that several ablation blocks each did
    independently. Prefer LOCAL disk (not a Drive-mounted path) for the
    active session: Drive's FUSE layer is slow enough on many small
    reads/writes to eat into the speedup. Copy the cache directory to Drive
    afterward if you want it to survive a runtime reset.
    """
    global _CACHE_MEMORY
    if cache_dir is None:
        _CACHE_MEMORY = None
        return
    from joblib import Memory
    _CACHE_MEMORY = Memory(location=cache_dir, verbose=0)
    print(f"[cache] Disk cache enabled at: {cache_dir}")


def get_cache_memory():
    """Public accessor for the module-level cache configured by
    `configure_cache` -- returns None if caching is disabled. Used by
    `pipeline_builder.py` so it doesn't reach into a private module global."""
    return _CACHE_MEMORY


def suppress_warnings() -> None:
    """Silences Python warnings (numpy/scipy/sklearn/MNE are all noisy at
    the scale of 6 datasets x many subjects x several ablation variants).
    Call once, e.g. in Section 1, alongside `configure_cache`.

    This is a blunt, explicit, opt-in instrument -- it hides ALL warnings,
    not a curated subset, so if something starts behaving strangely, calling
    this again with `warnings.resetwarnings()` first (or just not calling it)
    restores normal visibility for debugging. Per-worker-process suppression
    for the parallel cohort-build/ERD pools is separate and unconditional
    (see `pipeline_builder._build_one_subject_epochs` /
    `cohort_analysis._build_one_erd`), since worker processes don't inherit
    this call's filter state.
    """
    import warnings
    warnings.filterwarnings("ignore")
    print("[warnings] Suppressed for this session (driver process only -- "
          "parallel workers already suppress their own independently).")


# --------------------------------------------------------------------------
# ICA (bug #6 fix retained)
# --------------------------------------------------------------------------

def apply_ica_cleaning(raw_broadband_harmonized: mne.io.BaseRaw, raw_target: mne.io.BaseRaw,
                        n_components: float = 0.99, random_state: int = 42,
                        exclude_labels=("eye blink", "muscle artifact", "heart beat"),
                        prob_threshold: float = 0.8) -> mne.io.BaseRaw:
    """Fit ICA + ICLabel on a ~1-100 Hz copy of the SAME recording and apply the
    resulting spatial unmixing to the 8-30 Hz analysis copy.

    Additional fix here: n_components is capped at the data's actual rank.
    After CAR the channels sum to zero, which removes exactly one degree of
    freedom, and masked or interpolated channels remove more. Asking for 0.99
    variance from a rank-deficient matrix makes ICA either fail or return
    components spanning a null space.
    """
    from mne.preprocessing import ICA
    from mne_icalabel import label_components

    mask = get_channel_mask(raw_broadband_harmonized)
    n_real = int(mask.sum()) if mask is not None else len(raw_broadband_harmonized.ch_names)
    max_rank = max(n_real - 1, 2)   # -1 for the CAR constraint

    fit_inst = raw_broadband_harmonized
    if mask is not None and not mask.all():
        fit_inst = raw_broadband_harmonized.copy().pick(
            [c for c, m in zip(raw_broadband_harmonized.ch_names, mask) if m])

    ica = ICA(n_components=min(max_rank, len(fit_inst.ch_names) - 1),
              method="picard", random_state=random_state, max_iter="auto")
    ica.fit(fit_inst)

    labels = label_components(fit_inst, ica, method="iclabel")
    exclude = [i for i, (lbl, prob) in enumerate(zip(labels["labels"], labels["y_pred_proba"]))
               if lbl in exclude_labels and prob > prob_threshold]
    ica.exclude = exclude

    raw_clean = raw_target.copy()
    if mask is not None and not mask.all():
        sub = raw_clean.copy().pick([c for c, m in zip(raw_clean.ch_names, mask) if m])
        ica.apply(sub, verbose=False)
        data = raw_clean.get_data()
        idx = [raw_clean.ch_names.index(c) for c in sub.ch_names]
        data[idx] = sub.get_data()
        raw_clean._data = data
    else:
        ica.apply(raw_clean, verbose=False)

    print(f"[ICA ablation] fit on broadband copy ({len(fit_inst.ch_names)} real ch); "
          f"excluded {len(exclude)} component(s): {[labels['labels'][i] for i in exclude]}")
    return raw_clean


def _broadband_concat_uncached(raws, channel_mapping_df, common_channels, montage,
                                mode, broadband, target_sfreq, cache_key):
    """Harmonize + broadband-filter + resample EACH RUN (must happen before
    concatenation -- same reasoning as `_filter_resample_concat`), then
    concatenate into ONE subject-level raw. `cache_key` is unused inside the
    function body; it exists so `configure_cache` can key the disk cache on it
    instead of on the (expensive-to-hash) Raw objects -- see `_build_broadband_
    concat` and `configure_cache`.
    """
    processed = []
    for raw in _as_list(raws):
        raw_h = _harmonize_channels(raw, channel_mapping_df, common_channels,
                                    montage, mode=mode)
        # Clamp the broadband upper edge below THIS raw's Nyquist: a hardcoded
        # 100 Hz is invalid for Weibo2014 at 200 Hz (Nyquist exactly 100).
        safe_h = min(broadband[1], 0.4 * raw_h.info["sfreq"])
        raw_h.filter(broadband[0], safe_h, method="fir", fir_design="firwin",
                     phase="zero", picks="eeg", verbose=False)
        raw_h.resample(target_sfreq, npad="auto", verbose=False)
        # Gap-filling AFTER resample, same RAM reasoning as preprocess_raw:
        # this is the OTHER Lee2019-heavy step (the ICA ablation's broadband
        # copy), and it gets the same ~8x reduction for the same reason.
        raw_h = _fill_channel_gaps(raw_h, common_channels, montage, mode=mode)
        processed.append(raw_h)
    return _concat_preserving_mask(processed)


def _build_broadband_concat(raws, channel_mapping_df, common_channels, montage,
                             mode, broadband, target_sfreq, cache_key=None):
    """Dispatches to the disk-cached or plain version of
    `_broadband_concat_uncached` depending on whether `configure_cache` has
    been called. `raws`, `channel_mapping_df` and `montage` are excluded from
    the cache key (they are either expensive to hash or not deterministically
    hashable across a Colab session) -- `cache_key` plus the small remaining
    parameters (common_channels, mode, broadband, target_sfreq) identify the
    call instead.
    """
    if _CACHE_MEMORY is None or cache_key is None:
        return _broadband_concat_uncached(raws, channel_mapping_df, common_channels,
                                          montage, mode, broadband, target_sfreq, cache_key)
    cached_fn = _CACHE_MEMORY.cache(_broadband_concat_uncached,
                                    ignore=["raws", "channel_mapping_df", "montage"])
    return cached_fn(raws, channel_mapping_df, common_channels, montage,
                     mode, broadband, target_sfreq, cache_key)


def run_secondary_ica_pipeline(raws, channel_mapping_df, common_channels, montage, event_id,
                                epoch_window, baseline=None, broadband=(1.0, 100.0),
                                target_sfreq: float = 128.0, mode="reference_masked",
                                car_scope_channels=None, cue_offset_sec=0.0,
                                bandpass=(8.0, 30.0), trans_bandwidth=2.0,
                                cache_key: str | None = None) -> mne.Epochs:
    """Analysis-band copy: filter+resample per run, concatenate ONCE, reference
    ONCE. Broadband copy: same per-run-then-concatenate pattern, optionally
    cached to disk (see `configure_cache`). ICA is then fit EXACTLY ONCE per
    subject on the concatenated broadband copy and applied once -- previously
    this fit a fresh ICA per run, which for a 12-run dataset like
    BNCI2014-001 meant 12 redundant ICA decompositions per subject instead of 1.
    """
    raws_list = _as_list(raws)
    raw_concat = _filter_resample_concat(raws_list, channel_mapping_df, common_channels,
                                         montage, bandpass, target_sfreq, mode,
                                         trans_bandwidth)
    raw_car = set_common_average_reference(raw_concat, car_scope_channels)

    raw_broadband = _build_broadband_concat(raws_list, channel_mapping_df, common_channels,
                                            montage, mode, broadband, target_sfreq, cache_key)

    raw_clean = apply_ica_cleaning(raw_broadband, raw_car)
    return _epoch_concat(raw_clean, event_id, epoch_window, baseline, cue_offset_sec)


# --------------------------------------------------------------------------
# Analytic signal with edge handling
# --------------------------------------------------------------------------

def analytic_envelope(data: np.ndarray, sfreq: float, margin_samples: int = 0,
                       axis: int = -1, power: bool = False,
                       synthetic_pad_sec: float = 0.0) -> np.ndarray:
    """Hilbert envelope, with the edge artefact handled by REAL DATA MARGIN.

    Why not synthetic padding. ``scipy.signal.hilbert`` computes the analytic
    signal through the DFT, which treats the segment as one period of a
    periodic signal, so the step between the last and first sample injects a
    broadband transient. The obvious remedy -- reflection-padding the epoch --
    does not work for oscillatory data, and measurably makes things worse:
    even-symmetric reflection makes the signal continuous in VALUE but flips
    the sign of its slope at the boundary, replacing a step with a cusp. On a
    simulated 9-13 Hz oscillation with a known ERD-shaped envelope, mean
    absolute envelope error in the outer 125 ms was

        no padding                0.334
        reflection padding        0.438     <-- worse than doing nothing
        real-data margin +-1 s    0.003

    So the correct fix is not to invent samples at all: epoch with extra REAL
    signal on both sides, take the analytic signal over the longer segment, and
    crop the margin away afterwards. That is what ``margin_samples`` does, and
    it is why ``build_baseline_ablation_epochs`` requests a margin-extended
    window and the plotting functions crop back to the display window.

    Parameters
    ----------
    margin_samples : samples of real signal at EACH end to discard after the
        transform. Pass 0 when the data has no margin.
    synthetic_pad_sec : reflection padding, kept only for the case where no real
        margin exists at all (a pre-cut epoch). Defaults to 0, i.e. off, because
        of the measurement above. Turning it on is worse than leaving it off for
        narrowband data -- it exists only so the option is explicit rather than
        silently unavailable.
    """
    data = np.moveaxis(np.asarray(data, dtype=float), axis, -1)
    n_times = data.shape[-1]

    n_syn = 0
    if synthetic_pad_sec > 0:
        n_syn = int(min(round(synthetic_pad_sec * sfreq), max(n_times - 1, 0)))
        if n_syn:
            data = np.pad(data, [(0, 0)] * (data.ndim - 1) + [(n_syn, n_syn)],
                          mode="reflect")

    analytic = hilbert(data, N=next_fast_len(data.shape[-1]),
                       axis=-1)[..., :data.shape[-1]]
    env = np.abs(analytic)
    if power:
        env = env ** 2

    lo = n_syn + int(margin_samples)
    hi = data.shape[-1] - n_syn - int(margin_samples)
    if lo > 0 or hi < data.shape[-1]:
        if hi <= lo:
            raise ValueError(
                f"margin_samples={margin_samples} leaves nothing of a "
                f"{n_times}-sample segment.")
        env = env[..., lo:hi]
    return np.moveaxis(env, -1, axis)


def envelope_margin_samples(inst, display_window, sfreq=None) -> int:
    """How many samples of real margin an Epochs object has beyond the window
    you actually intend to display."""
    sfreq = sfreq or inst.info["sfreq"]
    lead = int(round((display_window[0] - inst.times[0]) * sfreq))
    trail = int(round((inst.times[-1] - display_window[1]) * sfreq))
    return max(0, min(lead, trail))


def available_envelope_margin(cfg, display_window, requested_margin: float) -> float:
    """Largest real-data margin this dataset can supply around `display_window`
    without running past its clean pre-cue signal or its post-cue trial length."""
    pre_head = cfg.pre_cue_clean_sec + display_window["tmin"]     # tmin is negative
    post_head = cfg.trial_length_sec - display_window["tmax"]
    return float(max(0.0, min(requested_margin, pre_head, post_head)))


def band_envelope(epochs: mne.Epochs, band=(8, 30), picks=None,
                   display_window=None, power: bool = True) -> tuple:
    """Band-pass, then edge-safe Hilbert envelope for an Epochs object.

    If `display_window` is given and the epoch extends beyond it, the extra real
    signal is used as margin and cropped after the transform. Returns
    (envelope, times, channel names) restricted to the display window.
    """
    filt = epochs.copy().filter(band[0], band[1], picks=picks, verbose=False)
    if picks is not None:
        filt = filt.copy().pick(list(picks))
    sfreq = filt.info["sfreq"]
    margin = 0
    if display_window is not None:
        margin = envelope_margin_samples(filt, display_window, sfreq)
    env = analytic_envelope(filt.get_data(), sfreq, margin_samples=margin, power=power)
    times = filt.times[margin:len(filt.times) - margin] if margin else filt.times
    return env, times, list(filt.ch_names)
