"""Per-channel (train-only) normalization -- the primary pipeline's choice --
plus the per-trial z-score ablation.

Mask-aware addition: a masked channel is exactly zero, so its standard
deviation is zero and the `+1e-8` floor turns it into a division by 1e-8. That
amplifies nothing (0/1e-8 == 0) but it does make the normalizer's sigma vector
report a physically meaningless 1e-8 for those rows, which then propagates into
anything that inspects the fitted statistics. Masked rows are now left at
exactly zero and reported as such.
"""

from __future__ import annotations
import numpy as np
import mne

from .signal_processing import get_channel_mask


def fit_channel_normalizer(train_epochs_list: list):
    """Fit per-channel mean/std from TRAINING-subject epochs only.

    Never pass validation/test-subject epochs -- this is the exact leakage
    boundary that audits.audit_feature_leakage and audit_normalizer_multi_split
    check (and that the previous, vacuous version of the first one failed to).
    """
    all_data = np.concatenate([ep.get_data() for ep in train_epochs_list], axis=0)
    mu = all_data.mean(axis=(0, 2), keepdims=True).squeeze(0)      # (C, 1)
    sigma = all_data.std(axis=(0, 2), keepdims=True).squeeze(0)    # (C, 1)
    dead = sigma[:, 0] <= 0
    sigma = sigma + 1e-12
    if dead.any():
        # Leave dead/masked rows untouched rather than dividing them by a
        # fictitious epsilon: mu=0, sigma=1 is the identity on a zero row.
        mu[dead, :] = 0.0
        sigma[dead, :] = 1.0
    return mu, sigma


def apply_channel_normalizer(epochs, mu: np.ndarray, sigma: np.ndarray) -> np.ndarray:
    """Apply a frozen per-channel normalizer. Returns a plain ndarray
    (n_trials, n_channels, n_times), not an in-place Epochs mutation."""
    data = epochs.get_data() if isinstance(epochs, mne.BaseEpochs) else np.asarray(epochs)
    return (data - mu[np.newaxis, :, :]) / sigma[np.newaxis, :, :]


def apply_per_trial_zscore_ablation(epochs) -> np.ndarray:
    """Per-trial, per-channel z-scoring: each trial normalized using ONLY its
    own mean/std across time.

    Trivially leakage-safe (no cross-trial statistic exists), but it also
    removes whatever subject-characteristic absolute amplitude scale a trial
    had -- which is exactly the comparison this ablation exists to make.
    Masked/flat channels stay at zero instead of becoming 0/1e-8.
    """
    data = epochs.get_data() if isinstance(epochs, mne.BaseEpochs) else np.asarray(epochs)
    mu = data.mean(axis=2, keepdims=True)
    sigma = data.std(axis=2, keepdims=True)
    dead = sigma <= 0
    sigma = np.where(dead, 1.0, sigma)
    mu = np.where(dead, 0.0, mu)
    return (data - mu) / sigma
