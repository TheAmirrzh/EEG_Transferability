"""Channel harmonization across N datasets.

THREE harmonization strategies, selected by ``GlobalConfig.HARMONIZATION_MODE``
(see config.py). This module decides *which names* belong in the shared
representation and *which dataset needs what*; the signal-level consequences
live in signal_processing.py.

    "union"            Target = union of all datasets' channels. Datasets
                       missing a target channel get it SYNTHESIZED by
                       spherical-spline interpolation (Perrin et al. 1989).
                       Keeps the largest channel count, but for a dataset
                       like Dreyer2023 (27 centro-parietal electrodes, no
                       frontopolar/temporal/occipital coverage) most of the
                       tensor becomes extrapolation, not measurement.
                       Interpolated channels are exact linear combinations
                       of the recorded ones, so the tensor's rank stays at
                       the native channel count however many rows it has,
                       and inter-channel correlation is inflated
                       (Kang, Lano & Sponheim 2015,
                       Neuropsychiatr Electrophysiol 1:9).

    "intersection"     Target = names present in EVERY enabled dataset.
                       No fabrication at all, but the shared set collapses
                       toward the smallest montage and genuinely informative
                       electrodes are discarded for every dataset.

    "reference_masked" (DEFAULT) Target = the intersection of a designated
                       set of ANCHOR datasets (default: physionet + cho2017,
                       which share ~62 10-10 positions). Every other dataset
                       is expressed in that same space: channels it really
                       recorded are kept as-is; channels it never recorded
                       are ZERO-FILLED and flagged in a per-dataset boolean
                       channel mask. No value is invented and no anchor
                       channel is deleted. Downstream code that can exploit
                       the mask (masked attention / channel dropout in a deep
                       model; rank-aware shrinkage covariance for CSP and
                       Riemannian methods) then knows exactly which of the
                       rows carry measurement.

Bug #5 fix (kept): ``standardize_channel_name`` strips only LEADING/TRAILING
separators, so internal separators survive. Extended here with the legacy
10-20 -> 10-10 alias map, without which a dataset using 'T3' and one using
'T7' are wrongly treated as different electrodes.
"""

from __future__ import annotations
import re
import mne
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mne.channels import make_standard_montage

from .config import DatasetRegistry


# --------------------------------------------------------------------------
# Name canonicalization
# --------------------------------------------------------------------------

LEGACY_TO_MODERN = {
    "T3": "T7", "T4": "T8", "T5": "P7", "T6": "P8",
}

# Not a scalp EEG electrode with a 10-05 position. Excluded from every
# harmonization mode, at source, so notebooks never post-hoc filter
# `common_channels` again.
#   CB1/CB2            inferior occipital ("cerebellar") sites, not in 10-05
#   EMG*/EOG*/HEO/VEO  peripheral physiology
#   STI*/TRIGGER       stimulus channels
#   A1/A2/M1/M2        earlobe / mastoid reference electrodes
NON_SCALP_CHANNELS = {
    "CB1", "CB2",
    "EMG1", "EMG2", "EMG3", "EMG4", "EMGD", "EMGG", "EMG",
    "EOG1", "EOG2", "EOG3", "HEO", "VEO", "HEOG", "VEOG", "EOG",
    "STI", "STIM", "STI014", "STIM014", "TRIGGER", "STATUS",
    "A1", "A2", "M1", "M2",
    "EKG", "ECG", "GSR", "RESP",
}

_MONTAGE_LOOKUP_CACHE: dict | None = None


def _montage_lookup(montage_name: str = "standard_1005") -> dict:
    global _MONTAGE_LOOKUP_CACHE
    if _MONTAGE_LOOKUP_CACHE is None:
        montage = make_standard_montage(montage_name)
        _MONTAGE_LOOKUP_CACHE = {ch.upper(): ch for ch in montage.ch_names}
    return _MONTAGE_LOOKUP_CACHE


def standardize_channel_name(name: str) -> str:
    """Canonicalize: strip leading/trailing non-alphanumerics, uppercase, then
    map legacy 10-20 labels onto 10-10 equivalents.

    'Fc5.' -> 'FC5'   'AFz..' -> 'AFZ'   'T3' -> 'T7'   'T7-T8' -> 'T7-T8'
    """
    cleaned = re.sub(r"^[^A-Za-z0-9]+|[^A-Za-z0-9]+$", "", str(name)).upper()
    return LEGACY_TO_MODERN.get(cleaned, cleaned)


def is_scalp_eeg(name: str) -> bool:
    """True when `name` (already standardized) is a scalp EEG electrode that
    also resolves to a position on the standard 10-05 montage."""
    if name in NON_SCALP_CHANNELS:
        return False
    return name in _montage_lookup()


def scalp_eeg_names(ch_names, ch_types=None) -> list[str]:
    """Standardize `ch_names`, keep only montage-resolvable scalp EEG."""
    if ch_types is not None:
        ch_names = [n for n, t in zip(ch_names, ch_types) if str(t).lower() == "eeg"]
    out, seen = [], set()
    for n in ch_names:
        std = standardize_channel_name(n)
        if is_scalp_eeg(std) and std not in seen:
            seen.add(std)
            out.append(std)
    return out


# --------------------------------------------------------------------------
# Per-channel tables
# --------------------------------------------------------------------------

def build_channel_table(ch_names, ch_types, dataset_label: str) -> pd.DataFrame:
    std_names = [standardize_channel_name(n) for n in ch_names]
    return pd.DataFrame({
        "dataset": dataset_label,
        "original_name": ch_names,
        "standardized_name": std_names,
        "channel_type": ch_types,
        "is_scalp_eeg": [is_scalp_eeg(n) for n in std_names],
    })


def filter_eeg_only(channel_df: pd.DataFrame) -> pd.DataFrame:
    """Keep only montage-resolvable scalp EEG rows, logging what was dropped.
    Now also removes CB1/CB2, EMG/EOG/stim and mastoid references, which the
    previous version let through whenever the source declared them 'eeg'."""
    keep = channel_df["is_scalp_eeg"] & (
        channel_df["channel_type"].astype(str).str.lower() == "eeg"
    )
    dropped = channel_df.loc[~keep]
    if len(dropped):
        print(f"[{channel_df['dataset'].iloc[0]}] Dropping {len(dropped)} "
              f"non-scalp/unmontageable channel(s): "
              f"{sorted(set(dropped['standardized_name']))}")
    return (channel_df.loc[keep]
            .drop_duplicates("standardized_name")
            .reset_index(drop=True))


# --------------------------------------------------------------------------
# The three target-channel strategies
# --------------------------------------------------------------------------

def compute_common_channels(*channel_dfs: pd.DataFrame):
    """Strict N-way intersection. Returns (sorted names, {dataset: extras})."""
    if len(channel_dfs) < 2:
        raise ValueError("Need at least 2 channel tables to compute a common set.")
    name_sets = {df["dataset"].iloc[0]: set(df["standardized_name"]) for df in channel_dfs}
    common = set.intersection(*name_sets.values())
    only_in = {label: sorted(names - common) for label, names in name_sets.items()}
    return sorted(common), only_in


def compute_target_channels(*channel_dfs: pd.DataFrame):
    """Union. Returns (sorted names, {dataset: names it must synthesize})."""
    if len(channel_dfs) < 2:
        raise ValueError("Need at least 2 channel tables to compute a target set.")
    name_sets = {df["dataset"].iloc[0]: set(df["standardized_name"]) for df in channel_dfs}
    target = set.union(*name_sets.values())
    needs_synthesis = {label: sorted(target - names) for label, names in name_sets.items()}
    return sorted(target), needs_synthesis


def compute_reference_channels(*channel_dfs: pd.DataFrame, anchor_datasets: list):
    """Reference-set strategy.

    The shared representation is the intersection of the ANCHOR datasets only
    (the high-density, well-covered ones -- by default PhysioNet + Cho2017,
    which share ~62 10-10 positions). Non-anchor datasets are then *masked*
    into that space rather than interpolated into it.

    Rationale: spherical-spline interpolation is a spatial-smoothness
    extrapolation whose error grows with distance from the nearest real
    electrode (Perrin et al. 1989; Kang et al. 2015), and a 22- or
    27-electrode motor montage has no measurement anywhere near many union
    positions. Masking states the missing-ness instead of guessing it and --
    unlike a plain intersection -- keeps every electrode the anchor datasets
    genuinely recorded.

    Returns (reference_channels, coverage) where coverage[label] has keys
    present / masked / dropped_extra / coverage_pct / is_anchor.
    """
    if len(channel_dfs) < 2:
        raise ValueError("Need at least 2 channel tables to compute a reference set.")
    name_sets = {df["dataset"].iloc[0]: set(df["standardized_name"]) for df in channel_dfs}

    anchors = [a for a in anchor_datasets if a in name_sets]
    if not anchors:
        raise ValueError(
            f"None of the anchor datasets {anchor_datasets} are enabled. "
            f"Enabled: {sorted(name_sets)}. Either enable one, or change "
            "GlobalConfig.ANCHOR_DATASETS / HARMONIZATION_MODE."
        )
    reference = set.intersection(*[name_sets[a] for a in anchors])
    reference_channels = sorted(reference)

    coverage = {}
    for label, names in name_sets.items():
        present = sorted(reference & names)
        coverage[label] = {
            "present": present,
            "masked": sorted(reference - names),
            "dropped_extra": sorted(names - reference),
            "coverage_pct": 100.0 * len(present) / max(len(reference), 1),
            "is_anchor": label in anchors,
        }
    return reference_channels, coverage


def resolve_target_channels(*channel_dfs: pd.DataFrame, mode: str, anchor_datasets=None):
    """Single entry point for all three strategies.

    Returns (target_channels, per_dataset_missing) where per_dataset_missing
    maps a dataset label to the target channels it does NOT natively have --
    the ones that will be interpolated ("union") or masked
    ("reference_masked"). Empty for every dataset under "intersection".
    """
    if mode == "union":
        return compute_target_channels(*channel_dfs)
    if mode == "intersection":
        target, _ = compute_common_channels(*channel_dfs)
        return target, {df["dataset"].iloc[0]: [] for df in channel_dfs}
    if mode == "reference_masked":
        target, coverage = compute_reference_channels(
            *channel_dfs, anchor_datasets=anchor_datasets or [])
        return target, {k: v["masked"] for k, v in coverage.items()}
    raise ValueError(
        f"mode must be 'union', 'intersection' or 'reference_masked', got {mode!r}")


def build_channel_masks(*channel_dfs: pd.DataFrame, target_channels: list) -> dict:
    """{dataset: bool array of len(target_channels)} -- True where that dataset
    really recorded the channel.

    Under "intersection" every mask is all-True; under "union" it marks which
    rows are interpolated rather than measured; under "reference_masked" it
    marks which rows carry signal at all. Carry this array with the tensor --
    it is the difference between a model that knows a channel is absent and
    one that believes a flat channel is a genuine measurement of zero brain
    activity.
    """
    masks = {}
    for df in channel_dfs:
        have = set(df["standardized_name"])
        masks[df["dataset"].iloc[0]] = np.array(
            [ch in have for ch in target_channels], dtype=bool)
    return masks


def summarize_channel_synthesis(*channel_dfs: pd.DataFrame,
                                 mode: str = "reference_masked",
                                 anchor_datasets=None) -> pd.DataFrame:
    """Per dataset: how many target channels are real vs. reconstructed/masked."""
    target_channels, missing_per_ds = resolve_target_channels(
        *channel_dfs, mode=mode, anchor_datasets=anchor_datasets)
    verb = {"union": "synthesized", "intersection": "dropped",
            "reference_masked": "masked"}[mode]
    rows = []
    for df in channel_dfs:
        label = df["dataset"].iloc[0]
        native = set(df["standardized_name"])
        n_native_in_target = len(native & set(target_channels))
        n_missing = len(missing_per_ds.get(label, []))
        n_t = max(len(target_channels), 1)
        rows.append({
            "dataset": label,
            "mode": mode,
            "native_channels_total": len(native),
            "target_channels": len(target_channels),
            "native_channels": n_native_in_target,
            "synthesized_channels": n_missing,   # column name kept stable
            "missing_verb": verb,
            "synthesized_pct": f"{100 * n_missing / n_t:.1f}%",
            "coverage_pct": f"{100 * n_native_in_target / n_t:.1f}%",
            "native_outside_target": len(native - set(target_channels)),
            "synthesized_names": missing_per_ds.get(label, []),
        })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Mapping table + montage verification
# --------------------------------------------------------------------------

def build_mapping_table(*channel_dfs: pd.DataFrame, common_channels: list) -> pd.DataFrame:
    per_dataset_series = {
        df["dataset"].iloc[0]: df.drop_duplicates("standardized_name")
                                 .set_index("standardized_name")["original_name"]
        for df in channel_dfs
    }
    all_names = sorted(set().union(*[set(s.index) for s in per_dataset_series.values()])
                       | set(common_channels))
    mapping = pd.DataFrame({"standardized_name": all_names})
    for label, series in per_dataset_series.items():
        mapping[f"{label}_original"] = mapping["standardized_name"].map(series)
        mapping[f"in_{label}"] = mapping[f"{label}_original"].notna()
    mapping["in_common"] = mapping["standardized_name"].isin(common_channels)
    return mapping.sort_values(["in_common", "standardized_name"],
                                ascending=[False, True]).reset_index(drop=True)


def verify_common_channels_montage(common_channels, montage_name="standard_1005"):
    montage = make_standard_montage(montage_name)
    lookup = {ch.upper(): ch for ch in montage.ch_names}
    resolved, missing = {}, []
    for name in common_channels:
        if name in lookup:
            resolved[name] = lookup[name]
        else:
            missing.append(name)
    print(f"Montage '{montage_name}': {len(resolved)}/{len(common_channels)} "
          f"target channels resolved to a known scalp position.")
    if missing:
        print("MISSING from montage (needs manual resolution):", missing)
    return montage, resolved, missing


# --------------------------------------------------------------------------
# Harmonization audit
# --------------------------------------------------------------------------

def analyze_dataset_harmonization(registry: DatasetRegistry, target_sfreq: float = 128.0,
                                   epoch_duration_sec: float = 2.0,
                                   mode: str = "reference_masked",
                                   anchor_datasets=None):
    """N-way harmonization audit driven entirely by `registry.enabled()`.

    `mode` must match whatever the pipeline actually processes data with --
    passing a different one here silently produces a channel list inconsistent
    with the rest of the run, which is how `common_channels` used to get
    overwritten mid-notebook.
    """
    anchor_datasets = anchor_datasets or []
    common_channels, per_dataset_names = registry.compute_channels(
        standardize_channel_name, mode=mode, anchor_datasets=anchor_datasets)
    rows = registry.summary_table_rows(standardize_channel_name, mode=mode,
                                        anchor_datasets=anchor_datasets)
    target_time_samples = int(epoch_duration_sec * target_sfreq)
    verb = {"union": "Synthesized", "intersection": "Dropped",
            "reference_masked": "Masked"}[mode]
    n_t = max(len(common_channels), 1)

    audit_summary = pd.DataFrame([
        {
            "Dataset": r["dataset"],
            "Native sfreq (Hz)": r["native_sfreq"],
            "Target sfreq (Hz)": target_sfreq,
            "Native EEG Ch": r["native_ch_count"],
            "Real ch in target": r["retained_ch_count"],
            "Native ch dropped": r["dropped_count"],
            f"{verb} count": r["missing_count"],
            f"{verb} %": f"{100 * r['missing_count'] / n_t:.1f}%",
            "Real-signal coverage": f"{100 * r['retained_ch_count'] / n_t:.1f}%",
            "Trial tensor (C x T)": f"({len(common_channels)}, {target_time_samples})",
        }
        for r in rows
    ])

    print(f"\n========= DATASET HARMONIZATION AUDIT -- mode='{mode}' "
          f"({len(rows)} dataset(s) enabled) =========")
    print(audit_summary.to_string(index=False))
    print(f"\nShared representation: X_i in R^({len(common_channels)} x "
          f"{target_time_samples}) @ {target_sfreq} Hz")
    if mode == "union":
        worst = max(rows, key=lambda r: r["missing_count"])
        print(f"WARNING: union mode reconstructs {worst['missing_count']}/{len(common_channels)} "
              f"channels for '{worst['dataset']}' by spherical-spline interpolation. "
              "Interpolated rows are exact linear combinations of that dataset's real "
              f"channels, so its tensor rank stays at ~{worst['native_ch_count']} however "
              "many rows it has, and inter-channel correlation is inflated "
              "(Kang, Lano & Sponheim 2015).")
    if mode == "reference_masked":
        print(f"Anchor dataset(s) defining the reference set: {anchor_datasets}. "
              "Non-anchor datasets are zero-filled + masked at absent positions; "
              "no value is interpolated and no anchor channel is deleted.")
    print("=" * 84 + "\n")

    montage = make_standard_montage("standard_1005")
    lookup = {ch.upper(): ch for ch in montage.ch_names}
    all_studied = sorted(set().union(*per_dataset_names.values()))
    resolved_chans = [lookup[ch] for ch in all_studied if ch in lookup]
    info = mne.create_info(ch_names=resolved_chans, sfreq=target_sfreq, ch_types="eeg")
    info.set_montage(montage)

    common_set = set(common_channels)
    node_colors = ["teal" if ch.upper() in common_set else "crimson" for ch in resolved_chans]

    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    mne.viz.plot_sensors(info, kind="topomap", ch_type="eeg", axes=ax, show=False,
                          show_names=True, pointsize=26, linewidth=1.2)
    ax.collections[0].set_color(node_colors)

    outside = sorted(set(all_studied) - common_set)
    legend_elements = [
        plt.Line2D([0], [0], marker='o', color='w',
                   label=f'In shared representation (n={len(common_set)})',
                   markerfacecolor='teal', markersize=9),
        plt.Line2D([0], [0], marker='o', color='w',
                   label=f'Outside it, dataset-exclusive (n={len(outside)})',
                   markerfacecolor='crimson', markersize=9),
    ]
    ax.legend(handles=legend_elements, loc="lower center", bbox_to_anchor=(0.5, -0.14),
              fontsize=8.5, frameon=True)
    ax.set_title(fr"Electrode harmonization -- {mode} ({len(rows)} datasets, $C={len(common_set)}$)",
                 fontsize=11, fontweight="bold", pad=12)
    fig.tight_layout()
    return fig, audit_summary, common_channels
