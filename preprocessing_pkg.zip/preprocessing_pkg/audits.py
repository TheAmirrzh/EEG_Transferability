"""Validation suite: leakage (L1-L5), temporal/ordering properties (T1-T4),
general invariants (V1-V5).

TERMINOLOGY CORRECTION
----------------------
The previous version called two of these tests "causality" audits. Neither is
about causality, and the mislabelling hid a real problem:

* CAR is a *memoryless* (instantaneous) spatial operator. "Causal" would only
  be a meaningful claim if CAR had temporal memory to begin with; it does not.
  The property being checked is that the output at sample t depends on input
  at sample t alone. Renamed ``audit_car_memoryless``. It now also calls the
  real ``set_common_average_reference`` instead of recomputing the average
  inline, which made the old test a tautology about its own arithmetic.

* The band-pass filter is applied with ``phase='zero'``, which is NON-CAUSAL
  BY CONSTRUCTION: the impulse response is symmetric, so output at time t
  depends on input both before and after t. This is normal and correct for
  offline analysis, but it means the honest question is not "is it causal" but
  "how far can energy travel, and is that further than the gap between
  trials?". ``audit_filter_leakage_bound`` computes the actual FIR half-support
  from ``mne.filter.create_filter`` and checks the guard distance against it,
  instead of assuming 1.5 s is far enough. At 160 Hz with a 2 Hz transition
  band the half-support is about 1.65 s, so the old fixed guard was inside the
  filter's reach and the test could pass or fail for the wrong reason.

* ``audit_epoch_isolation`` is new and is the one that actually matters for
  the data: it checks whether adjacent trials are far enough apart that the
  zero-phase filter cannot carry one trial's energy into the next trial's
  epoch.
"""

from __future__ import annotations
import hashlib
import logging
import numpy as np
import mne

from .channels import standardize_channel_name
from .normalization import fit_channel_normalizer
from .signal_processing import (
    preprocess_raw, set_common_average_reference, make_epochs,
    get_channel_mask, fir_half_length_sec, _harmonize_channels, _fill_channel_gaps,
)
from .pipeline_builder import DatasetPipeline

logger = logging.getLogger("preprocessing_pkg.audits")
logging.basicConfig(level=logging.INFO, format="%(message)s")


# --------------------------------------------------------------------------
# Structural equivalence
# --------------------------------------------------------------------------

def assert_channel_equivalence(epochs_dict_or_list, expected_channels: list,
                                expected_sample_length: int = 256,
                                allow_masked: bool = True) -> bool:
    """Every Epochs has the same channels, in the same order, with the declared
    tensor shape, no NaN/Inf and no unexpectedly flat channel.

    MASK-AWARE. The previous version asserted every channel has std > 1e-10,
    which is correct under 'intersection' and 'union' but is guaranteed to FAIL
    under 'reference_masked', where absent channels are exactly zero on
    purpose. Masked channels are now required to be exactly zero, and only
    channels the mask marks as real are required to be non-flat.
    """
    if isinstance(epochs_dict_or_list, mne.BaseEpochs):
        epochs_map = {"S_single": epochs_dict_or_list}
    elif isinstance(epochs_dict_or_list, list):
        epochs_map = {f"S{i+1:03d}": ep for i, ep in enumerate(epochs_dict_or_list)}
    elif isinstance(epochs_dict_or_list, dict):
        epochs_map = epochs_dict_or_list
    else:
        raise TypeError(f"Unsupported input type: {type(epochs_dict_or_list)}")

    expected = [ch.upper() for ch in expected_channels]
    n_exp = len(expected)
    n_masked_total = 0

    for subj_id, epochs in epochs_map.items():
        names = [ch.upper() for ch in epochs.ch_names]
        assert len(names) == n_exp, (
            f"[{subj_id}] Channel count mismatch: expected {n_exp}, got {len(names)}")
        assert names == expected, (
            f"[{subj_id}] Channel order/name mismatch.\nExpected: {expected}\nFound: {names}")

        data = epochs.get_data()
        assert data.shape[1] == n_exp, f"[{subj_id}] Tensor channel dim {data.shape[1]} != {n_exp}"
        assert data.shape[2] == expected_sample_length, (
            f"[{subj_id}] Tensor time dim {data.shape[2]} != {expected_sample_length}")
        assert np.isfinite(data).all(), f"[{subj_id}] Tensor contains NaN/Inf!"

        mask = get_channel_mask(epochs)
        if mask is None:
            mask = np.ones(n_exp, dtype=bool)
        ch_stds = np.std(data, axis=-1)                 # (n_trials, n_channels)
        real_stds = ch_stds[:, mask]
        assert np.all(real_stds > 1e-13), (
            f"[{subj_id}] A channel marked as REAL is flat -- that is a dead electrode "
            "or a harmonization bug, not an intentional mask.")
        if not mask.all():
            if not allow_masked:
                raise AssertionError(
                    f"[{subj_id}] {int((~mask).sum())} masked channel(s) present but "
                    "allow_masked=False.")
            assert np.allclose(data[:, ~mask, :], 0.0, atol=0), (
                f"[{subj_id}] Masked channels are not exactly zero -- something wrote "
                "into positions that were supposed to carry no measurement.")
            n_masked_total += int((~mask).sum())

    print(f"PASSED: channel equivalence across {len(epochs_map)} recording(s) "
          f"({n_exp} channels, identical spatial indexing"
          + (f"; masked positions present and exactly zero" if n_masked_total else "")
          + ").")
    return True


# --------------------------------------------------------------------------
# T1 -- CAR is memoryless (was: "CAR is causal")
# --------------------------------------------------------------------------

def audit_car_memoryless(raw: mne.io.BaseRaw, common_channels: list = None, montage=None,
                          channel_mapping_df=None, mode: str = "reference_masked",
                          car_scope_channels=None, perturb_sample: int = 24000,
                          perturb_channel_idx: int = 0, perturb_magnitude: float = 50e-6,
                          tolerance: float = 1e-15) -> bool:
    """T1: perturbing one channel at one sample must change the referenced
    signal at that sample only.

    Two fixes over the old ``audit_car_instantaneous``:
      * it calls the REAL ``set_common_average_reference`` rather than
        recomputing ``data - data.mean(0)`` inline, so it tests the pipeline
        instead of restating its own arithmetic;
      * it goes through ``_harmonize_channels``, so the perturbed channel is
        one the pipeline would actually reference over -- perturbing a masked
        (zero-filled) channel is a no-op and the old version could silently
        pick one.
    """
    raw_h = _harmonize_channels(raw.copy(), channel_mapping_df, common_channels,
                                 montage, mode=mode) if common_channels else raw.copy()
    if common_channels:
        # _harmonize_channels no longer fills gaps/picks/sets montage itself
        # (moved to _fill_channel_gaps, called after resample in the real
        # pipeline for RAM reasons) -- this audit works on one small raw and
        # needs the full picture immediately, so call it right here instead.
        raw_h = _fill_channel_gaps(raw_h, common_channels, montage, mode=mode)
    mask = get_channel_mask(raw_h)
    real_idx = np.where(mask)[0] if mask is not None else np.arange(len(raw_h.ch_names))
    ch_idx = int(real_idx[min(perturb_channel_idx, len(real_idx) - 1)])

    n_samples = raw_h.n_times
    sample_idx = perturb_sample if perturb_sample < n_samples else n_samples // 2

    ref_orig = set_common_average_reference(raw_h, car_scope_channels).get_data()

    raw_p = raw_h.copy()
    d = raw_p.get_data()
    d[ch_idx, sample_idx] += perturb_magnitude
    raw_p._data = d
    ref_pert = set_common_average_reference(raw_p, car_scope_channels).get_data()

    abs_diff = np.abs(ref_pert - ref_orig)
    changed = np.where(np.max(abs_diff, axis=0) > tolerance)[0]

    if len(changed) == 1 and changed[0] == sample_idx:
        logger.info(f"PASS: T1 - the average reference is memoryless (only sample "
                    f"{sample_idx} changed, on channel '{raw_h.ch_names[ch_idx]}').")
        return True
    if len(changed) == 0:
        logger.error("T1 FAILED: no sample changed. Either the perturbed channel is "
                      "outside the CAR scope, or it is masked.")
        return False
    logger.error(f"T1 FAILED: the reference has memory -- samples other than "
                  f"{sample_idx} changed: {changed[changed != sample_idx][:10]}")
    return False


# --------------------------------------------------------------------------
# T2 -- filter leakage bound (was: "temporal causality")
# --------------------------------------------------------------------------

def continuous_filter_helper(raw_inst, l_freq=8.0, h_freq=30.0, trans_bandwidth=2.0):
    return raw_inst.filter(l_freq, h_freq, method="fir", fir_design="firwin",
                            phase="zero", l_trans_bandwidth=trans_bandwidth,
                            h_trans_bandwidth=trans_bandwidth, verbose=False)


def audit_filter_leakage_bound(raw: mne.io.BaseRaw, event_id: dict,
                                primary_epoch_window: dict, cue_offset_sec: float = 0.0,
                                l_freq: float = 8.0, h_freq: float = 30.0,
                                trans_bandwidth: float = 2.0,
                                guard_sec: float | None = None,
                                tolerance: float = 1e-9) -> dict:
    """T2: how far can a perturbation travel backwards in time through the
    band-pass, and is the declared guard distance actually outside that reach?

    The pipeline filters with ``phase='zero'``, which is non-causal by
    construction: the FIR impulse response is symmetric about its centre, so
    the output at time t depends on input up to ``fir_half_length_sec`` on
    EITHER side, future included. That is standard for offline analysis; the
    thing that has to be true is not "no future influence" but "no influence
    from the NEXT TRIAL".

    The old test injected a perturbation at tmax + 1.5 s and asserted zero
    leakage. At PhysioNet's 160 Hz with a 2 Hz transition band the half-support
    is about 1.65 s, so the perturbation was INSIDE the filter's reach and the
    assertion was testing numerical luck rather than a property.

    Returns a dict with the measured half-support, the guard used, and the
    observed leakage, and warns rather than silently passing when the guard is
    too small.
    """
    sfreq = raw.info["sfreq"]
    half = fir_half_length_sec(sfreq, l_freq, h_freq, trans_bandwidth)
    if guard_sec is None:
        guard_sec = half * 1.25 + 0.1     # comfortably outside the reach

    raw_filt = continuous_filter_helper(raw.copy(), l_freq, h_freq, trans_bandwidth)
    events, _ = mne.events_from_annotations(raw_filt, event_id=event_id, verbose=False)
    tmin = primary_epoch_window["tmin"] + cue_offset_sec
    tmax = primary_epoch_window["tmax"] + cue_offset_sec
    ep_kw = dict(events=events, event_id=event_id, tmin=tmin, tmax=tmax,
                 baseline=None, preload=True, verbose=False)
    data_unperturbed = mne.Epochs(raw_filt, **ep_kw).get_data()

    raw_p = raw.copy()
    n = raw_p.n_times
    for ev in events:
        idx = int(ev[0] - raw_p.first_samp + (tmax + guard_sec) * sfreq)
        if 0 <= idx and idx + 100 < n:
            raw_p._data[:, idx:idx + 100] += 1000.0
    data_perturbed = mne.Epochs(
        continuous_filter_helper(raw_p, l_freq, h_freq, trans_bandwidth), **ep_kw).get_data()

    leak = float(np.max(np.abs(data_unperturbed - data_perturbed)))
    passed = leak <= tolerance
    result = dict(fir_half_support_sec=half, guard_sec=guard_sec,
                  max_backward_leakage=leak, passed=passed)

    logger.info(
        f"T2: zero-phase FIR half-support = {half:.3f}s at {sfreq:.0f} Hz "
        f"({l_freq}-{h_freq} Hz, {trans_bandwidth} Hz transition). "
        f"The filter is NON-CAUSAL by design; this bounds its reach.")
    if passed:
        logger.info(f"PASS: T2 - a perturbation {guard_sec:.3f}s past the epoch end "
                    f"leaves it untouched (max delta {leak:.2e} V).")
    else:
        logger.warning(f"T2 ALERT: leakage {leak:.2e} V from {guard_sec:.3f}s away. "
                        f"Increase the guard past {half:.3f}s, or narrow the transition "
                        "band, before trusting epoch isolation.")
    return result


def audit_epoch_isolation(raw: mne.io.BaseRaw, event_id: dict, epoch_window: dict,
                           cue_offset_sec: float = 0.0, l_freq: float = 8.0,
                           h_freq: float = 30.0, trans_bandwidth: float = 2.0) -> dict:
    """T3: can the zero-phase filter carry one trial's signal into the next
    trial's epoch?

    This is the practically important version of T2 and it did not exist
    before. With a symmetric FIR of half-support H, a trial's epoch spanning
    [tmin, tmax] draws on continuous signal over [tmin - H, tmax + H]. If the
    median inter-trial interval is smaller than that span, neighbouring trials
    overlap in the filtered signal -- which inflates any cross-validation that
    puts adjacent trials in different folds, and blurs ERD onset estimates.

    (Subject-grouped CV protects you from the first consequence, since whole
    subjects move together. It does not protect within-subject analyses.)
    """
    sfreq = raw.info["sfreq"]
    half = fir_half_length_sec(sfreq, l_freq, h_freq, trans_bandwidth)
    events, _ = mne.events_from_annotations(raw, event_id=event_id, verbose=False)
    onsets = events[:, 0] / sfreq
    iti = float(np.median(np.diff(onsets))) if len(onsets) > 1 else float("nan")
    tmin = epoch_window["tmin"] + cue_offset_sec
    tmax = epoch_window["tmax"] + cue_offset_sec
    span = (tmax + half) - (tmin - half)
    overlap = span - iti
    ok = overlap <= 0
    result = dict(median_iti_sec=iti, effective_support_sec=span,
                  fir_half_support_sec=half, overlap_sec=max(overlap, 0.0), passed=ok)
    if ok:
        logger.info(f"PASS: T3 - effective epoch support {span:.2f}s fits inside the "
                    f"{iti:.2f}s median inter-trial interval.")
    else:
        logger.warning(
            f"T3 ALERT: effective epoch support is {span:.2f}s (window {tmax - tmin:.2f}s "
            f"+ 2x{half:.2f}s of filter reach) but trials are only {iti:.2f}s apart, so "
            f"adjacent trials overlap by {overlap:.2f}s in the filtered signal. Keep "
            "subject-grouped CV, and do not read within-subject trial independence "
            "into these epochs.")
    return result


def audit_filter_resample_order(raw_native, l_freq=8.0, h_freq=30.0, target_sfreq=128.0,
                                 trans_bandwidth=2.0) -> bool:
    """T4: the pipeline really filters at the native rate before resampling."""
    def filt(r):
        return r.filter(l_freq=l_freq, h_freq=h_freq, method="fir", fir_design="firwin",
                        phase="zero", l_trans_bandwidth=trans_bandwidth,
                        h_trans_bandwidth=trans_bandwidth, verbose=False)

    ref_filter_first = filt(raw_native.copy())
    ref_filter_first.resample(target_sfreq, npad="auto", verbose=False)

    ref_resample_first = raw_native.copy()
    ref_resample_first.resample(target_sfreq, npad="auto", verbose=False)
    filt(ref_resample_first)

    actual = filt(raw_native.copy())
    actual.resample(target_sfreq, npad="auto", verbose=False)

    d_same = np.max(np.abs(actual.get_data() - ref_filter_first.get_data()))
    d_diff = np.max(np.abs(actual.get_data() - ref_resample_first.get_data()))
    passed = d_same < 1e-10 and d_diff > 1e-8
    if passed:
        logger.info(f"PASS: T4 - matches filter-then-resample (delta={d_same:.2e}), "
                    f"diverges from resample-then-filter (delta={d_diff:.2e}).")
    else:
        logger.error("T4 ALERT: output does not match the declared filter-before-resample order.")
    return passed


def audit_epoch_boundary_containment(raw_car, events, event_id, window,
                                      cue_offset_sec: float = 0.0, n_spot_check=5) -> bool:
    """T5: each epoch is an EXACT slice of the continuous signal.

    Bug fixed: the previous version indexed the raw array with ``ev[0]``
    directly. MNE event samples are absolute, i.e. they include
    ``raw.first_samp``, while ``raw.get_data()`` is zero-based. For any
    recording with a non-zero first sample -- normal in EDF+ and in several
    MOABB readers -- every comparison was shifted and the test either failed
    spuriously or compared the wrong window.
    """
    tmin = window["tmin"] + cue_offset_sec
    tmax = window["tmax"] + cue_offset_sec
    epochs = make_epochs(raw_car, events=events, event_id=event_id,
                          tmin=tmin, tmax=tmax, baseline=None)
    sfreq = raw_car.info["sfreq"]
    raw_data = raw_car.get_data()
    ep_data = epochs.get_data()
    first_samp = int(raw_car.first_samp)
    for i, ev in enumerate(epochs.events[:n_spot_check]):
        start = int(ev[0]) - first_samp + int(round(tmin * sfreq))
        stop = start + ep_data[i].shape[-1]
        if start < 0 or stop > raw_data.shape[-1]:
            logger.error(f"BOUNDARY ALERT: epoch {i} falls outside the recording.")
            return False
        if not np.allclose(raw_data[:, start:stop], ep_data[i], atol=1e-12):
            logger.error(f"BOUNDARY ALERT: epoch {i} is not an exact "
                         f"[{tmin:.3f}, {tmax:.3f}]s slice.")
            return False
    logger.info(f"PASS: T5 - epochs exactly match their declared "
                f"[{tmin:.3f}, {tmax:.3f}]s slice (first_samp={first_samp} accounted for).")
    return True


# --------------------------------------------------------------------------
# Leakage
# --------------------------------------------------------------------------

def audit_subject_split_integrity(train_subject_ids, test_subject_ids) -> bool:
    """L1: train/test subject sets are disjoint."""
    overlap = set(train_subject_ids) & set(test_subject_ids)
    if overlap:
        logger.error(f"LEAKAGE: subject(s) {overlap} appear in BOTH train and test.")
        return False
    logger.info(f"PASS: L1 - train ({len(train_subject_ids)}) and test "
                f"({len(test_subject_ids)}) subject sets are disjoint.")
    return True


def audit_channel_set_determinism(registry, mode: str = "reference_masked",
                                   anchor_datasets=None) -> bool:
    """L2: the shared channel set is a deterministic function of channel NAMES
    under the mode actually in use.

    The old version always called ``compute_common_channels`` (intersection)
    regardless of configuration, so it certified a channel set the pipeline was
    not using.
    """
    a, _ = registry.compute_channels(standardize_channel_name, mode=mode,
                                      anchor_datasets=anchor_datasets)
    b, _ = registry.compute_channels(standardize_channel_name, mode=mode,
                                      anchor_datasets=anchor_datasets)
    if a != b:
        logger.error("NON-DETERMINISM: the channel set changed between identical calls.")
        return False
    logger.info(f"PASS: L2 - channel set is deterministic and name-only "
                f"({len(a)} channels, mode='{mode}', "
                f"{len(registry.enabled())} dataset(s) enabled).")
    return True


def audit_duplicate_trials(epochs_by_subject: dict) -> bool:
    """L3: no bit-identical trial appears under two different subject keys."""
    seen, duplicates = {}, []
    for subj, epochs in epochs_by_subject.items():
        data = epochs.get_data()
        for t in range(len(data)):
            h = hashlib.sha256(np.ascontiguousarray(data[t]).tobytes()).hexdigest()
            if h in seen and seen[h][0] != subj:
                duplicates.append((seen[h], (subj, t)))
            seen[h] = (subj, t)
    if duplicates:
        logger.error(f"LEAKAGE: {len(duplicates)} duplicate trial(s) across subjects: "
                     f"{duplicates[:5]}")
        return False
    n_total = sum(len(e) for e in epochs_by_subject.values())
    logger.info(f"PASS: L3 - no duplicate trials across {len(epochs_by_subject)} "
                f"recordings ({n_total} trials hashed).")
    return True


def audit_feature_leakage(train_epochs_list, unseen_test_epochs, fit_normalizer_fn,
                           apply_normalizer_fn, tolerance: float = 1e-9) -> bool:
    """L4: normalization parameters are fitted strictly on training subjects.

    THE OLD TEST WAS VACUOUS. It built ``perturbed_test_epochs =
    unseen_test_epochs.copy()``, mutated the COPY, and then refit the
    normalizer on the unchanged ``train_epochs_list``. Of course nothing
    changed -- the copy was never connected to anything. The test would have
    passed even if ``fit_normalizer_fn`` had been handed the test data
    directly.

    This version perturbs the actual test object in place, refits, and restores
    it, so a normalizer that touched test data would be caught.
    """
    mu_train, sigma_train = fit_normalizer_fn(train_epochs_list)

    test_raw = unseen_test_epochs.get_data().copy()
    test_norm = apply_normalizer_fn(unseen_test_epochs, mu_train, sigma_train)
    assert test_raw.shape == test_norm.shape, "Dimension mismatch after normalization!"

    # If the test subject came out perfectly standardised, the statistics must
    # have been computed from it.
    m = np.mean(test_norm, axis=(0, 2))
    s = np.std(test_norm, axis=(0, 2))
    finite = np.isfinite(m) & np.isfinite(s) & (s > 0)
    if finite.any() and (np.all(np.abs(m[finite]) < 1e-6)
                         and np.all(np.abs(s[finite] - 1.0) < 1e-6)):
        logger.error("LEAKAGE: the test subject appears self-normalized.")
        return False

    original = unseen_test_epochs._data.copy()
    try:
        unseen_test_epochs._data = original * 100.0 + 50.0
        mu_after, sigma_after = fit_normalizer_fn(train_epochs_list)
    finally:
        unseen_test_epochs._data = original

    d_mu = float(np.max(np.abs(mu_train - mu_after)))
    d_sigma = float(np.max(np.abs(sigma_train - sigma_after)))
    if d_mu > tolerance or d_sigma > tolerance:
        logger.error(f"LEAKAGE: the normalizer responds to unseen test data "
                     f"(delta_mu={d_mu:.2e}, delta_sigma={d_sigma:.2e}).")
        return False
    logger.info("PASS: L4 - leave-subjects-out normalizer independence verified "
                "(test object perturbed in place, not on a detached copy).")
    return True


def audit_normalizer_multi_split(epochs_by_subject: dict, n_random_splits=5, test_size=3,
                                  random_state=42, tolerance=1e-9) -> bool:
    """L5: the same independence across several random leave-subjects-out splits."""
    rng = np.random.RandomState(random_state)
    ids = list(epochs_by_subject.keys())
    test_size = min(test_size, max(len(ids) - 2, 1))
    all_passed = True
    for i in range(n_random_splits):
        shuffled = ids.copy()
        rng.shuffle(shuffled)
        test_ids, train_ids = shuffled[:test_size], shuffled[test_size:]
        train_list = [epochs_by_subject[s] for s in train_ids]

        mu_before, _ = fit_channel_normalizer(train_list)
        subj = test_ids[0]
        original = epochs_by_subject[subj]._data.copy()
        try:
            epochs_by_subject[subj]._data = original * 999.0 + 123.0
            mu_after, _ = fit_channel_normalizer(train_list)
        finally:
            epochs_by_subject[subj]._data = original

        delta = float(np.max(np.abs(mu_before - mu_after)))
        passed = delta < tolerance
        all_passed &= passed
        logger.info(f"  split {i}: train={len(train_ids)} subj, test={test_ids}, "
                    f"delta={delta:.2e} -> {'PASS' if passed else 'FAIL'}")
    logger.info(f"{'PASS' if all_passed else 'FAIL'}: L5 - normalizer train/test "
                f"independence across {n_random_splits} random splits.")
    return all_passed


# --------------------------------------------------------------------------
# General invariants
# --------------------------------------------------------------------------

def audit_cohort_tensor_consistency(epochs_by_subject: dict, expected_sfreq=128.0) -> bool:
    """V1: identical channel count/order/sfreq across every recording."""
    ref_subj = next(iter(epochs_by_subject))
    ref_names = epochs_by_subject[ref_subj].ch_names
    ref_sfreq = epochs_by_subject[ref_subj].info["sfreq"]
    ok = True
    for subj, epochs in epochs_by_subject.items():
        if epochs.ch_names != ref_names:
            logger.error(f"CONSISTENCY: {subj} channel order differs from {ref_subj}.")
            ok = False
        if abs(epochs.info["sfreq"] - ref_sfreq) > 1e-6 or \
           abs(epochs.info["sfreq"] - expected_sfreq) > 1e-6:
            logger.error(f"CONSISTENCY: {subj} sfreq mismatch.")
            ok = False
    logger.info(f"{'PASS' if ok else 'FAIL'}: V1 - tensor consistency across "
                f"{len(epochs_by_subject)} recordings ({len(ref_names)} ch @ {ref_sfreq} Hz).")
    return ok


def audit_cohort_finite_values(epochs_by_subject: dict, raw_processed_dict: dict = None) -> bool:
    """V2: no NaN/Inf anywhere."""
    ok = True
    for subj, epochs in epochs_by_subject.items():
        if not np.all(np.isfinite(epochs.get_data())):
            logger.error(f"FINITE-VALUE: {subj} epochs contain non-finite value(s).")
            ok = False
    if raw_processed_dict:
        for subj, raw in raw_processed_dict.items():
            if not np.all(np.isfinite(raw.get_data())):
                logger.error(f"FINITE-VALUE: {subj}'s processed raw is non-finite.")
                ok = False
    logger.info(f"{'PASS' if ok else 'FAIL'}: V2 - all values finite across "
                f"{len(epochs_by_subject)} recordings.")
    return ok


def audit_pipeline_determinism(pipe: DatasetPipeline, subject_id: int) -> bool:
    """V3: repeated runs of the deterministic chain are bit-identical."""
    d1 = pipe.get_epochs(subject_id, variant="primary").get_data()
    d2 = pipe.get_epochs(subject_id, variant="primary").get_data()
    same = np.array_equal(d1, d2)
    tag = f"{pipe.cfg.name}/S{subject_id:03d}"
    if same:
        logger.info(f"PASS: V3 - pipeline is bit-for-bit deterministic for {tag}.")
    else:
        logger.error(f"NON-DETERMINISM: repeated runs for {tag} differ "
                     f"(max delta={np.max(np.abs(d1 - d2)):.2e}).")
    return same


def audit_trial_count_bounds(epochs_by_subject: dict, min_trials_per_class=5,
                              max_class_imbalance_ratio=2.0) -> bool:
    """V4: flags suspiciously few trials or severe class imbalance."""
    ok = True
    for subj, epochs in epochs_by_subject.items():
        counts = {label: int((epochs.events[:, 2] == code).sum())
                  for label, code in epochs.event_id.items()}
        for label, n in counts.items():
            if n < min_trials_per_class:
                logger.error(f"TRIAL-COUNT: {subj} has only {n} '{label}' trials.")
                ok = False
        if len(counts) == 2:
            vals = list(counts.values())
            ratio = max(vals) / max(min(vals), 1)
            if ratio > max_class_imbalance_ratio:
                logger.error(f"CLASS-BALANCE: {subj} class ratio {ratio:.2f}x ({counts}).")
                ok = False
    logger.info(f"{'PASS' if ok else 'FAIL'}: V4 - trial counts/class balance within "
                f"bounds for {len(epochs_by_subject)} recordings.")
    return ok


def audit_effective_rank(epochs_by_subject: dict, tol_rel: float = 1e-10) -> "pd.DataFrame":
    """V5 (new): report the numerical rank of each recording's channel space.

    This is the number that makes the harmonization trade-off concrete.
    Expectations:
      * CAR removes exactly one degree of freedom, so a fully-sampled dataset
        should show rank C-1.
      * A masked dataset should show rank (n_real - 1).
      * A UNION-interpolated dataset shows rank (n_native - 1) no matter how
        many rows the tensor has -- the extra rows carry no extra information,
        which is the quantitative statement of why interpolating 27 channels up
        to 82 does not create 55 channels of data.
    Any covariance-based method (CSP, Riemannian tangent space) needs shrinkage
    to be defined at all on these matrices.
    """
    import pandas as pd
    rows = []
    for subj, ep in epochs_by_subject.items():
        d = ep.get_data()
        flat = d.transpose(1, 0, 2).reshape(d.shape[1], -1)
        scale = np.abs(flat).max()
        rank = int(np.linalg.matrix_rank(flat, tol=tol_rel * scale)) if scale > 0 else 0
        mask = get_channel_mask(ep)
        n_real = int(mask.sum()) if mask is not None else d.shape[1]
        rows.append(dict(recording=subj, dataset=subj.split("/")[0],
                         n_channels=d.shape[1], n_real_channels=n_real,
                         effective_rank=rank,
                         rank_deficit=d.shape[1] - rank))
    df = pd.DataFrame(rows)
    summary = df.groupby("dataset")[["n_channels", "n_real_channels", "effective_rank"]].median()
    logger.info("V5 - effective rank by dataset (median):")
    logger.info(summary.to_string())
    logger.info("Rank well below n_channels means those extra rows are linear "
                "combinations, not independent measurements.")
    return df


# --------------------------------------------------------------------------
# Augmentation invariants + capstone runner
# --------------------------------------------------------------------------

def audit_augmentation_pipeline(augmenter_instance, sample_tensor, sfreq: float = 128.0,
                                 expected_channels: int = 62, expected_samples: int = 256) -> bool:
    import torch
    assert sample_tensor.ndim == 3, f"Expected (B, C, T), got {sample_tensor.shape}"
    b, c, t = sample_tensor.shape
    assert c == expected_channels, f"Channel mismatch: expected {expected_channels}, got {c}"
    assert t == expected_samples, f"Temporal mismatch: expected {expected_samples}, got {t}"

    for _ in range(50):
        aug = augmenter_instance(sample_tensor)
        if aug.shape != sample_tensor.shape:
            logger.error(f"Shape mutated: {aug.shape}")
            return False
        if torch.isnan(aug).any() or torch.isinf(aug).any():
            logger.error("Augmented tensor contains NaN/Inf!")
            return False
    logger.info(f"PASS: augmentation shape invariant ({b}, {c}, {t}) and stability.")

    if getattr(augmenter_instance, "channel_dropout_rate", 0) > 0:
        orig = torch.mean(sample_tensor ** 2).item()
        energies = [torch.mean(augmenter_instance.channel_dropout(sample_tensor) ** 2).item()
                    for _ in range(500)]
        ratio = np.mean(energies) / (orig + 1e-12)
        if not (0.95 <= ratio <= 1.05):
            logger.error(f"AUGMENTATION: channel-dropout energy not conserved (ratio={ratio:.3f}).")
            return False
        logger.info(f"PASS: channel-dropout energy conservation (ratio={ratio:.3f}).")

    if getattr(augmenter_instance, "max_jitter_samples", 0) > 0:
        xj = augmenter_instance.temporal_jitter(sample_tensor)
        if xj.shape != sample_tensor.shape or torch.isnan(xj).any() or torch.isinf(xj).any():
            logger.error("Temporal jitter broke shape or injected NaN/Inf.")
            return False
        logger.info(f"PASS: non-circular temporal jitter ({augmenter_instance.jitter_mode}).")

    logger.info("PASS: all augmentation integrity audits completed.")
    return True


def run_full_pipeline_audit(train_epochs, unseen_test_epoch, sample_raw, event_id,
                             fit_normalizer_fn, apply_normalizer_fn,
                             augmenter_instance, primary_epoch_window: dict,
                             n_channels: int, n_time_samples: int,
                             cue_offset_sec: float = 0.0,
                             l_freq: float = 8.0, h_freq: float = 30.0,
                             trans_bandwidth: float = 2.0) -> dict:
    """Capstone suite. `n_channels`/`n_time_samples` follow whatever the
    enabled datasets and harmonization mode produce -- no hardcoded 62/256."""
    import torch
    print("\n======================= PIPELINE INTEGRITY AUDIT =======================")
    results = {}
    results["Leave_Subjects_Out_Integrity"] = audit_feature_leakage(
        train_epochs_list=train_epochs, unseen_test_epochs=unseen_test_epoch,
        fit_normalizer_fn=fit_normalizer_fn, apply_normalizer_fn=apply_normalizer_fn)

    bound = audit_filter_leakage_bound(
        raw=sample_raw, event_id=event_id, primary_epoch_window=primary_epoch_window,
        cue_offset_sec=cue_offset_sec, l_freq=l_freq, h_freq=h_freq,
        trans_bandwidth=trans_bandwidth)
    results["Filter_Leakage_Bound"] = bound["passed"]

    iso = audit_epoch_isolation(sample_raw, event_id, primary_epoch_window,
                                 cue_offset_sec, l_freq, h_freq, trans_bandwidth)
    results["Epoch_Isolation"] = iso["passed"]

    results["Augmentation_Invariants"] = audit_augmentation_pipeline(
        augmenter_instance=augmenter_instance,
        sample_tensor=torch.randn(16, n_channels, n_time_samples),
        expected_channels=n_channels, expected_samples=n_time_samples)

    print("\n======================== AUDIT SUITE RESULTS ========================")
    for name, status in results.items():
        print(f"[*] {name:<35} : {'PASSED' if status else 'FAILED'}")
    print("=" * 70 + "\n")
    return results


# Backwards-compatible aliases for the old (mis-named) entry points.
audit_car_instantaneous = audit_car_memoryless
audit_temporal_causality = audit_filter_leakage_bound
