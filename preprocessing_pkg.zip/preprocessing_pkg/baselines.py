"""Classical BCI baselines -- the shared classifier family every ablation
table draws from, so rows stay apples-to-apples.

WHAT WAS WRONG WITH THE PREVIOUS ``SimpleFBCSP``
------------------------------------------------
1. It was not FBCSP. The defining stage of Ang et al. (2008) -- mutual
   information based feature selection over the filter bank -- was missing
   entirely; every band's CSP features were simply concatenated and handed to
   LDA. Without selection, a filter bank is just a wider CSP, and the whole
   point of FBCSP (letting the data choose the subject-specific discriminative
   band) never happens. MIBIF is implemented here, including the paired-feature
   rule: CSP log-variance features come in complementary pairs (first and last
   eigenvector of the same band), and Ang et al. keep the partner of every
   selected feature.
2. It was not a scikit-learn estimator. No ``get_params``/``set_params``, so
   ``sklearn.base.clone`` inside cross-validation could not copy it -- which is
   why the notebook had to monkey-patch four dunder methods onto the class at
   runtime. Inheriting ``BaseEstimator``/``ClassifierMixin`` removes all of that.
3. The CSP objects were built in ``__init__`` and mutated by ``fit``, so a
   "cloned" estimator shared fitted spatial filters with its parent -- a direct
   train/test leak once clone was made to work by deepcopy.
4. The last sub-band (28-32 Hz) sat almost entirely outside the 8-30 Hz
   analysis passband, so it contributed near-zero-variance features that are
   pure noise for the selector to chase.
5. ``mne.filter.filter_data`` with default FIR settings needs a filter longer
   than a 2 s epoch for a 4 Hz-wide band at 8 Hz, so MNE silently shortened it
   and warned. Ang et al. specify zero-phase Chebyshev Type II; that is what is
   used here, applied with ``filtfilt``.

Deviation from the original paper, stated rather than hidden: Ang et al. use a
Naive Bayes Parzen Window classifier. Shrinkage LDA is used here instead so
that FBCSP, CSP+LDA and the Riemannian pipeline all end in the same classifier
family and differences between rows are attributable to the feature stage.
"""

from __future__ import annotations
import numpy as np
import mne
from scipy.signal import cheby2, sosfiltfilt
from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.pipeline import Pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import mutual_info_classif
from mne.decoding import CSP
from pyriemann.estimation import Covariances
from pyriemann.tangentspace import TangentSpace


# --------------------------------------------------------------------------
# Standard baselines
# --------------------------------------------------------------------------

def build_classical_bci_baselines(sfreq: float = 128.0, n_csp_components: int = 6) -> dict:
    """1. CSP + shrinkage LDA   2. Riemannian covariance + tangent space + LR.

    Both covariance estimators are shrinkage (Ledoit-Wolf) rather than
    empirical, and that is not cosmetic. CAR removes exactly one degree of
    freedom (post-CAR channels sum to zero); masked channels remove one each;
    interpolated channels add rows without adding rank. The sample covariance
    of such data is singular, so 'empirical' raises LinAlgError and the
    Riemannian tangent space -- which needs a strictly positive-definite matrix
    to take a logarithm of -- is undefined. Shrinkage restores definiteness.
    """
    return {
        "CSP+LDA": Pipeline([
            ("CSP", CSP(n_components=n_csp_components, reg="ledoit_wolf",
                         log=True, norm_trace=False)),
            ("LDA", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")),
        ]),
        "Riemannian_TS+LR": Pipeline([
            ("Cov", Covariances(estimator="lwf")),
            ("TangentSpace", TangentSpace(metric="riemann")),
            ("Classifier", LogisticRegression(max_iter=1000, C=1.0, solver="lbfgs")),
        ]),
    }


# --------------------------------------------------------------------------
# FBCSP
# --------------------------------------------------------------------------

def default_filter_bank(bandpass=(8.0, 30.0), width: float = 4.0) -> tuple:
    """4 Hz-wide sub-bands tiling the analysis passband.

    Ang et al. use 4-40 Hz in 4 Hz steps, but these data are band-limited to
    8-30 Hz upstream, so bands outside that window would carry only filter
    roll-off. Tiling the actual passband keeps the filter-bank idea and drops
    the empty bands.
    """
    lo, hi = bandpass
    edges = np.arange(lo, hi + 1e-9, width)
    return tuple((float(a), float(b)) for a, b in zip(edges[:-1], edges[1:]))


class FBCSP(BaseEstimator, ClassifierMixin):
    """Filter Bank CSP with MIBIF feature selection (Ang et al. 2008).

    Stages
    ------
    1. Zero-phase Chebyshev Type II band-pass into ``bands``.
    2. CSP per band, ``n_components`` log-variance features each.
    3. MIBIF: rank all features by mutual information with the label, keep the
       top ``n_select``, then add the complementary partner of each (CSP
       features are paired: component j pairs with component n-1-j of the same
       band). Fitted on TRAINING DATA ONLY -- it lives inside ``fit``, so
       cross-validation never sees test labels.
    4. Shrinkage LDA on the selected features.
    """

    def __init__(self, sfreq: float = 128.0, bands=None, n_components: int = 4,
                 n_select: int = 4, csp_reg: str = "ledoit_wolf",
                 filter_order: int = 6, stop_atten_db: float = 30.0,
                 random_state: int = 42):
        self.sfreq = sfreq
        self.bands = bands
        self.n_components = n_components
        self.n_select = n_select
        self.csp_reg = csp_reg
        self.filter_order = filter_order
        self.stop_atten_db = stop_atten_db
        self.random_state = random_state

    # -- filtering ---------------------------------------------------------

    def _sos(self, band):
        nyq = self.sfreq / 2.0
        lo = max(band[0] / nyq, 1e-6)
        hi = min(band[1] / nyq, 1 - 1e-6)
        return cheby2(self.filter_order, self.stop_atten_db, [lo, hi],
                      btype="bandpass", output="sos")

    def _filter_band(self, X, band):
        # padlen must stay below the epoch length; filtfilt raises otherwise.
        n_times = X.shape[-1]
        sos = self._sos(band)
        padlen = min(3 * sos.shape[0] * 2, n_times - 1)
        return sosfiltfilt(sos, X, axis=-1, padlen=padlen)

    # -- MIBIF -------------------------------------------------------------

    @staticmethod
    def _pair_index(idx: int, n_components: int) -> int:
        """Complementary CSP feature within the same band: component j of band
        b pairs with component (n_components-1-j) of band b."""
        band, comp = divmod(idx, n_components)
        return band * n_components + (n_components - 1 - comp)

    def _mibif_select(self, F, y):
        mi = mutual_info_classif(F, y, random_state=self.random_state)
        order = np.argsort(mi)[::-1]
        k = min(self.n_select, F.shape[1])
        selected = set()
        for idx in order[:k]:
            selected.add(int(idx))
            selected.add(self._pair_index(int(idx), self.n_components))
        return np.array(sorted(selected)), mi

    # -- sklearn API -------------------------------------------------------

    def _resolved_bands(self):
        return tuple(self.bands) if self.bands is not None else default_filter_bank()

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        self.classes_ = np.unique(y)
        self.bands_ = self._resolved_bands()
        # CSPs are constructed HERE, not in __init__, so a cloned estimator
        # never inherits fitted spatial filters from its parent.
        self.csps_ = [CSP(n_components=self.n_components, log=True,
                          reg=self.csp_reg, norm_trace=False)
                      for _ in self.bands_]
        feats = [csp.fit_transform(self._filter_band(X, b), y)
                 for b, csp in zip(self.bands_, self.csps_)]
        F = np.concatenate(feats, axis=1)
        self.selected_idx_, self.mutual_info_ = self._mibif_select(F, y)
        self.clf_ = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
        self.clf_.fit(F[:, self.selected_idx_], y)
        return self

    def _transform(self, X):
        X = np.asarray(X, dtype=float)
        feats = [csp.transform(self._filter_band(X, b))
                 for b, csp in zip(self.bands_, self.csps_)]
        return np.concatenate(feats, axis=1)[:, self.selected_idx_]

    def predict(self, X):
        return self.clf_.predict(self._transform(X))

    def predict_proba(self, X):
        return self.clf_.predict_proba(self._transform(X))

    def decision_function(self, X):
        return self.clf_.decision_function(self._transform(X))

    def score(self, X, y):
        return float(np.mean(self.predict(X) == np.asarray(y)))


#: Backwards-compatible alias. The notebook's runtime get_params/set_params/
#: score/__sklearn_clone__ shims are no longer needed -- BaseEstimator supplies
#: all of them.
SimpleFBCSP = FBCSP


def build_all_baselines(sfreq: float = 128.0) -> dict:
    out = build_classical_bci_baselines(sfreq=sfreq)
    out["FBCSP (MIBIF)"] = FBCSP(sfreq=sfreq)
    return out
