"""Every ablation, run through the SAME evaluation protocol so rows are
comparable within and across blocks.

EVALUATION CHANGES IN THIS REVISION
-----------------------------------
* ``StratifiedGroupKFold`` replaces ``GroupKFold``. GroupKFold balances group
  SIZES, not class proportions, so when datasets with different class balances
  are pooled a fold could end up 60/40 while another is 45/55, and plain
  accuracy then moves for reasons unrelated to the ablation.

* Every row reports BALANCED ACCURACY and ROC-AUC alongside accuracy, plus the
  EMPIRICAL majority-class rate instead of a hardcoded "50%" chance level. With
  pooled datasets the actual majority rate is rarely 0.500, and a row reading
  "52.1% vs chance 50%" is uninterpretable when the majority class is 51.8%.

* Accuracy is reported with a fold-level standard deviation AND the number of
  independent subjects behind it, because with 5 folds the std of the mean is
  not a meaningful uncertainty on its own.

* A PER-DATASET breakdown accompanies the pooled row. Pooling datasets whose
  channel masks differ means the pooled classifier can partly exploit
  *dataset identity* (which rows are zero, which montage the covariance came
  from) rather than the task -- so a pooled number that looks good may be
  measuring the wrong thing. The per-dataset rows are the honest comparison.

* The channel set is passed in explicitly. The previous ``_build_cohort``
  called ``registry.compute_common_channels`` internally, so every ablation
  table was computed on the strict intersection regardless of what the
  notebook had configured.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from sklearn.model_selection import StratifiedGroupKFold, GroupKFold
from sklearn.base import clone
from sklearn.metrics import balanced_accuracy_score, roc_auc_score

from .config import DatasetRegistry, GlobalConfig
from .channels import (
    standardize_channel_name, build_channel_table, filter_eeg_only,
    resolve_target_channels, build_mapping_table,
)
from .pipeline_builder import build_pipeline_from_config, build_cohort, resolve_car_scope
from .normalization import apply_per_trial_zscore_ablation
from .alignment import align_cohort
from .baselines import build_classical_bci_baselines

# True for every DatasetConfig: code 1 -> left_hand, code 2 -> right_hand.
CODE_TO_BINARY_LABEL = {1: 0, 2: 1}


def flatten_epochs_dict(epochs_by_key: dict):
    """{"dataset/Sxxx": Epochs} -> (X, y, groups, datasets)."""
    if not epochs_by_key:
        raise ValueError(
            "flatten_epochs_dict got an empty dict -- every subject failed for this "
            "pipeline variant (see the '[cohort build] Skipping ...' messages above).")
    X_list, y_list, groups, datasets = [], [], [], []
    for key, epochs in epochs_by_key.items():
        data = epochs.get_data()
        codes = epochs.events[:, 2]
        inv = {v: k for k, v in epochs.event_id.items()}
        y = np.array([CODE_TO_BINARY_LABEL[c] if c in CODE_TO_BINARY_LABEL
                      else (0 if "left" in inv[c].lower() else 1) for c in codes])
        X_list.append(data)
        y_list.append(y)
        groups.extend([key] * len(y))
        datasets.extend([key.split("/")[0]] * len(y))
    return (np.concatenate(X_list, axis=0), np.concatenate(y_list, axis=0),
            np.array(groups), np.array(datasets))


def _make_cv(y, groups, k):
    """Stratified where possible, falling back cleanly when it is not."""
    n_groups = len(set(groups))
    k = int(max(2, min(k, n_groups)))
    try:
        cv = StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=42)
        list(cv.split(np.zeros(len(y)), y, groups))
        return cv, k
    except Exception:
        return GroupKFold(n_splits=k), k


def _fit_and_score_fold(train_idx, test_idx, X, y, classifier_template, per_channel_normalize):
    """One fold's worth of work for `cv_accuracy`'s (optionally parallel)
    loop. Pulled into its own function so it can run as a joblib task --
    each fold is an independent, isolated computation (no shared state
    across folds), so parallelizing folds changes nothing about the result,
    only how it's computed. Thread-capped for the same reason as every
    other joblib worker in this codebase: avoid n_jobs processes each also
    trying to use every CPU core for their own BLAS calls."""
    def _run():
        Xtr, Xte = X[train_idx], X[test_idx]
        ytr, yte = y[train_idx], y[test_idx]
        if per_channel_normalize:
            mu = Xtr.mean(axis=(0, 2), keepdims=True)
            sigma = Xtr.std(axis=(0, 2), keepdims=True) + 1e-8
            Xtr, Xte = (Xtr - mu) / sigma, (Xte - mu) / sigma
        clf = clone(classifier_template)
        clf.fit(Xtr, ytr)
        pred = clf.predict(Xte)
        acc = float(np.mean(pred == yte))
        bacc = float(balanced_accuracy_score(yte, pred))
        auc = None
        try:
            if hasattr(clf, "predict_proba"):
                s = clf.predict_proba(Xte)[:, 1]
            else:
                s = clf.decision_function(Xte)
            auc = float(roc_auc_score(yte, s))
        except Exception:
            pass
        return acc, bacc, auc

    try:
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=1):
            return _run()
    except ImportError:
        return _run()


def cv_accuracy(X, y, groups, classifier_template, k: int = 5,
                per_channel_normalize: bool = False, return_detail: bool = False,
                n_jobs: int = 1):
    """Leakage-safe subject-grouped CV.

    `per_channel_normalize=True` fits the per-channel mean/std on the TRAIN
    fold only and applies it to both folds -- the correct way to run the
    primary pipeline's normalizer inside cross-validation.

    `n_jobs=1` (default) runs folds sequentially, identical to before this
    was added. `n_jobs>1` runs folds concurrently via joblib -- folds are
    fully independent computations, so this changes only wall-clock time,
    never the numeric result (fold order is preserved regardless).
    """
    cv, k = _make_cv(y, groups, k)
    fold_indices = list(cv.split(X, y, groups))

    if n_jobs == 1:
        fold_results = [_fit_and_score_fold(tr, te, X, y, classifier_template, per_channel_normalize)
                        for tr, te in fold_indices]
    else:
        from joblib import Parallel, delayed
        fold_results = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(_fit_and_score_fold)(tr, te, X, y, classifier_template, per_channel_normalize)
            for tr, te in fold_indices
        )

    accs = [r[0] for r in fold_results]
    baccs = [r[1] for r in fold_results]
    aucs = [r[2] for r in fold_results if r[2] is not None]

    out = (float(np.mean(accs)), float(np.std(accs)))
    if return_detail:
        return out + (float(np.mean(baccs)) if baccs else float("nan"),
                      float(np.mean(aucs)) if aucs else float("nan"), k)
    return out


def empirical_chance(y) -> float:
    """Majority-class rate -- the number accuracy actually has to beat."""
    y = np.asarray(y)
    return float(max(np.mean(y == 0), np.mean(y == 1))) if len(y) else float("nan")


def _row(setup, acc, std, bacc, auc, n_trials, n_subjects, chance, k, extra=None):
    row = dict(Setup=setup,
               Accuracy=f"{acc:.2%}", Std=f"\u00b1{std:.2%}",
               BalancedAcc=f"{bacc:.2%}", AUC=("--" if np.isnan(auc) else f"{auc:.3f}"),
               MajorityRate=f"{chance:.2%}",
               N_trials=n_trials, N_subjects=n_subjects, K=k)
    if extra:
        row.update(extra)
    return row


def _row_failed(setup, reason: str, extra=None):
    print(f"[ablation] '{setup}' could not be evaluated: {reason}")
    row = dict(Setup=setup, Accuracy="FAILED", Std="--", BalancedAcc="--", AUC="--",
               MajorityRate="--", N_trials=0, N_subjects=0, K=0)
    if extra:
        row.update(extra)
    return row


def _safe_acc_row(epochs_by_key: dict, label: str, classifier_template, k: int = 5,
                   per_channel_normalize: bool = False, extra=None, cv_n_jobs: int = 1):
    if not epochs_by_key:
        return _row_failed(label, "no subject succeeded for this pipeline variant", extra)
    try:
        X, y, groups, _ = flatten_epochs_dict(epochs_by_key)
        acc, std, bacc, auc, kk = cv_accuracy(
            X, y, groups, classifier_template, k=k,
            per_channel_normalize=per_channel_normalize, return_detail=True, n_jobs=cv_n_jobs)
        return _row(label, acc, std, bacc, auc, len(y), len(set(groups)),
                    empirical_chance(y), kk, extra)
    except Exception as exc:
        return _row_failed(label, str(exc), extra)


def per_dataset_breakdown(epochs_by_key: dict, classifier_template, k: int = 5) -> pd.DataFrame:
    """Within-dataset, subject-grouped CV for every dataset separately.

    This is the number to trust when comparing datasets, because it never lets
    the classifier use dataset identity as a shortcut. A pooled score far above
    every per-dataset score is a warning sign, not a success.
    """
    rows = []
    by_ds = {}
    for key, ep in epochs_by_key.items():
        by_ds.setdefault(key.split("/")[0], {})[key] = ep
    for ds, subset in sorted(by_ds.items()):
        if len(subset) < 2:
            rows.append(_row_failed(ds, "fewer than 2 subjects, cannot group-split"))
            continue
        rows.append(_safe_acc_row(subset, ds, classifier_template, k=k))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Cohort helper shared by every block
# --------------------------------------------------------------------------

def _build_cohort(registry, channel_mapping_df, montage, glob, n_subjects_per_dataset,
                   common_channels, variant: str, car_scope_channels=None,
                   **pipe_kwargs) -> dict:
    return build_cohort(registry, channel_mapping_df, montage, glob,
                        n_subjects_per_dataset, common_channels=common_channels,
                        variant=variant, car_scope_channels=car_scope_channels,
                        **pipe_kwargs)


# --------------------------------------------------------------------------
# Block 1: spatial reference -- CAR vs Surface Laplacian
# --------------------------------------------------------------------------

def ablation_spatial_reference(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels,
                                car_scope_channels=None,
                                classifier_name="CSP+LDA") -> pd.DataFrame:
    """NOTE: under HARMONIZATION_MODE='reference_masked' the Laplacian row will
    fail for any dataset with masked channels, by design -- CSD solves a spline
    system over all supplied positions and would treat zero-filled rows as real
    0 V measurements. Run this block under 'intersection' for a clean
    comparison, or read it as CAR-only."""
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    rows = []
    for variant, label in tqdm(
        [("primary", "CAR (primary)"), ("laplacian", "Surface Laplacian")],
        desc="Spatial-reference ablation", unit="setup",
    ):
        cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels, variant,
                                car_scope_channels)
        rows.append(_safe_acc_row(cohort, label, clf, k=glob.CV_FOLDS))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 2: artifact handling
# --------------------------------------------------------------------------

def ablation_artifact_handling(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels,
                                car_scope_channels=None,
                                classifier_name="CSP+LDA") -> pd.DataFrame:
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    rows = []
    for variant, label in tqdm(
        [("primary", "None (primary)"), ("ica", "+ ICA"),
         ("autoreject", "+ AutoReject"),
         ("channel_reject", "+ Bad-ch interpolation")],
        desc="Artifact-handling ablation", unit="setup",
    ):
        cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels, variant,
                                car_scope_channels)
        rows.append(_safe_acc_row(cohort, label, clf, k=glob.CV_FOLDS))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 3: epoch window grid
# --------------------------------------------------------------------------

def ablation_epoch_window(registry, channel_mapping_df, montage, glob,
                           n_subjects_per_dataset, common_channels,
                           car_scope_channels=None,
                           classifier_name="CSP+LDA") -> pd.DataFrame:
    """The grid now holds window DURATION constant and varies onset only.

    The previous grid mixed 3.0 s and 2.0 s windows, which confounds the thing
    being ablated (when the imagery window starts) with the amount of data per
    trial -- a longer window gives CSP more samples per covariance estimate and
    wins partly for that reason.
    """
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    rows = []
    for window in tqdm(glob.EPOCH_WINDOW_ABLATION_GRID,
                        desc="Epoch-window ablation", unit="window"):
        dur = window["tmax"] - window["tmin"]
        label = (f"tmin={window['tmin']:.2f}s, dur={dur:.2f}s "
                 f"({window.get('note', '')})")
        cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels, "primary",
                                car_scope_channels, epoch_window=window, baseline=None)
        rows.append(_safe_acc_row(cohort, label, clf, k=glob.CV_FOLDS,
                                   extra={"Window_s": f"{dur:.2f}"}))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 4: baseline correction
# --------------------------------------------------------------------------

def ablation_baseline_correction(registry, channel_mapping_df, montage, glob,
                                  n_subjects_per_dataset, common_channels,
                                  car_scope_channels=None,
                                  classifier_name="CSP+LDA") -> pd.DataFrame:
    """Both arms use BASELINE_ABLATION_EPOCH_WINDOW so the comparison is fair
    (the primary window has no pre-cue time to baseline against)."""
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    window = glob.BASELINE_ABLATION_EPOCH_WINDOW
    rows = []
    for baseline, label in tqdm(
        [(None, "Baseline off"),
         (glob.BASELINE_ABLATION_BASELINE, "Baseline on (pre-cue)")],
        desc="Baseline-correction ablation", unit="setup",
    ):
        cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                                n_subjects_per_dataset, common_channels, "primary",
                                car_scope_channels, epoch_window=window, baseline=baseline)
        rows.append(_safe_acc_row(cohort, label, clf, k=glob.CV_FOLDS))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 5: normalization
# --------------------------------------------------------------------------

def ablation_normalization(registry, channel_mapping_df, montage, glob,
                            n_subjects_per_dataset, common_channels,
                            car_scope_channels=None,
                            classifier_name="CSP+LDA") -> pd.DataFrame:
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                            n_subjects_per_dataset, common_channels, "primary",
                            car_scope_channels)
    labels = ("None (raw physical units)", "Per-channel (train-fold only)",
              "Per-trial z-score")
    if not cohort:
        return pd.DataFrame([_row_failed(l, "no subject succeeded") for l in labels])

    rows = [
        _safe_acc_row(cohort, labels[0], clf, k=glob.CV_FOLDS, per_channel_normalize=False),
        _safe_acc_row(cohort, labels[1], clf, k=glob.CV_FOLDS, per_channel_normalize=True),
    ]
    try:
        _, y, groups, _ = flatten_epochs_dict(cohort)
        # Same iteration order as flatten_epochs_dict, so y/groups stay aligned.
        X_pt = np.concatenate([apply_per_trial_zscore_ablation(ep)
                               for ep in cohort.values()], axis=0)
        acc, std, bacc, auc, kk = cv_accuracy(X_pt, y, groups, clf, k=glob.CV_FOLDS,
                                               return_detail=True)
        rows.append(_row(labels[2], acc, std, bacc, auc, len(y), len(set(groups)),
                         empirical_chance(y), kk))
    except Exception as exc:
        rows.append(_row_failed(labels[2], str(exc)))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 6: Euclidean Alignment
# --------------------------------------------------------------------------

def ablation_euclidean_alignment(registry, channel_mapping_df, montage, glob,
                                  n_subjects_per_dataset, common_channels,
                                  car_scope_channels=None,
                                  classifier_name="CSP+LDA") -> pd.DataFrame:
    """Three rows, because the standard EA formulation is transductive and that
    has to be visible rather than buried:

      EA off                    inductive reference point
      EA on (per-subject)       He & Wu 2020 as published -- the reference for a
                                held-out subject is estimated from that
                                subject's own (unlabelled) trials, so it does
                                touch test data
      EA on (train-fold only)   strictly inductive: reference pooled over
                                training subjects and applied to everyone

    If row 2 beats row 3 by a lot, the gain is coming from target adaptation,
    not from alignment per se -- which is a legitimate result, but a different
    claim.
    """
    clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]
    cohort = _build_cohort(registry, channel_mapping_df, montage, glob,
                            n_subjects_per_dataset, common_channels, "primary",
                            car_scope_channels)
    labels = ("EA off (primary)", "EA on (per-subject, transductive)",
              "EA on (train-fold reference, inductive)")
    if not cohort:
        return pd.DataFrame([_row_failed(l, "no subject succeeded") for l in labels])

    rows = [_safe_acc_row(cohort, labels[0], clf, k=glob.CV_FOLDS)]

    try:
        _, y, groups, _ = flatten_epochs_dict(cohort)
        aligned = align_cohort(cohort, scope="subject")
        X_ea = np.concatenate([aligned[k] for k in cohort], axis=0)
        acc, std, bacc, auc, kk = cv_accuracy(X_ea, y, groups, clf, k=glob.CV_FOLDS,
                                               return_detail=True)
        rows.append(_row(labels[1], acc, std, bacc, auc, len(y), len(set(groups)),
                         empirical_chance(y), kk))
    except Exception as exc:
        rows.append(_row_failed(labels[1], str(exc)))

    try:
        rows.append(_ea_train_only_row(cohort, clf, glob, labels[2]))
    except Exception as exc:
        rows.append(_row_failed(labels[2], str(exc)))

    return pd.DataFrame(rows)


def _ea_train_only_row(cohort, clf, glob, label):
    """Fit the EA reference inside each CV fold, on training subjects only."""
    from .alignment import compute_ea_reference, whiten_with_reference
    X, y, groups, _ = flatten_epochs_dict(cohort)
    cv, k = _make_cv(y, groups, glob.CV_FOLDS)
    accs, baccs, aucs = [], [], []
    for train_idx, test_idx in cv.split(X, y, groups):
        r_bar = compute_ea_reference(X[train_idx])
        Xtr = whiten_with_reference(X[train_idx], r_bar)
        Xte = whiten_with_reference(X[test_idx], r_bar)
        m = clone(clf)
        m.fit(Xtr, y[train_idx])
        pred = m.predict(Xte)
        accs.append(float(np.mean(pred == y[test_idx])))
        baccs.append(float(balanced_accuracy_score(y[test_idx], pred)))
        try:
            s = (m.predict_proba(Xte)[:, 1] if hasattr(m, "predict_proba")
                 else m.decision_function(Xte))
            aucs.append(float(roc_auc_score(y[test_idx], s)))
        except Exception:
            pass
    return _row(label, float(np.mean(accs)), float(np.std(accs)),
                float(np.mean(baccs)), float(np.mean(aucs)) if aucs else float("nan"),
                len(y), len(set(groups)), empirical_chance(y), k)


# --------------------------------------------------------------------------
# Block 7: channel-harmonization strategy -- the three-way comparison
# --------------------------------------------------------------------------

def ablation_channel_harmonization_strategy(registry, montage, glob, n_subjects_per_dataset,
                                             modes=("reference_masked", "union", "intersection"),
                                             classifier_name="CSP+LDA") -> pd.DataFrame:
    """Directly compares the three strategies under the identical pipeline and
    CV protocol. Rebuilds the channel set, mapping table and CAR scope
    independently for each, then reports pooled AND per-dataset scores.

    Read the pooled column with suspicion. The three modes produce tensors of
    different dimensionality and different rank, and under 'union' every
    low-density dataset's tensor is largely interpolation, which makes its
    channels unusually smooth and its covariance unusually well-conditioned.
    That can raise pooled accuracy while carrying no extra neural information,
    because it also makes dataset identity trivially decodable. The
    per-dataset rows and the rank column are where the real comparison is.
    """
    from dataclasses import replace
    from .signal_processing import get_channel_mask

    rows = []
    label_of = {
        "reference_masked": "Reference set + masking (anchor intersection)",
        "union": "Union + spherical-spline interpolation",
        "intersection": "Strict N-way intersection",
    }

    channel_dfs = []
    for cfg in registry.enabled():
        names = cfg.get_channel_names()
        channel_dfs.append(filter_eeg_only(
            build_channel_table(names, ["eeg"] * len(names), cfg.name)))

    for mode in tqdm(modes, desc="Channel-harmonization-strategy ablation", unit="mode"):
        try:
            common_channels, missing = resolve_target_channels(
                *channel_dfs, mode=mode, anchor_datasets=list(glob.ANCHOR_DATASETS))
            mapping_df = build_mapping_table(*channel_dfs, common_channels=common_channels)
            mode_glob = replace(glob, HARMONIZATION_MODE=mode)
            car_scope = resolve_car_scope(registry, common_channels, mode_glob)

            worst = max((len(v) for v in missing.values()), default=0)
            print(f"[{label_of[mode]}] C={len(common_channels)}; worst-case "
                  f"{'interpolated' if mode == 'union' else 'masked'} channels for one "
                  f"dataset = {worst}")

            cohort = build_cohort(registry, mapping_df, montage, mode_glob,
                                   n_subjects_per_dataset,
                                   common_channels=common_channels,
                                   variant="primary", car_scope_channels=car_scope)
            clf = build_classical_bci_baselines(sfreq=glob.TARGET_SFREQ)[classifier_name]

            ranks = []
            for ep in cohort.values():
                d = ep.get_data()
                flat = d.transpose(1, 0, 2).reshape(d.shape[1], -1)
                ranks.append(int(np.linalg.matrix_rank(flat, tol=1e-10 * np.abs(flat).max())))
            extra = {
                "N_channels": len(common_channels),
                "Median_rank": int(np.median(ranks)) if ranks else 0,
                "Real_ch_min": int(min((get_channel_mask(ep).sum()
                                        for ep in cohort.values()
                                        if get_channel_mask(ep) is not None), default=len(common_channels))),
            }
            rows.append(_safe_acc_row(cohort, label_of[mode], clf, k=glob.CV_FOLDS, extra=extra))

            per_ds = per_dataset_breakdown(cohort, clf, k=glob.CV_FOLDS)
            print(f"  per-dataset ({mode}):")
            print("  " + per_ds.to_string(index=False).replace("\n", "\n  "))
        except Exception as exc:
            rows.append(_row_failed(label_of[mode], str(exc)))

    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Block 8: dataset-identity probe -- how much of a pooled score is shortcut?
# --------------------------------------------------------------------------

def audit_dataset_identity_shortcut(epochs_by_key: dict, glob) -> pd.DataFrame:
    """Can a classifier tell which DATASET a trial came from?

    If dataset identity is near-perfectly decodable from the harmonized tensor
    -- which it will be under 'union' or 'reference_masked', because the mask
    pattern alone identifies the dataset -- then any pooled cross-dataset score
    can in principle be reached by learning per-dataset decision rules rather
    than a shared neural representation. This does not invalidate pooling, but
    it means the pooled number is an upper bound on generalisation, and the
    per-dataset rows are the ones to quote.
    """
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline as SkPipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import cross_val_score

    X, _, groups, datasets = flatten_epochs_dict(epochs_by_key)
    feats = np.log(np.mean(X ** 2, axis=2) + 1e-20)
    if len(set(datasets)) < 2:
        return pd.DataFrame([{"Probe": "dataset identity", "Result": "only one dataset"}])
    cv, k = _make_cv(datasets, groups, glob.CV_FOLDS)
    pipe = SkPipeline([("sc", StandardScaler()),
                       ("lr", LogisticRegression(max_iter=1000))])
    scores = cross_val_score(pipe, feats, datasets, cv=cv, groups=groups, scoring="accuracy")
    chance = empirical_chance(pd.factorize(datasets)[0] == 0)
    df = pd.DataFrame([{
        "Probe": "Dataset identity from log band-power",
        "Accuracy": f"{scores.mean():.2%}", "Std": f"\u00b1{scores.std():.2%}",
        "N_datasets": len(set(datasets)),
        "MajorityRate": f"{max(pd.Series(datasets).value_counts(normalize=True)):.2%}",
    }])
    print(df.to_string(index=False))
    print("Near-ceiling accuracy here means the pooled task score above is an upper "
          "bound: the model can condition on dataset identity. Quote the per-dataset "
          "rows for generalisation claims.")
    return df


# --------------------------------------------------------------------------
# Run everything
# --------------------------------------------------------------------------

def run_all_ablations(registry, channel_mapping_df, montage, glob, n_subjects_per_dataset,
                       common_channels, car_scope_channels=None,
                       classifier_name="CSP+LDA") -> dict:
    blocks = {
        "Spatial reference (CAR vs Laplacian)": ablation_spatial_reference,
        "Artifact handling": ablation_artifact_handling,
        "Epoch window grid": ablation_epoch_window,
        "Baseline correction": ablation_baseline_correction,
        "Normalization": ablation_normalization,
        "Euclidean Alignment": ablation_euclidean_alignment,
    }
    results = {}
    for title, fn in blocks.items():
        print(f"\n================ ABLATION: {title} ================")
        df = fn(registry, channel_mapping_df, montage, glob, n_subjects_per_dataset,
                common_channels, car_scope_channels, classifier_name)
        print(df.to_string(index=False))
        results[title] = df
    return results
