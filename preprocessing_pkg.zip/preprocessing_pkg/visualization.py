"""V1-V13 plotting.

CHANGES IN THIS REVISION
------------------------
* Every envelope now goes through ``signal_processing.analytic_envelope``
  with a REAL-DATA MARGIN that is cropped after the transform. The bare
  ``scipy.signal.hilbert`` used previously treats the epoch as one period of a
  periodic signal, so the step between the last and first sample injects a
  broadband transient that corrupts roughly one cycle of the lowest analysed
  frequency at each end -- ~125 ms at 8 Hz, i.e. 12% of a 2 s epoch, sitting
  exactly where ERD onset and offset are read off. Note that the obvious fix,
  reflection-padding the epoch, measures WORSE than doing nothing on
  narrowband data; see analytic_envelope's docstring for why and for the
  numbers. These functions therefore take epochs that already carry margin
  (built by cohort_analysis.build_baseline_ablation_epochs) and crop to a
  display window.

* ``plot_erd_ers_tfr`` uses ``epochs.compute_tfr`` (``tfr_morlet`` was
  deprecated in MNE 1.7 and removed in 1.8), applies ``zero_mean=True``, and
  baselines over a window that stops short of both the epoch edge and the cue
  rather than running from ``epochs.tmin`` to exactly 0.0. The old baseline
  included the first sample, which is inside the wavelet's cone of influence,
  and ran up to t=0, which with a symmetric wavelet already contains post-cue
  energy.

* ``plot_channel_correlation_heatmap`` annotates the -1/(N-1) correlation floor
  that CAR imposes by construction, reports the effective rank, and marks
  masked/interpolated channels -- without which the matrix looks structured for
  reasons that have nothing to do with the brain.

* Every topography/lateralisation function is mask-aware: masked channels are
  excluded rather than plotted as a genuine 0.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
import mne
import matplotlib.pyplot as plt

from .signal_processing import (
    analytic_envelope, get_channel_mask, envelope_margin_samples,
)

CODE_TO_DISPLAY_LABEL = {1: "Left Hand", 2: "Right Hand"}


def _display_label(event_name: str, event_code: int) -> str:
    return f"{CODE_TO_DISPLAY_LABEL.get(event_code, event_name)} ({event_name})"


def _real_channel_idx(inst):
    mask = get_channel_mask(inst)
    return np.arange(len(inst.ch_names)) if mask is None else np.where(mask)[0]


def _have(epochs, picks):
    """Only the requested channels that exist AND carry real signal."""
    real = set(np.asarray(epochs.ch_names)[_real_channel_idx(epochs)])
    return [p for p in picks if p in real]


# --------------------------------------------------------------------------
# V1/V2 -- raw trace and PSD, before/after
# --------------------------------------------------------------------------

def plot_raw_trace_comparison(raw_before, raw_after, picks=("C3", "CZ", "C4"),
                               duration: float = 4.0, start: float = 10.0):
    from .channels import standardize_channel_name
    lookup = {standardize_channel_name(ch): ch for ch in raw_before.ch_names}
    valid = [p for p in picks if p in lookup and p in raw_after.ch_names]
    if not valid:
        raise ValueError(f"None of {picks} found in both recordings.")
    orig = [lookup[p] for p in valid]

    sb, sa = raw_before.info["sfreq"], raw_after.info["sfreq"]
    db, tb = raw_before.copy().pick(orig).get_data(
        start=int(start * sb), stop=int((start + duration) * sb), return_times=True)
    da, ta = raw_after.copy().pick(valid).get_data(
        start=int(start * sa), stop=int((start + duration) * sa), return_times=True)

    fig, axes = plt.subplots(len(valid), 1, figsize=(10, 2.2 * len(valid)))
    axes = np.atleast_1d(axes)
    for i, ch in enumerate(valid):
        axes[i].plot(tb - tb[0], db[i] * 1e6, label=f"raw ({orig[i]})", alpha=0.6, lw=0.8)
        axes[i].plot(ta - ta[0], da[i] * 1e6, label=f"processed ({ch})", alpha=0.9, lw=0.9)
        axes[i].set_ylabel(f"{ch}\n(uV)")
        if i == 0:
            axes[i].legend(loc="upper right", fontsize=8)
    axes[-1].set_xlabel("Time from segment start (s)")
    fig.suptitle("V1: Raw trace, before vs. after processing")
    fig.tight_layout()
    return fig


def plot_psd_comparison(raw_before, raw_after, fmax: float = 60.0, band=(8, 30)):
    fig, ax = plt.subplots(figsize=(8, 4))
    for raw, label, color in [(raw_before, "before", "tab:blue"),
                               (raw_after, "after", "tab:orange")]:
        picks = _real_channel_idx(raw)
        spectrum = raw.compute_psd(fmax=min(fmax, raw.info["sfreq"] / 2 - 1),
                                    picks=picks, verbose=False)
        psd, freqs = spectrum.get_data(return_freqs=True)
        ax.plot(freqs, 10 * np.log10(psd.mean(axis=0) + 1e-30), label=label, color=color)
    ax.axvspan(*band, color="green", alpha=0.08, label=f"{band[0]}-{band[1]} Hz passband")
    ax.set_xlabel("Frequency (Hz)"); ax.set_ylabel("Power (dB)")
    ax.set_title("V2: PSD, before vs. after processing")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# Channel-coverage EDA
# --------------------------------------------------------------------------

def plot_channel_synthesis_summary(synthesis_df):
    """Stacked bar: real vs. reconstructed/masked channels per dataset."""
    verb = synthesis_df.get("missing_verb", pd.Series(["synthesized"])).iloc[0]
    colour = {"synthesized": "darkorange", "masked": "0.75", "dropped": "crimson"}[verb]
    fig, ax = plt.subplots(figsize=(max(6, 1.4 * len(synthesis_df)), 4.5))
    x = np.arange(len(synthesis_df))
    native = synthesis_df["native_channels"].values
    missing = synthesis_df["synthesized_channels"].values
    ax.bar(x, native, label="Real (recorded)", color="teal")
    ax.bar(x, missing, bottom=native, label=f"{verb.capitalize()}", color=colour,
           hatch="//" if verb == "masked" else None, edgecolor="white")
    ax.set_xticks(x)
    ax.set_xticklabels(synthesis_df["dataset"], rotation=30, ha="right")
    ax.set_ylabel("Channel count")
    ax.axhline(synthesis_df["target_channels"].iloc[0], color="k", linestyle="--",
               linewidth=1, label="Target channel count")
    ax.set_title(f"Channel coverage per dataset (mode: "
                 f"{synthesis_df.get('mode', pd.Series(['?'])).iloc[0]})")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


def plot_common_montage(montage, common_channels, resolved_positions):
    info = mne.create_info(ch_names=[resolved_positions[n] for n in common_channels],
                            sfreq=128.0, ch_types="eeg")
    info.set_montage(montage)
    fig = info.plot_sensors(show_names=True, sphere="auto", show=False)
    fig.suptitle(f"V3: shared montage (n={len(common_channels)})")
    return fig


def plot_channel_variance_boxplot(epochs: mne.Epochs):
    data = epochs.get_data()
    per_trial_var = data.var(axis=2)
    mask = get_channel_mask(epochs)
    fig, ax = plt.subplots(figsize=(max(8, 0.25 * len(epochs.ch_names)), 4))
    ax.boxplot(per_trial_var, tick_labels=epochs.ch_names, showfliers=True)
    ax.set_yscale("symlog", linthresh=1e-14)
    ax.set_ylabel("Per-trial variance (V^2)")
    title = "V4: Per-channel variance across trials"
    if mask is not None and not mask.all():
        title += f"  --  {int((~mask).sum())} masked channel(s) sit at exactly zero by design"
        for i, m in enumerate(mask):
            if not m:
                ax.get_xticklabels()[i].set_color("crimson")
    ax.set_title(title)
    plt.setp(ax.get_xticklabels(), rotation=90, fontsize=6)
    fig.tight_layout()
    return fig


def plot_class_balance(epochs_by_subject: dict):
    rows = []
    for subj, epochs in epochs_by_subject.items():
        for label, code in epochs.event_id.items():
            rows.append({"subject": subj, "label": _display_label(label, code),
                         "n_trials": int((epochs.events[:, 2] == code).sum())})
    df = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(max(8, 0.3 * df["subject"].nunique()), 4))
    df.pivot(index="subject", columns="label", values="n_trials").fillna(0).plot(kind="bar", ax=ax)
    ax.set_ylabel("Trial count")
    ax.set_title("V5: Class balance per recording")
    ax.legend(title="class", fontsize=8)
    fig.tight_layout()
    return fig, df


def plot_epochs_image(epochs: mne.Epochs, picks=("C3", "C4")):
    picks = _have(epochs, picks)
    if not picks:
        raise ValueError("None of the requested channels carry real signal here.")
    figs = epochs.plot_image(picks=picks, show=False)
    for fig, ch in zip(np.atleast_1d(figs), picks):
        fig.suptitle(f"V6: Epochs image -- {ch}")
    return figs


# --------------------------------------------------------------------------
# V7 -- ERD/ERS time-frequency
# --------------------------------------------------------------------------

def plot_erd_ers_tfr(epochs: mne.Epochs, picks=("C3", "C4"), freqs=None,
                      baseline_pad: float = 0.1):
    """Morlet TFR, percent change vs. a pre-cue baseline.

    Two corrections. (1) ``tfr_morlet`` was deprecated in MNE 1.7 and removed
    in 1.8; this uses ``epochs.compute_tfr``. (2) the baseline no longer runs
    from ``epochs.tmin`` to exactly 0.0. The first samples of the epoch are
    inside the wavelet's cone of influence (a 4-cycle wavelet at 8 Hz spans
    0.5 s), and a symmetric wavelet centred just before t=0 already integrates
    post-cue energy -- so both ends of the old baseline were contaminated by
    the things it was supposed to be a reference for.
    """
    if freqs is None:
        freqs = np.arange(8, 31, 1)
    if epochs.tmin >= 0:
        raise ValueError("plot_erd_ers_tfr needs pre-cue time (epochs.tmin < 0). "
                         "Pass epochs built with the baseline-ablation window.")
    picks = _have(epochs, picks)
    if not picks:
        raise ValueError("None of the requested channels carry real signal here.")

    n_cycles = freqs / 2.0
    # Half-duration of the longest wavelet, i.e. the cone-of-influence margin.
    coi = float(np.max(n_cycles / (2.0 * np.pi * freqs)) * 3.0)
    b_start = epochs.tmin + max(coi, baseline_pad)
    b_stop = -max(coi, baseline_pad)
    if b_start >= b_stop:
        b_start, b_stop = epochs.tmin + baseline_pad, -baseline_pad
        print(f"[TFR] Epoch has little clean pre-cue time; baseline narrowed to "
              f"({b_start:.2f}, {b_stop:.2f}) s. Interpret ERD magnitude cautiously.")

    fig, axes = plt.subplots(len(epochs.event_id), len(picks),
                              figsize=(4.4 * len(picks), 3.2 * len(epochs.event_id)),
                              squeeze=False)
    for row, (event_name, event_code) in enumerate(epochs.event_id.items()):
        sub = epochs[event_name]
        power = sub.compute_tfr(method="morlet", freqs=freqs, n_cycles=n_cycles,
                                 picks=picks, return_itc=False, average=True,
                                 zero_mean=True, verbose=False)
        power.apply_baseline(baseline=(b_start, b_stop), mode="percent", verbose=False)
        for col, ch in enumerate(picks):
            power.plot([power.ch_names.index(ch)], axes=axes[row, col], show=False,
                       colorbar=(col == len(picks) - 1))
            axes[row, col].set_title(f"{_display_label(event_name, event_code)} @ {ch}")
    fig.suptitle(f"V7: ERD/ERS time-frequency (% change vs. "
                 f"[{b_start:.2f}, {b_stop:.2f}] s pre-cue baseline)")
    fig.tight_layout()
    return fig


def plot_bandpower_timecourse(epochs: mne.Epochs, picks=("C3", "C4"), band=(8, 30),
                               display_window=None):
    """V8: band-power time course by class, with edge-safe envelopes."""
    picks = _have(epochs, picks)
    if not picks:
        raise ValueError("None of the requested channels carry real signal here.")
    filt = epochs.copy().filter(band[0], band[1], picks=picks, verbose=False)
    margin = (envelope_margin_samples(filt, display_window) if display_window else 0)
    times = filt.times[margin:len(filt.times) - margin] if margin else filt.times
    fig, axes = plt.subplots(1, len(picks), figsize=(5 * len(picks), 4), sharey=True)
    axes = np.atleast_1d(axes)
    for col, ch in enumerate(picks):
        idx = filt.ch_names.index(ch)
        for event_name, event_code in filt.event_id.items():
            data = filt[event_name].get_data(picks=[idx]).squeeze(1)
            env = analytic_envelope(data, filt.info["sfreq"],
                                    margin_samples=margin, power=True)
            axes[col].plot(times, env.mean(axis=0),
                           label=_display_label(event_name, event_code))
        axes[col].axvline(0, color="k", ls="--", lw=0.8)
        axes[col].set_title(ch); axes[col].set_xlabel("Time from cue (s)")
    axes[0].set_ylabel(f"{band[0]}-{band[1]} Hz power (V^2)")
    axes[0].legend(fontsize=8)
    fig.suptitle("V8: Band-power time course by class (real-margin Hilbert envelope)")
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# V9 -- channel correlation, read correctly
# --------------------------------------------------------------------------

def plot_channel_correlation_heatmap(epochs: mne.Epochs, show_car_floor: bool = True):
    """V9: channel correlation matrix, with the structure CAR and harmonization
    impose on it made explicit.

    Two things were being misread here.

    1. After a common average reference over N channels, the referenced signals
       sum to zero at every time point. That alone forces the average
       off-diagonal correlation to about -1/(N-1). At N=62 that is -0.016, so a
       faint blue wash is expected and is not connectivity.

    2. Interpolated channels (union mode) are exact linear combinations of the
       recorded ones, so neighbouring interpolated sites correlate near 1 with
       each other and with their source electrodes for purely algebraic reasons
       (Kang, Lano & Sponheim 2015). A block of near-unity correlation in a
       low-density dataset is the interpolation, not the brain.

    Masked channels are excluded rather than contributing a degenerate row.
    """
    mask = get_channel_mask(epochs)
    idx = _real_channel_idx(epochs)
    names = [epochs.ch_names[i] for i in idx]
    data = epochs.get_data()[:, idx, :]
    flat = data.transpose(1, 0, 2).reshape(len(idx), -1)
    corr = np.corrcoef(flat)
    n = len(idx)
    floor = -1.0 / (n - 1) if n > 1 else 0.0
    off = corr[~np.eye(n, dtype=bool)]
    rank = int(np.linalg.matrix_rank(flat, tol=1e-10 * np.abs(flat).max()))

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="RdBu_r")
    ax.set_xticks(range(n)); ax.set_yticks(range(n))
    ax.set_xticklabels(names, rotation=90, fontsize=6)
    ax.set_yticklabels(names, fontsize=6)
    fig.colorbar(im, ax=ax, label="Pearson r")
    subtitle = (f"mean off-diagonal r = {off.mean():+.3f} "
                f"(CAR floor {floor:+.3f}) | rank {rank}/{n}")
    if mask is not None and not mask.all():
        subtitle += f" | {int((~mask).sum())} masked channel(s) excluded"
    ax.set_title("V9: Channel correlation matrix\n" + subtitle, fontsize=10)
    if show_car_floor:
        print(f"[V9] N={n} referenced channels -> CAR forces mean off-diagonal r "
              f"~= {floor:+.4f}; observed {off.mean():+.4f}. "
              f"Effective rank {rank} (expect {n - 1} for full-rank CAR data; "
              "markedly lower means rows are linear combinations of others).")
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# V10 -- task vs subject structure
# --------------------------------------------------------------------------

def _log_bandpower_features(epochs_by_subject: dict, band=(8, 30), real_only: bool = True):
    feats, tasks, subjects = [], [], []
    ref_idx = None
    for subj, epochs in epochs_by_subject.items():
        filt = epochs.copy().filter(band[0], band[1], verbose=False)
        data = filt.get_data()
        if real_only:
            # Use the channels real in EVERY recording, otherwise masked zeros
            # become a constant feature that identifies the dataset outright.
            idx = set(_real_channel_idx(epochs).tolist())
            ref_idx = idx if ref_idx is None else (ref_idx & idx)
        feats.append(data)
        inv = {v: k for k, v in epochs.event_id.items()}
        tasks.extend([CODE_TO_DISPLAY_LABEL.get(c, inv[c]) for c in epochs.events[:, 2]])
        subjects.extend([subj] * len(epochs))
    if real_only and ref_idx is not None:
        keep = sorted(ref_idx)
        feats = [f[:, keep, :] for f in feats]
    X = np.concatenate([np.log(np.mean(f ** 2, axis=2) + 1e-20) for f in feats], axis=0)
    return X, np.array(tasks), np.array(subjects)


def _scatter_pair(embedding, tasks, subjects, titles, suptitle):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for label in np.unique(tasks):
        m = tasks == label
        axes[0].scatter(embedding[m, 0], embedding[m, 1], s=12, alpha=0.6, label=label)
    axes[0].set_title(titles[0]); axes[0].legend(fontsize=8)
    uniq = np.unique(subjects)
    cmap = plt.colormaps["tab20"].resampled(max(len(uniq), 1))
    for i, s in enumerate(uniq):
        m = subjects == s
        axes[1].scatter(embedding[m, 0], embedding[m, 1], s=12, alpha=0.6, color=cmap(i))
    axes[1].set_title(titles[1])
    fig.suptitle(suptitle)
    fig.tight_layout()
    return fig, axes


def plot_task_vs_subject_pca(epochs_by_subject: dict, band=(8, 30)):
    """V10: PCA of log band-power.

    This is a DESCRIPTIVE embedding: the PCA is fitted on all trials, which is
    appropriate for visualising the structure that exists in the data but is
    NOT a model evaluation. Any accuracy number must come from
    ``cohort_analysis.evaluate_raw_feature_separability``, where the scaler and
    classifier are fitted inside each fold.
    """
    from sklearn.decomposition import PCA
    X, tasks, subjects = _log_bandpower_features(epochs_by_subject, band)
    pcs = PCA(n_components=2).fit_transform(X)
    fig, axes = _scatter_pair(pcs, tasks, subjects,
                              ("V10a: PCA coloured by TASK", "V10b: PCA coloured by SUBJECT"),
                              "V10: Task-vs-subject structure in log band-power "
                              "(descriptive embedding, fitted on all trials)")
    for ax in axes:
        ax.set_xlabel("PC1"); ax.set_ylabel("PC2")
    return fig, X, tasks, subjects


def plot_task_vs_subject_umap(epochs_by_subject: dict, band=(8, 30),
                               n_neighbors=15, min_dist=0.1):
    import umap
    from sklearn.preprocessing import StandardScaler
    X, tasks, subjects = _log_bandpower_features(epochs_by_subject, band)
    emb = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist,
                    random_state=42).fit_transform(StandardScaler().fit_transform(X))
    fig, _ = _scatter_pair(emb, tasks, subjects,
                           ("UMAP: coloured by TASK", "UMAP: coloured by SUBJECT"),
                           "Task vs. subject structure, UMAP (descriptive)")
    return fig, X, tasks, subjects


def plot_task_vs_subject_tsne(epochs_by_subject: dict, band=(8, 30),
                               perplexity=30, random_state=42):
    from sklearn.manifold import TSNE
    from sklearn.preprocessing import StandardScaler
    X, tasks, subjects = _log_bandpower_features(epochs_by_subject, band)
    perp = min(perplexity, max(5, (len(X) - 1) // 3))
    emb = TSNE(n_components=2, perplexity=perp, random_state=random_state,
               init="pca", learning_rate="auto").fit_transform(
        StandardScaler().fit_transform(X))
    fig, axes = _scatter_pair(emb, tasks, subjects,
                              ("t-SNE: coloured by TASK", "t-SNE: coloured by SUBJECT"),
                              "Task vs. subject structure, t-SNE (descriptive)")
    for ax in axes:
        ax.set_xlabel("t-SNE 1"); ax.set_ylabel("t-SNE 2")
    return fig, X, tasks, subjects


# --------------------------------------------------------------------------
# V11/V12
# --------------------------------------------------------------------------

def plot_rejection_rate_comparison(rejection_counts: dict):
    non_empty = {k: v for k, v in rejection_counts.items() if v}
    if not non_empty:
        print("[plot_rejection_rate_comparison] No data to plot.")
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.text(0.5, 0.5, "No rejection-rate data available", ha="center", va="center")
        ax.axis("off")
        return fig
    df = pd.DataFrame(non_empty).fillna(0)
    fig, ax = plt.subplots(figsize=(max(8, 0.3 * len(df)), 4))
    df.plot(kind="bar", ax=ax)
    ax.set_ylabel("Count rejected"); ax.set_xlabel("Recording")
    ax.set_title("V11: Rejection rate by policy and recording")
    fig.tight_layout()
    return fig


def plot_normalization_check(raw_data, normalized_data, ch_names, picks=("C3", "C4", "CZ")):
    picks = [p for p in picks if p in ch_names]
    idx = [list(ch_names).index(p) for p in picks]
    fig, axes = plt.subplots(2, len(picks), figsize=(4 * len(picks), 6), sharey="row")
    axes = np.atleast_2d(axes)
    for col, (ch, i) in enumerate(zip(picks, idx)):
        axes[0, col].hist(raw_data[:, i, :].ravel() * 1e6, bins=80, color="gray",
                          alpha=0.7, density=True)
        axes[0, col].set_title(f"{ch} -- raw (uV)"); axes[0, col].set_xlabel("Amplitude (uV)")
        axes[1, col].hist(normalized_data[:, i, :].ravel(), bins=80, color="teal",
                          alpha=0.7, density=True)
        axes[1, col].set_title(f"{ch} -- normalized (z)")
        axes[1, col].set_xlabel("Standardized value"); axes[1, col].set_xlim(-5, 5)
        if col == 0:
            axes[0, col].set_ylabel("Density"); axes[1, col].set_ylabel("Density")
    fig.suptitle("V12: Amplitude distribution before vs. after per-channel normalization")
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# V13 -- topographies and lateralisation
# --------------------------------------------------------------------------

def _erd_db(data, base_mask, imag_mask):
    p_base = np.mean(data[:, :, base_mask] ** 2, axis=(0, 2)) + 1e-30
    p_imag = np.mean(data[:, :, imag_mask] ** 2, axis=(0, 2)) + 1e-30
    return 10 * np.log10(p_imag / p_base)


def _masked_topo(values, info, mask, ax, vlim, cmap="RdBu_r"):
    """Plot only real channels; masked positions are simply absent."""
    if mask is not None and not mask.all():
        keep = np.where(mask)[0]
        sub = mne.pick_info(info, keep)
        return mne.viz.plot_topomap(values[keep], sub, axes=ax, show=False,
                                     cmap=cmap, vlim=vlim)
    return mne.viz.plot_topomap(values, info, axes=ax, show=False, cmap=cmap, vlim=vlim)


def plot_motor_imagery_topomaps(epochs_tfr, band=(8, 30), baseline_window=(-0.5, -0.05),
                                 imagery_window=(1.0, 2.5)):
    band_ep = epochs_tfr.copy().filter(band[0], band[1], verbose=False)
    times = band_ep.times
    mask = get_channel_mask(epochs_tfr)
    bm = (times >= baseline_window[0]) & (times <= baseline_window[1])
    im_ = (times >= imagery_window[0]) & (times <= imagery_window[1])
    fig, axes = plt.subplots(1, len(band_ep.event_id),
                              figsize=(5 * len(band_ep.event_id), 4.5))
    axes = np.atleast_1d(axes)
    img = None
    for i, (name, code) in enumerate(band_ep.event_id.items()):
        erd = _erd_db(band_ep[name].get_data(), bm, im_)
        picked = erd[mask] if mask is not None else erd
        vmax = np.percentile(np.abs(picked), 95)
        img, _ = _masked_topo(erd, band_ep.info, mask, axes[i], (-vmax, vmax))
        axes[i].set_title(_display_label(name, code), fontsize=11, fontweight="bold")
    cbar_ax = fig.add_axes([0.92, 0.25, 0.02, 0.5])
    fig.colorbar(img, cax=cbar_ax).set_label("Power change (dB vs. baseline)", fontsize=9)
    fig.suptitle(f"Topographic sensorimotor rhythm modulation ({band[0]}-{band[1]} Hz)",
                 fontsize=13, y=0.98)
    return fig


def plot_mu_topomaps_decibels(epochs_tfr, mu_band=(10, 14), baseline_window=(-0.5, -0.05),
                               imagery_window=(1.0, 2.5)):
    return plot_motor_imagery_topomaps(epochs_tfr, band=mu_band,
                                        baseline_window=baseline_window,
                                        imagery_window=imagery_window)


def plot_lateralization_index(epochs_tfr, band=(8, 30), display_window=None,
                               normalize: bool = True, baseline=(-0.5, -0.05)):
    """Contralateral C3/C4 power divergence, edge-safe.

    ``normalize=True`` gives the log-ratio log P(C4) - log P(C3), baselined to
    the pre-cue period. That is the quantity worth plotting: the previous raw
    difference ``(P(C4) - P(C3)) * 1e12`` is in arbitrary units, scales with
    each subject's absolute amplitude, and therefore cannot be compared or
    averaged across subjects or datasets at all.
    """
    picks = _have(epochs_tfr, ("C3", "C4"))
    if len(picks) < 2:
        raise ValueError("Both C3 and C4 must carry real signal for a lateralisation index.")
    filt = epochs_tfr.copy().filter(band[0], band[1], picks=picks, verbose=False).copy().pick(picks)
    margin = (envelope_margin_samples(filt, display_window) if display_window else 0)
    times = filt.times[margin:len(filt.times) - margin] if margin else filt.times
    i3, i4 = filt.ch_names.index("C3"), filt.ch_names.index("C4")

    fig, ax = plt.subplots(figsize=(9, 4.5))
    palette = ["#1f77b4", "#2ca02c"]
    for idx, (name, code) in enumerate(filt.event_id.items()):
        data = filt[name].get_data()
        env = analytic_envelope(data, filt.info["sfreq"], margin_samples=margin, power=True)
        if normalize:
            lat = np.log(env[:, i4, :] + 1e-30) - np.log(env[:, i3, :] + 1e-30)
            if baseline is not None and times[0] < baseline[1]:
                bm = (times >= baseline[0]) & (times <= baseline[1])
                if bm.any():
                    lat = lat - lat[:, bm].mean(axis=1, keepdims=True)
        else:
            lat = env[:, i4, :] - env[:, i3, :]
        mean, sem = lat.mean(axis=0), lat.std(axis=0) / np.sqrt(max(len(lat), 1))
        c = palette[idx % len(palette)]
        ax.plot(times, mean, label=_display_label(name, code), color=c, lw=2)
        ax.fill_between(times, mean - sem, mean + sem, color=c, alpha=0.15)
    ax.axhline(0, color="k", ls="--", alpha=0.6)
    ax.axvline(0, color="gray", ls=":", label="Cue onset")
    ax.set_xlabel("Time from cue (s)")
    ax.set_ylabel("log P(C4) - log P(C3)" if normalize else "P(C4) - P(C3)")
    ax.set_title("Contralateral sensorimotor power divergence"
                 + (" (log ratio, baselined)" if normalize else ""), fontweight="bold")
    ax.legend(fontsize=8, loc="best")
    fig.tight_layout()
    return fig


def plot_normalized_lateralization(epochs_tfr, mu_band=(10, 14), display_window=None,
                                    primary_window=(1.0, 2.0)):
    fig = plot_lateralization_index(epochs_tfr, band=mu_band,
                                    display_window=display_window, normalize=True)
    fig.axes[0].axvspan(*primary_window, color="yellow", alpha=0.1,
                        label="Primary epoch window")
    fig.axes[0].legend(fontsize=8, loc="lower left")
    fig.axes[0].set_title("Normalized hemispheric SMR divergence", fontweight="bold")
    return fig


def compute_grand_average_topomap(epochs_input, mu_band=(10, 14),
                                   baseline_window=(-0.5, -0.05), imagery_window=(1.0, 2.5)):
    """Grand-average ERD topography.

    Averaging across recordings now averages only over channels that are REAL
    in every contributing recording. Averaging a masked zero into a grand mean
    silently pulls that electrode's ERD estimate toward 0 dB in proportion to
    how many datasets lack it -- which looks like a weak but genuine effect.
    """
    if isinstance(epochs_input, mne.BaseEpochs):
        epochs_dict = {"S001": epochs_input}
    elif isinstance(epochs_input, list):
        epochs_dict = {f"S{i+1:03d}": ep for i, ep in enumerate(epochs_input)}
    elif isinstance(epochs_input, dict):
        epochs_dict = epochs_input
    else:
        raise TypeError(f"Unsupported input type: {type(epochs_input)}")

    common_mask = None
    for ep in epochs_dict.values():
        m = get_channel_mask(ep)
        m = np.ones(len(ep.ch_names), dtype=bool) if m is None else m
        common_mask = m.copy() if common_mask is None else (common_mask & m)

    by_code = {}
    for ep in epochs_dict.values():
        filt = ep.copy().filter(mu_band[0], mu_band[1], verbose=False)
        times = filt.times
        bm = (times >= baseline_window[0]) & (times <= baseline_window[1])
        im_ = (times >= imagery_window[0]) & (times <= imagery_window[1])
        for name, code in filt.event_id.items():
            by_code.setdefault(code, []).append(_erd_db(filt[name].get_data(), bm, im_))

    grand = {code: np.mean(v, axis=0) for code, v in by_code.items()}
    info = next(iter(epochs_dict.values())).info
    allv = np.concatenate([g[common_mask] for g in grand.values()])
    vmax = np.percentile(np.abs(allv), 95)

    fig, axes = plt.subplots(1, len(grand), figsize=(5 * len(grand), 4.5))
    axes = np.atleast_1d(axes)
    img = None
    for ax, (code, vals) in zip(axes, grand.items()):
        img, _ = _masked_topo(vals, info, common_mask, ax, (-vmax, vmax))
        ax.set_title(CODE_TO_DISPLAY_LABEL.get(code, str(code)), fontsize=11, fontweight="bold")
    cbar_ax = fig.add_axes([0.92, 0.25, 0.02, 0.5])
    fig.colorbar(img, cax=cbar_ax).set_label("Mu-power change (dB vs. baseline)", fontsize=9)
    n = len(epochs_dict)
    extra = ("" if common_mask.all()
             else f"; restricted to the {int(common_mask.sum())} electrodes real in all")
    fig.suptitle(("Sensorimotor mu-ERD topography (single recording)" if n == 1 else
                  f"Cohort grand-average mu-ERD topography (N={n}{extra})"),
                 fontsize=13, y=0.98)
    return fig


def plot_dataset_amplitude_distribution(raw_before, raw_after, dataset_name, picks="eeg"):
    before = raw_before.get_data(picks=picks).ravel() * 1e6
    after = raw_after.get_data(picks=_real_channel_idx(raw_after)).ravel() * 1e6
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].hist(before, bins=200, color="tab:blue", alpha=0.8)
    axes[0].set_title(f"{dataset_name}: BEFORE"); axes[0].set_xlabel("Amplitude (uV)")
    axes[0].set_ylabel("Sample count")
    axes[1].hist(after, bins=200, color="tab:orange", alpha=0.8)
    axes[1].set_title(f"{dataset_name}: AFTER (filter + reference)")
    axes[1].set_xlabel("Amplitude (uV)")
    for ax in axes:
        ax.set_yscale("log")
    fig.suptitle(f"{dataset_name}: amplitude distribution, before vs. after")
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------
# Trial timeline
# --------------------------------------------------------------------------

def plot_dataset_event_timelines(dataset_specs: list):
    """Trial structure per dataset, drawn on a CUE-RELATIVE axis (t=0 is the
    imagery cue for every dataset, not the annotation onset)."""
    n = len(dataset_specs)
    fig, axes = plt.subplots(n, 1, figsize=(11.5, 2.9 * n), sharex=True)
    axes = np.atleast_1d(axes)
    for i, ds in enumerate(dataset_specs):
        ax = axes[i]
        first = (i == 0)
        ax.axvspan(*ds["pre_cue"], color="#e0e0e0", alpha=0.6,
                   label="Clean pre-cue baseline" if first else "")
        ax.axvline(0.0, color="#d62728", ls="--", lw=2, zorder=5,
                   label="Imagery cue (t=0)" if first else "")
        ax.axvspan(*ds["transient"], color="#ffcccc", alpha=0.6,
                   label="Excluded transient (VEP/orienting)" if first else "")
        ax.axvspan(*ds["primary_window"], color="#c8e6c9", alpha=0.8,
                   label="Primary epoch window" if first else "")
        if ds.get("trial_end") is not None and ds.get("rest_end") is not None \
                and ds["trial_end"] < ds["rest_end"]:
            ax.axvspan(ds["trial_end"], ds["rest_end"], color="#f5f5f5", alpha=0.5,
                       label="Post-trial rest / ITI" if first else "")
        if ds.get("feedback_onset") is not None:
            ax.axvspan(ds["feedback_onset"], ds["trial_end"], color="#ffe0b2", alpha=0.75,
                       hatch="xx", edgecolor="#e65100",
                       label="Online feedback (label-correlated)" if first else "")
        if ds.get("beep_at") is not None:
            ax.axvline(ds["beep_at"], color="#6a1b9a", ls="-.", lw=1.5,
                       label="Auditory warning" if first else "")
        ax.set_ylim(0, 1); ax.set_yticks([])
        offs = ds.get("annotation_offset")
        title = f"{ds['name']} [{ds['native_sfreq']}]"
        if offs:
            title += f"   (annotation sits {offs:+.1f}s from the cue)"
        ax.set_title(title, fontsize=10.5, fontweight="bold", loc="left", pad=8)
        ax.grid(True, axis="x", ls=":", alpha=0.6)
    axes[-1].set_xlabel("Time relative to the IMAGERY CUE (s)", fontsize=10, fontweight="bold")
    axes[-1].set_xlim(-3.4, 8.4)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1.03),
               ncol=4, fontsize=8.5, frameon=True)
    fig.suptitle("Cross-dataset paradigm alignment (cue-locked)",
                 fontsize=13, y=1.08, fontweight="bold")
    fig.tight_layout()
    return fig
