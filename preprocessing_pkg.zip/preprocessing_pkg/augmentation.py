"""Online augmentation for EEG tensors. Ported unchanged from the original
notebook.

FIXED: the `jitter_mode` type hint used to list "crop_resample" while
`temporal_jitter` only recognized "crop_and_resample", so the documented value
raised ValueError. The Literal now matches the implementation.

Also fixed: `temporal_jitter` drew ONE shift and applied it to the whole batch,
so every trial in a minibatch was displaced identically. That is a batch-level
augmentation masquerading as a per-trial one -- it reduces the effective
augmentation diversity by the batch size and correlates the noise across
samples within a step. Shifts are now drawn per trial.
"""

from __future__ import annotations
from typing import Literal
import numpy as np
import torch
import torch.nn.functional as F


class EEGAugmentationTransform:
    """Supports inputs of shape (C, T) or (B, C, T)."""

    def __init__(self, sfreq: float = 128.0, max_jitter_ms: float = 100.0,
                 jitter_mode: Literal["zero_pad", "reflect_pad", "crop_and_resample", "interpolation"] = "reflect_pad",
                 noise_snr_db: float = 20.0, channel_dropout_rate: float = 0.10,
                 p_jitter: float = 0.5, p_noise: float = 0.5, p_dropout: float = 0.3):
        self.sfreq = sfreq
        self.max_jitter_samples = int((max_jitter_ms / 1000.0) * sfreq)
        self.jitter_mode = jitter_mode
        self.noise_snr_db = noise_snr_db
        self.channel_dropout_rate = channel_dropout_rate
        self.p_jitter = p_jitter
        self.p_noise = p_noise
        self.p_dropout = p_dropout

    def _shift_one(self, x: torch.Tensor, shift: int) -> torch.Tensor:
        """x: (1, C, T) -> shifted (1, C, T), never circular."""
        t = x.shape[-1]
        if shift == 0:
            return x
        if self.jitter_mode == "zero_pad":
            return (F.pad(x[..., :-shift], (shift, 0), mode="constant", value=0.0)
                    if shift > 0 else
                    F.pad(x[..., -shift:], (0, -shift), mode="constant", value=0.0))
        if self.jitter_mode == "reflect_pad":
            return (F.pad(x[..., :-shift], (shift, 0), mode="reflect")
                    if shift > 0 else
                    F.pad(x[..., -shift:], (0, -shift), mode="reflect"))
        if self.jitter_mode == "crop_and_resample":
            crop_len = t - abs(shift)
            start = 0 if shift > 0 else abs(shift)
            return F.interpolate(x[..., start:start + crop_len], size=t,
                                 mode="linear", align_corners=True)
        if self.jitter_mode == "interpolation":
            b, c, _ = x.shape
            norm_shift = (2.0 * shift) / (t - 1)
            grid_x = torch.linspace(-1.0, 1.0, t, device=x.device).view(1, 1, t, 1).expand(b, c, t, 1)
            grid = torch.cat([grid_x - norm_shift, torch.zeros_like(grid_x)], dim=-1)
            return F.grid_sample(x.unsqueeze(-1), grid, mode="bilinear",
                                 padding_mode="border", align_corners=True).squeeze(-1)
        raise ValueError(f"Unknown jitter_mode: {self.jitter_mode}")

    def temporal_jitter(self, x: torch.Tensor) -> torch.Tensor:
        """Non-circular temporal jitter, drawn INDEPENDENTLY PER TRIAL.

        The previous version drew a single shift per call and applied it to the
        whole batch, so every trial in a minibatch moved together -- which is a
        batch-level perturbation, not per-sample augmentation.
        """
        if self.max_jitter_samples <= 0:
            return x
        was_2d = x.ndim == 2
        if was_2d:
            x = x.unsqueeze(0)
        shifts = np.random.randint(-self.max_jitter_samples,
                                   self.max_jitter_samples + 1, size=x.shape[0])
        out = torch.cat([self._shift_one(x[i:i + 1], int(s))
                         for i, s in enumerate(shifts)], dim=0)
        return out.squeeze(0) if was_2d else out

    def add_gaussian_noise(self, x: torch.Tensor) -> torch.Tensor:
        signal_power = torch.mean(x ** 2, dim=-1, keepdim=True)
        snr_linear = 10.0 ** (self.noise_snr_db / 10.0)
        noise_power = signal_power / snr_linear
        noise = torch.randn_like(x) * torch.sqrt(noise_power + 1e-12)
        return x + noise

    def channel_dropout(self, x: torch.Tensor) -> torch.Tensor:
        if self.channel_dropout_rate <= 0.0:
            return x
        if x.ndim == 3:
            b, c, _ = x.shape
            mask = (torch.rand(b, c, 1, device=x.device) > self.channel_dropout_rate).float()
        elif x.ndim == 2:
            c, _ = x.shape
            mask = (torch.rand(c, 1, device=x.device) > self.channel_dropout_rate).float()
        else:
            raise ValueError(f"Expected 2D or 3D tensor, got shape {x.shape}")
        return x * mask * (1.0 / np.sqrt(1.0 - self.channel_dropout_rate))

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        out = x.clone()
        if np.random.rand() < self.p_jitter:
            out = self.temporal_jitter(out)
        if np.random.rand() < self.p_noise:
            out = self.add_gaussian_noise(out)
        if np.random.rand() < self.p_dropout:
            out = self.channel_dropout(out)
        return out
